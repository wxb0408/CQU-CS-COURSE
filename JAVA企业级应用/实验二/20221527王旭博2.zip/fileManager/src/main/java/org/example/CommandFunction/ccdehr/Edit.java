package org.example.CommandFunction.ccdehr;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Edit implements CommandStatus {
    String address;
    int status;


    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    @Override
    public void excute(String[] command) {
        if(command.length!=2){
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！",ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
        }else{
            //无论给出的为绝对路径还是相对路径都构造成绝对路径
            File file ;
            Path path = Paths.get(command[1]);
            //确保file为绝对路径
            if (!path.isAbsolute()){
                file = new File(this.address, command[1]);
            }
            else{
                file = new File(command[1]);//
            }
            if(!file.exists()){
                System.out.println(ConsoleColor.colored("该路径下文件不存在，请确定文件路径",ConsoleColor.RED));
                System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
            }else{
                //接下来要读取文件内容打印，并在此基础上编辑保存
                //一、读取文件内容
                List<String> lines = new ArrayList<>();
                try(Scanner fileScanner = new Scanner(new FileReader(file))){//制定读取文件的scanner
                    while(fileScanner.hasNextLine()){
                        lines.add(fileScanner.nextLine());
                    }
                }catch(FileNotFoundException e){
                    System.out.println(ConsoleColor.colored("文件读取失败",ConsoleColor.RED));
                    System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                }
                //二、将读取的文件内容打印到控制台上
                for(String line:lines){
                    System.out.println(line);
                }
                //三、编辑进入自己的内容
                System.out.println(ConsoleColor.colored("输入你的新的内容，输入 'exit' 结束编辑:",ConsoleColor.RED));
                Scanner inputScanner = new Scanner(System.in);//创建一个从键盘读取的scanner
                StringBuilder newContent = new StringBuilder();//创建一个存储输入的字符串构造器
                while (true) {
                    String userInput = inputScanner.nextLine();
                    if ("exit".equalsIgnoreCase(userInput.trim())) {
                        break;
                    }
                    newContent.append(userInput).append(System.lineSeparator());
                }
                //四、加入文件保存退出
                try (FileWriter fileWriter = new FileWriter(file,true)) {
                    fileWriter.write(newContent.toString());
                    System.out.println(ConsoleColor.colored("文件已更新",ConsoleColor.RED));
                    System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                } catch (IOException e) {
                    System.out.println(ConsoleColor.colored("文件写入失败",ConsoleColor.RED));
                    System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                }
            }
        }
    }
}
