package org.example.Menu;

import org.example.CommandFunction.ccdehr.*;
import org.example.CommandFunction.copy.Copy;
import org.example.CommandFunction.copy.Xcopy;
import org.example.CommandFunction.crypt.Decrypt;
import org.example.CommandFunction.crypt.Encrypt;
import org.example.CommandFunction.delete.Del;
import org.example.CommandFunction.delete.Rmdir;
import org.example.CommandFunction.mkdir.Mkdir;
import org.example.CommandFunction.mkdir.Mkdirs;
import org.example.CommandFunction.zip.Unzip;
import org.example.CommandFunction.zip.Zip;
import org.example.util.AddressObservable;
import org.example.util.ConsoleColor;

import java.util.Scanner;

public class MenuController {
    String address = "c:>";//实时记录当前所处于的目录
    //读取一行命令的对象
    Scanner in=new Scanner(System.in);
    //系统的统一管理处
    public void  mainMenu(){
        Help help = Help.getInstance(this.address);
        System.out.println("******************************");
        System.out.println("*   欢迎来到命令行文件管理系统！   *");
        System.out.println("******************************");
        System.out.print("c:>");
        //注册观察者
        AddressObservable addressObservable = new AddressObservable();
        Edit edit = new Edit();
        addressObservable.addObserver(edit);
        Cd cd = new Cd();
        addressObservable.addObserver(cd);
        Mkdir mkdir = new Mkdir();
        addressObservable.addObserver(mkdir);
        Mkdirs mkdirs = new Mkdirs();
        addressObservable.addObserver(mkdirs);
        Cat cat = new Cat();
        addressObservable.addObserver(cat);
        Del del = new Del();
        addressObservable.addObserver(del);
        Rmdir rmdir = new Rmdir();
        addressObservable.addObserver(rmdir);
        Rename rename = new Rename();
        addressObservable.addObserver(rename);
        Dir dir = new Dir();
        addressObservable.addObserver(dir);
        Copy copy = new Copy();
        addressObservable.addObserver(copy);
        Xcopy xcopy = new Xcopy();
        addressObservable.addObserver(xcopy);
        Zip zip = new Zip();
        addressObservable.addObserver(zip);
        Unzip unzip = new Unzip();
        addressObservable.addObserver(unzip);
        Encrypt encrypt = new Encrypt();
        addressObservable.addObserver(encrypt);
        Decrypt decrypt = new Decrypt();
        addressObservable.addObserver(decrypt);
        addressObservable.setAddress("c:>");
        help.setAddress("c:>");
        boolean flag = true;
        while(flag){
            String[] command = this.getCinFormat();
            switch(command[0]){
                case "help":
                    if(command.length == 1) {
                        help.showHelp();
                        break;
                    }else{
                        this.help(command);
                        break;
                    }
                case "cd":
                    cd.excute(command);
                    addressObservable.setAddress(cd.getAddress());
                    help.setAddress(cd.getAddress());
                    break;
                case "mkdir":
                    mkdir.excute(command);
                    break;
                case "mkdirs":
                    mkdirs.excute(command);
                    break;
                case "edit":
                    edit.excute(command);
                    break;
                case "cat":
                    cat.excute(command);
                    break;
                case "del":
                    del.excute(command);
                    break;
                case "rmdir":
                    rmdir.excute(command);
                    break;
                case "rename":
                    rename.excute(command);
                    break;
                case "dir":
                    dir.excute(command);
                    break;
                case "copy":
                    copy.excute(command);
                    break;
                case "xcopy":
                    xcopy.excute(command);
                    break;
                case "zip":
                    try {
                        zip.excute(command);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    break;
                case "unzip":
                    try {
                        unzip.excute(command);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    break;
                case "encyrpt":
                    encrypt.excute(command);
                    break;
                case "decyrpt":
                    decrypt.excute(command);
                    break;
                case "exit":
                    flag = false;
                    break;
                default:
                    System.out.println("指令错误，请重新输入！");
                    System.out.println("输入help，查看指令详情！");
                    System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                    break;
            }
        }

    }
    //将输入的一行命令进行切割，从而获取该命令的对应操作
    public String[] getCinFormat(){
        String parse = in.nextLine();
        String[] command = parse.trim().split(" ");//将给定的指令通过空格进行分割，以识别指令
        command[0] = command[0].toLowerCase();//全部转为小写方便后续指令的判定
        return command;
    }

    private void help(String[] command){
        Help help = Help.getInstance(this.address);
        switch (command[1]){
            case "cat":
                help.cat();
                break;
            case "cd":
                help.cd();
                break;
            case "dir":
                help.dir();
                break;
            case "edit":
                help.edit();
                break;
            case "rename":
                help.rename();
                break;
            case "copy":
                help.copy();
                break;
            case "xcopy":
                help.xcopy();
                break;
            case "decrypt":
                help.decyrpt();
                break;
            case "encrypt":
                help.encyrpt();
                break;
            case "del":
                help.del();
                break;
            case "rmdir":
                help.rmdir();
                break;
            case "mkdir":
                help.mkdir();
                break;
            case "mkdirs":
                help.mkdirs();
                break;
            case "zip":
                help.zip();
                break;
            case "unzip":
                help.unzip();
                break;
            default:
                System.out.println("指令错误，请重新输入！");
                System.out.println("输入help，查看指令详情！");
                System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                break;
        }
    }


}
