package org.example.CommandFunction.ccdehr;

import org.example.util.ConsoleColor;

public class Help {

    String address;

    public void setAddress(String address){
        this.address = address;
    }


    private static Help Instance;
//    private Help(){}

    public static Help getInstance(String address){
        if (Instance == null){
            synchronized (Help.class){
                if(Instance==null){
                    Instance=new Help(address);
                }
            }
        }
        return Instance;
    }

    public Help(String address){
        this.address = address;
    }
    public void showHelp(){
        System.out.println("--------------------帮助--------------------");
        System.out.println(ConsoleColor.colored("命令格式： 命令名称 [参数]",ConsoleColor.RED));
        System.out.println();
        System.out.print(ConsoleColor.colored("cd",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("        显示当前目录名或改变当前目录",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("dir",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("       显示目录中的文件和子目录列表",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("mkdir",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("     创建文件",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("mkdirs",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("    创建文件夹",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("edit",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("      编辑文件",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("copy",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("      将一份文件或多份文件拷贝到另一位置",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("xcopy",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("     将一份文件夹或多份文件夹拷贝到另一位置",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("del",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("       删除一个或多个文件",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("rmdir",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("     删除文件夹",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("cat",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("       显示文本文件内容",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("encrypt",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("   加密文件",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("decrypt",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("   解密文件",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("zip",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("       压缩文件",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("unzip",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("     解压文件",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored("rename",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("    重命名文件",ConsoleColor.BLUE));
        System.out.println(ConsoleColor.colored("若想查看详细信息，请输入“help 命令名称”查看！",ConsoleColor.BLUE));
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void cat(){
        System.out.println(ConsoleColor.colored("dir: 显示文本文件内容",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1: 相对路径显示文本文件内容",ConsoleColor.BLUE));
        System.out.println("使用示例：cat 1.txt  cat 常用地址.md");
        System.out.println("功能描述：完整的显示文本文件内容");
        System.out.println("注意事项：无法查看.docx等非文本文件内容");
        System.out.println();
        System.out.println(ConsoleColor.colored("2: 绝对路径路径显示文本文件内容",ConsoleColor.BLUE));
        System.out.println("使用示例：cat E:\\操作系统\\常用地址.md");
        System.out.println("功能描述：完整的显示文本文件内容");
        System.out.println("注意事项：无法查看.docx等非文本文件内容");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void cd(){
        System.out.println(ConsoleColor.colored("cd: 更换当前目录",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.返回上一级 cd ..",ConsoleColor.BLUE));
        System.out.println("使用示例：cd ..");
        System.out.println("功能描述：返回上一级的目录");
        System.out.println("注意事项：如果处于盘符则不会发生变化");
        System.out.println();
        System.out.println(ConsoleColor.colored("2: 使用相对路径 cd [相对路径]",ConsoleColor.BLUE));
        System.out.println("使用示例：cd 操作系统");
        System.out.println("功能描述：基于当前目录访问相对路径");
        System.out.println();
        System.out.println(ConsoleColor.colored("3: 使用绝对路径路径 cd [绝对路径]",ConsoleColor.BLUE));
        System.out.println("使用示例：cd E:\\操作系统");
        System.out.println("功能描述：直接访问绝对路径，与当前目录无关");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void dir(){
        System.out.println(ConsoleColor.colored("dir:文件夹下的内容罗列",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1: 仅显示当前目录下的文件 dir single [相对路径]/[绝对路径]",ConsoleColor.BLUE));
        System.out.println("使用示例：dir single E:\\操作系统  dir single 操作系统");
        System.out.println("功能描述： 仅显示当前目录下的所有文件");
        System.out.println();
        System.out.println(ConsoleColor.colored("2.显示当前目录下的所有文件 dir all [相对路径]/[绝对路径]",ConsoleColor.BLUE));
        System.out.println("使用示例：dir all E:\\操作系统  dir all 操作系统");
        System.out.println("功能描述： 显示当前目录下的所有文件(包含子目录)");
        System.out.println();
        System.out.println(ConsoleColor.colored("3.单过滤条件下文件夹内容罗列 dir [single]/[all] [相对路径]/[绝对路径] filter [name]/[size]/[time]/[type]",ConsoleColor.BLUE));
        System.out.println("使用示例： dir all cmdtest filter name 1   dir all cmdtest filter size >30   dir all cmdtest filter time >2024-11-03-17:06:03");
        System.out.println("功能描述： 添加单一的过滤条件对文件夹内容进行过滤显示");
        System.out.println("注意事项： 以大小和时间为条件过滤时，需要使用不等式表示，且大小以bit为单位");
        System.out.println();
        System.out.println(ConsoleColor.colored("4.多过滤条件下文件夹内容罗列 dir [single]/[all] [相对路径]/[绝对路径] filter [name]/[size]/[time]/[type]",ConsoleColor.BLUE));
        System.out.println("使用示例： dir all cmdtest filter name 1 size >30 time >2024-11-03-17:06:03");
        System.out.println("功能描述： 添加多个过滤条件1对文件夹进行多次过滤");
        System.out.println("注意事项： 在filter后面直接跟过滤事项和条件，不需要写多个filter");
        System.out.println();
        System.out.println(ConsoleColor.colored("5.文件夹下内容罗列按照选定顺序进行罗列 dir [single]/[all] [相对路径]/[绝对路径] sort [name]/[size]/[time]",ConsoleColor.BLUE));
        System.out.println("使用示例： dir all cmdtest sort time");
        System.out.println("功能描述： 基于给定的排列顺序对文件夹下的内容进行罗列");
        System.out.println("注意事项： 排序的条件一次性只能选择定一个");
        System.out.println();
        System.out.println(ConsoleColor.colored("6.文件夹下内容罗列基于过滤条件与排序条件同时进行 dir [single]/[all] [相对路径]/[绝对路径] filter [name]/[size]/[time]/[type] sort [name]/[size]/[time]",ConsoleColor.BLUE));
        System.out.println("使用示例： dir all cmdtest filter name 1 size >30 time >2024-11-03-17:06:03 sort time");
        System.out.println("功能描述： 文件夹下的内容显示将会基于过滤条件和排序条件同时进行");
        System.out.println("注意事项： 所有过滤条件要写在排序条件之前，多过滤条件下只用写一个filter");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }
    public void edit(){
        System.out.println(ConsoleColor.colored("edit: 文本文件的编辑",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.绝对路径下文本文件的编辑 edit [绝对路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： edit E:\\操作系统\\常用地址.md");
        System.out.println("功能描述： 绝对路径下文本文件的编辑");
        System.out.println("注意事项： 本编辑功能只能针对文本文件生效，输入exit结束命令");
        System.out.println();
        System.out.println(ConsoleColor.colored("2.相对路径下文本文件的编辑 edit [相对路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： edit 常用地址.md");
        System.out.println("功能描述： 相对路径下文本文件的编辑");
        System.out.println("注意事项： 本编辑功能只能针对文本文件生效，输入exit结束命令");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void rename(){
        System.out.println(ConsoleColor.colored("rename: 文件或文件夹的重命名",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.文件夹的重命名 rename [旧文件夹名] [新文件夹名]",ConsoleColor.BLUE));
        System.out.println("使用示例：rename 操作系统 test");
        System.out.println("功能描述： 文件夹的重命名");
        System.out.println("注意事项： 此处暂时只能使用相对路径，不要使用绝对路径");
        System.out.println();
        System.out.println(ConsoleColor.colored("2.文件的重命名 rename [旧文件名] [新文件名]",ConsoleColor.BLUE));
        System.out.println("使用示例：rename PGO+LTO+静态编译优化.docx 112.docx");
        System.out.println("功能描述： 文件的重命名");
        System.out.println("注意事项： 此处暂时只能使用相对路径，不要使用绝对路径,且在写文件名时请添加后缀");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void copy(){
        System.out.println(ConsoleColor.colored("copy: 文件的拷贝",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.单文件的前台拷贝 copy -F [目标路径] [源文件路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： copy -F E:\\yidong 第2章操作系统结构.pptx");
        System.out.println("功能描述： 对单个文件在前台进行拷贝");
        System.out.println("注意事项： 此处暂时不支持使用通配符进行文件选择，可以使用绝对路径或相对路径");
        System.out.println();
        System.out.println(ConsoleColor.colored("2.单文件的后台拷贝 copy -B [目标路径] [源文件路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： copy -B E:\\yidong 第2章操作系统结构.pptx");
        System.out.println("功能描述： 对单个文件在后台进行拷贝");
        System.out.println("注意事项： 此处暂时不支持使用通配符进行文件选择，可以使用绝对路径或相对路径");
        System.out.println();
        System.out.println(ConsoleColor.colored("3.批量文件的前台拷贝 copy -F [目标路径] [源文件路径]/[源文件路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： copy -F E:\\yidong 第2章操作系统结构.pptx 第3章进程与线程.pptx");
        System.out.println("功能描述： 对单个文件在前台进行拷贝");
        System.out.println("注意事项： 此处暂时不支持使用通配符进行文件选择，可以使用绝对路径或相对路径，不同源文件以空格分割");
        System.out.println();
        System.out.println(ConsoleColor.colored("4.批量文件的后台拷贝 copy -B [目标路径] [源文件路径]/[源文件路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： copy -B E:\\yidong 第2章操作系统结构.pptx 第3章进程与线程.pptx");
        System.out.println("功能描述： 对单个文件在后台进行拷贝");
        System.out.println("注意事项： 此处暂时不支持使用通配符进行文件选择，可以使用绝对路径或相对路径，不同源文件以空格分割");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void xcopy(){
        System.out.println(ConsoleColor.colored("copy: 文件夹的拷贝",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.单文件夹的前台拷贝 copy -F [目标路径] [源文件夹路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： copy -F E:\\yidong E:\\test\\tasks_k");
        System.out.println("功能描述： 对单个文件夹在前台进行拷贝");
        System.out.println("注意事项： 此处请使用绝对路径");
        System.out.println();
        System.out.println(ConsoleColor.colored("2.单文件夹的后台拷贝 copy -B [目标路径] [源文件夹路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： copy -B E:\\yidong E:\\test\\tasks_k");
        System.out.println("功能描述： 对单个文件夹在后台进行拷贝");
        System.out.println("注意事项： 此处请使用绝对路径");
        System.out.println();
        System.out.println(ConsoleColor.colored("3.批量文件夹的前台拷贝 copy -F [目标路径] [源文件夹路径]/[源文件夹路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： copy -F E:\\yidong  E:\\M3.8.7 E:\\test\\tasks_k");
        System.out.println("功能描述： 对单个文件夹在前台进行拷贝");
        System.out.println("注意事项： 此处请使用绝对路径");
        System.out.println();
        System.out.println(ConsoleColor.colored("4.批量文件夹的后台拷贝 copy -B [目标路径] [源文件夹路径]/[源文件夹路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： copy -B E:\\yidong  E:\\M3.8.7 E:\\test\\tasks_k");
        System.out.println("功能描述： 对单个文件夹在后台进行拷贝");
        System.out.println("注意事项： 此处请使用绝对路径");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void encyrpt(){
        System.out.println(ConsoleColor.colored("encyrpt: 文件的加密",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.单文件AES加密 encyrpt [源文件路径] [目标文件路径] -[1]",ConsoleColor.BLUE));
        System.out.println("使用示例：encyrpt 《openEuler操作系统》鲲鹏云ECS版v1.0.docx E:\\test -1");
        System.out.println("功能描述： 对指定文件进行加密并生成新的文件到指定目录下");
        System.out.println("注意事项： 输入的秘钥必须为16位，请记录相应秘钥，以供解密使用，此处可以使用相对路径或绝对路径");
        System.out.println();
        System.out.println(ConsoleColor.colored("2.单文件异或加密 encyrpt [源文件路径] [目标文件路径] -[2]",ConsoleColor.BLUE));
        System.out.println("使用示例：encyrpt 《openEuler操作系统》鲲鹏云ECS版v1.0.docx E:\\test -2");
        System.out.println("功能描述： 对指定文件进行加密并生成新的文件到指定目录下");
        System.out.println("注意事项： 该加密算法的安全性较低");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }


    public void decyrpt(){
        System.out.println(ConsoleColor.colored("decyrpt: 加密文件的解密",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.单文件的ASE解密 decyrpt [源文件路径] [目标文件路径] -[1]",ConsoleColor.BLUE));
        System.out.println("使用示例：decyrpt 《openEuler操作系统》鲲鹏云ECS版v1.0.docx E:\\test -1");
        System.out.println("功能描述： 对指定文件进行解密并生成新的文件到指定目录下");
        System.out.println("注意事项： 输入的秘钥需要与加密时的设定相同");
        System.out.println();
        System.out.println(ConsoleColor.colored("2.单文件异或的解密 decyrpt [源文件路径] [目标文件路径] -[2]",ConsoleColor.BLUE));
        System.out.println("使用示例：decyrpt 《openEuler操作系统》鲲鹏云ECS版v1.0.docx E:\\test -2");
        System.out.println("功能描述： 对指定文件进行解密并生成新的文件到指定目录下");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void del(){
        System.out.println(ConsoleColor.colored("del: 文件的删除",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.单文件的删除 del [通配符]/[相对路径]/[绝对路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： del *.pptx del 123456789.docx del E:\\test\\112.docx");
        System.out.println("功能描述： 对单个文件进行删除");
        System.out.println();
        System.out.println(ConsoleColor.colored("2.批处理文件的删除 del [通配符][相对路径][绝对路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： del *.pptx 123456789.docx E:\\test\\112.docx");
        System.out.println("功能描述： 对单个文件进行删除");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void rmdir(){
        System.out.println(ConsoleColor.colored("rmdir: 文件夹的删除",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.单文件夹的删除 rmdir [相对路径]/[绝对路径]",ConsoleColor.BLUE));
        System.out.println("使用示例： rmdir test  rmdir E:\\test");
        System.out.println("功能描述： 删除文件夹");
        System.out.println("注意事项： 本命令仅能对单文件夹进行删除，不要同时删除多文件夹");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void mkdir(){
        System.out.println(ConsoleColor.colored("mkdir: 文件的创建",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.单文件的创建 mkdir [文件名称]",ConsoleColor.BLUE));
        System.out.println("使用示例： mkdir test.docx  mkdir E:\\test.docx");
        System.out.println("功能描述： 在指定目录之下创建文件");
        System.out.println("注意事项： 如果文件已经存在，请选择是否替换。文件的名称要完整（包含后缀）");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void mkdirs(){
        System.out.println(ConsoleColor.colored("mkdirs: 文件夹的创建",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.文件夹的创建 mkdirs [文件夹名称]",ConsoleColor.BLUE));
        System.out.println("使用示例： mkdirs test   mkdirs E:\\test");
        System.out.println("功能描述： 在指定的路径下创建文件夹");
        System.out.println("注意事项： 如果目录中文件夹已经存在并同意替换，则原文件夹中的内容将会被完全删除");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void zip(){
        System.out.println(ConsoleColor.colored("zip: 批量文件或文件夹的压缩",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.批量文件或文件夹的压缩 zip [压缩文件名] [一系列待压缩文件/文件夹]",ConsoleColor.BLUE));
        System.out.println("使用示例： zip test test test.docx");
        System.out.println("功能描述： 将指定的文件或文件夹批量的压缩到一个.zip文件中");
        System.out.println("指定压缩文件名不要带有后缀");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }

    public void unzip(){
        System.out.println(ConsoleColor.colored("unzip: 压缩文件的解压缩",ConsoleColor.RED));
        System.out.println(ConsoleColor.colored("1.压缩文件的解压缩 unzip [解压缩目标路径] [压缩文件夹]",ConsoleColor.BLUE));
        System.out.println("使用示例： unzip test test.zip");
        System.out.println("功能描述： 将指定的压缩文件解压缩到指定的目录中");
        System.out.println("一次性只能解压一个文件夹");
        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
    }
}
