package org.example.util;

public interface CommandStatus {
    // 执行成功状态
    int SUCCESS = 1;
    // 未完成状态
    int UNDONE = 0;

    /**
     * 执行命令的方法
     * @param command 输入的命令数组
     * @return 执行状态，返回对应的状态常量
     */
    void excute(String[] command) throws Exception;

    void updateAddress(String newAddress);
}
