package org.example.util;

import java.util.ArrayList;
import java.util.List;

public class AddressObservable {
    private String address;
    private List<CommandStatus> observers = new ArrayList<>();

    public void setAddress(String newAddress) {
        this.address = newAddress;
        notifyObservers();
    }
    public String getAddress() {
        return address;
    }
    public void addObserver(CommandStatus observer) {
        observers.add(observer);
    }
    private void notifyObservers() {
        for (CommandStatus observer : observers) {
            observer.updateAddress(address);
        }
    }
}
