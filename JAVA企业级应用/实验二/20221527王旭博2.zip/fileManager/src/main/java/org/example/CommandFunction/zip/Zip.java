package org.example.CommandFunction.zip;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;
import org.example.util.compress;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.ZipOutputStream;

public class Zip implements CommandStatus {
    String address;
    int status;


    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }
    //zip 压缩文件命名 带压缩的文件
    @Override
    public void excute(String[] command) throws Exception {
        if (command.length < 3) {
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
            return; // 这里加上 return，避免后续代码在输入错误时执行
        }

        // 创建压缩文件名
        String zipFileName = Paths.get(address, command[1] + ".zip").toAbsolutePath().toString(); // 可以根据需要自定义压缩包名称
        FileOutputStream fos = new FileOutputStream(zipFileName);
        ZipOutputStream zipOut = new ZipOutputStream(fos);

        try {
            // 遍历每个需要压缩的文件或文件夹
            for (int i = 2; i < command.length; i++) {
                String filePath = command[i];
                Path path = Paths.get(address, filePath).toAbsolutePath(); // 拼接地址

                File fileToZip = path.toFile();
                if (fileToZip.exists()) {
                    if (fileToZip.isDirectory()) {
                        // 使用相对路径作为basePath
                        String basePath = fileToZip.getName() + "/";
                        compress.zipDirectory(fileToZip, zipOut, basePath);
                    } else {
                        // 使用空的basePath，压缩文件
                        compress.zipFile(fileToZip, zipOut, ""); // 注意这里传递空的basePath
                    }
                } else {
                    System.out.println(ConsoleColor.colored("未找到带压缩文件： " + path, ConsoleColor.RED));
                }
            }
        } finally {
            zipOut.close();
            fos.close();
        }

        System.out.println(ConsoleColor.colored("压缩完成: " + zipFileName, ConsoleColor.RED));
        System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
    }
}
