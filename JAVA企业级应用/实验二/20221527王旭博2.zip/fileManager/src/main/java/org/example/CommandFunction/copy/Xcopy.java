package org.example.CommandFunction.copy;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Stack;


public class Xcopy implements CommandStatus {
    String address;
    private long totalBytes = 0; // 用于记录总字节数
    private long copiedBytes = 0; // 用于记录已复制的字节数
    private volatile boolean copying = true; // 用于控制进度条线程
    private long bytes = 0;



    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    // copy -F/B target source
    @Override
    public void excute(String[] command) {
        if (command.length < 4) {
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
            return;
        }
        // 目标地址
        String destinationPath = command[2];
        // 源路径
        String sourcePath = command[3];
        // 选择前台或后台执行
        String mode = command[1];

        if (mode.equals("-F")) {
            copyFolderInForeground(sourcePath, destinationPath);
        } else {
            new Thread(() -> copyFolderInBackground(sourcePath, destinationPath)).start();
            System.out.println(ConsoleColor.colored("拷贝任务已在后台启动", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        }
    }

    // 前台拷贝文件夹
    private void copyFolderInForeground(String sourcePath, String destinationPath) {
        long startTime = System.currentTimeMillis();
        Stack<File> stack = new Stack<>(); // 使用栈结构
        File sourceFolder = new File(sourcePath);
        stack.push(sourceFolder);
        // 先计算总字节数
        this.bytes = calculateTotalBytes(sourceFolder);
        // 创建目标路径，确保包含源文件夹的名称
        File newDestinationPath = new File(destinationPath, sourceFolder.getName());
        newDestinationPath.mkdirs(); // 创建目标文件夹

        // 创建一个新的线程来显示进度条
        Thread progressThread = new Thread(() -> {
            while (copying) {
                displayProgressBar(copiedBytes, totalBytes);
                try {
                    Thread.sleep(500); // 每隔500毫秒更新一次
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            // 复制完成后显示总耗时
            long totalTime = System.currentTimeMillis() - startTime;
            System.out.println("\n拷贝完成，总耗时: " + (totalTime) + "ms");
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        });

        progressThread.start();

        // 拷贝文件夹
        try {
            while (!stack.isEmpty()) {
                File currentFile = stack.pop();
                // 根据原始路径在目标路径下生成完整的目标路径
                String relativePath = currentFile.getAbsolutePath().substring(sourceFolder.getAbsolutePath().length());
                File newFile = new File(newDestinationPath, relativePath);

                if (currentFile.isDirectory()) {
                    newFile.mkdirs(); // 创建新目录
                    // 将子文件夹压入栈中
                    File[] children = currentFile.listFiles();
                    if (children != null) {
                        for (File child : children) {
                            stack.push(child);
                        }
                    }
                } else {
                    // 复制文件
                    copiedBytes += copyFileWithProgress(currentFile.toPath(), newFile.toPath());
                }
            }
        } catch (IOException e) {
            System.out.println(ConsoleColor.colored("拷贝失败", ConsoleColor.RED));
        } finally {
            copying = false; // 设置为 false，结束进度条线程
            progressThread.interrupt(); // 中断进度条线程
        }
    }

    // 后台拷贝文件夹
    private void copyFolderInBackground(String sourcePath, String destinationPath) {
        long startTime = System.currentTimeMillis();
        Stack<File> stack = new Stack<>(); // 使用栈结构
        stack.push(new File(sourcePath));

        // 创建目标路径，确保包含源文件夹的名称
        File sourceFolder = new File(sourcePath);
        File newDestinationPath = new File(destinationPath, sourceFolder.getName());
        newDestinationPath.mkdirs();

        // 拷贝文件夹
        try {
            while (!stack.isEmpty()) {
                File currentFile = stack.pop();
                String relativePath = currentFile.getAbsolutePath().substring(sourceFolder.getAbsolutePath().length());
                File newFile = new File(newDestinationPath, relativePath);

                if (currentFile.isDirectory()) {
                    newFile.mkdirs(); // 创建新目录
                    // 将子文件夹压入栈中
                    File[] children = currentFile.listFiles();
                    if (children != null) {
                        for (File child : children) {
                            stack.push(child);
                        }
                    }
                } else {
                    // 复制文件
                    copyFile(currentFile.toPath(), newFile.toPath());
                }
            }
            long endTime = System.currentTimeMillis();
            System.out.println();
            System.out.println(ConsoleColor.colored("拷贝完成, 总耗时: " + (endTime - startTime) + " 毫秒", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        } catch (IOException e) {
            System.out.println(ConsoleColor.colored("拷贝失败", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        }
    }

    private long copyFileWithProgress(Path source, Path destination) throws IOException {
        try (InputStream in = Files.newInputStream(source);
             OutputStream out = Files.newOutputStream(destination)) {
            byte[] buffer = new byte[1024]; // 1KB buffer
            long totalBytesCopied = 0;
            int bytesRead;

            long lastReportedProgress = 0; // 记录上一次更新的进度
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
                totalBytesCopied += bytesRead;
                copiedBytes += bytesRead;

                // 每当复制达到2%的进度时更新进度条
                long currentProgress = (copiedBytes * 100) / this.bytes;
                if (currentProgress >= lastReportedProgress + 2) {
                    lastReportedProgress += 2; // 更新上次报告的进度
                    displayProgressBar(copiedBytes, this.bytes);
                }
            }
            return totalBytesCopied;
        }
    }

    private void copyFile(Path source, Path destination) throws IOException {
        try (InputStream in = Files.newInputStream(source);
             OutputStream out = Files.newOutputStream(destination)) {
            byte[] buffer = new byte[1024]; // 1KB buffer
            int bytesRead;

            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }
    }

    // 计算给定文件夹内所有文件的总字节数
    private long calculateTotalBytes(File folder) {
        Stack<File> stack = new Stack<>();
        stack.push(folder);

        while (!stack.isEmpty()) {
            File currentFile = stack.pop();

            if (currentFile.isDirectory()) {
                File[] children = currentFile.listFiles();
                if (children != null) {
                    for (File child : children) {
                        stack.push(child);
                    }
                }
            } else {
                totalBytes += currentFile.length(); // 累加文件大小
            }
        }
        return totalBytes;
    }

    // 绘制进度条
    private void displayProgressBar(long copiedBytes, long totalBytes) {
        int percent = (int) ((copiedBytes * 100) / totalBytes);
        int barLength = 50; // 进度条长度
        int progressLength = (percent * barLength) / 100;

        StringBuilder progressBar = new StringBuilder("[");
        for (int i = 0; i < barLength; i++) {
            if (i < progressLength) {
                progressBar.append('#');
            } else {
                progressBar.append(' ');
            }
        }
        progressBar.append("] ").append(percent).append("%");

        System.out.print("\r" + progressBar.toString());
    }
}
