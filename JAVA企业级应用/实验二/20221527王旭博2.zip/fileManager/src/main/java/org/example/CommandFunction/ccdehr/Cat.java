package org.example.CommandFunction.ccdehr;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Cat implements CommandStatus {
    String address;
    int status;

    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    @Override
    public void excute(String[] command) {
        this.status = CommandStatus.UNDONE;
        if (command.length == 2) {
            String filePath = command[1];
            // 检查路径是否为相对路径
            if (!new File(filePath).isAbsolute()) {
                filePath = address + File.separator + filePath; // 拼接为完整路径
            }
            File file = new File(filePath);
            //判断文件是否存在
            if (!file.exists()) {
                System.out.println(ConsoleColor.colored("未找到对应目录文件！",ConsoleColor.RED));
                System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
            }else
            // 读取文件内容并输出
            {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    //循环获取每一行
                    while ((line = reader.readLine()) != null) {
                        System.out.println(line);
                    }
                    System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                } catch (IOException e) {
                    System.out.println(ConsoleColor.colored("读取文件发生错误！",ConsoleColor.RED));
                    System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                }
            }
        }else{
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！",ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
        }
    }
}
