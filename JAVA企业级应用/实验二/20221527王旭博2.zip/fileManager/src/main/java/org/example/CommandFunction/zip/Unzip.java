package org.example.CommandFunction.zip;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;
import org.example.util.compress;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Unzip implements CommandStatus {
    String address;
    int status;


    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }
    //unzip 目标路径 带解压文件夹
    @Override
    public void excute(String[] command) throws Exception {
        if (command.length < 3) {
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
            return; // 防止后续代码执行
        }
        // 确定解压缩目标文件夹的路径
        String outputDir = command[1];
        Path outputPath;
        // 判断 outputDir 是否为绝对路径
        if (Paths.get(outputDir).isAbsolute()) {
            outputPath = Paths.get(outputDir).toAbsolutePath(); // 如果是绝对路径，直接使用
        } else {
            outputPath = Paths.get(address, outputDir).toAbsolutePath(); // 否则拼接地址以获得绝对路径
        }
        // 创建输出目录，如果不存在的话
        if (!Files.exists(outputPath)) {
            Files.createDirectories(outputPath);
        }
        // 取得待解压缩的压缩包路径
        String zipFileName = command[2];
        Path zipFilePath = Paths.get(address, zipFileName).toAbsolutePath(); // 拼接获得绝对路径
        // 进行解压缩
        compress.unzip(zipFilePath.toFile(), outputPath.toFile());
        System.out.println(ConsoleColor.colored("解压完成: " + zipFileName, ConsoleColor.RED));
        System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
    }
}
