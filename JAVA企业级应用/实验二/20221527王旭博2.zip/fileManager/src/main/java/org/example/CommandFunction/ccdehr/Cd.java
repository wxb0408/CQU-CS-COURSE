package org.example.CommandFunction.ccdehr;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Cd  implements CommandStatus {
    String address = "c:";
    int status;

    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    @Override
    public void excute(String[] command) {
        int s = CommandStatus.UNDONE;
        //仅有一个cd时，返回当前路径即可
        if(command.length == 1){
            System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
        }
        //要改变路径或者可能出错了
        else if(command.length == 2){
            //改变路径为上一级时
            if(command[1].equals("..")){
                File file = new File(address);//获取当前路径
                if(file.getParent()!=null){//查看其父目录
                    this.address = file.getParent();
                }
                System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                s = CommandStatus.SUCCESS;
            }else if(command[1].equals(".")){//留在本级的操作
                System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                s = CommandStatus.SUCCESS;
            }
            else{
                File file ;
                Path path = Paths.get(command[1]);
                //确保file为绝对路径
                if (!path.isAbsolute()){
                    file = new File(this.address, command[1]);
                }
                else{
                    file = new File(command[1]);//
                }
                    if(file.exists()&&file.isDirectory()){//路径存在且为文件夹
                        this.address = file.getAbsolutePath();
                        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                        s = CommandStatus.SUCCESS;
                    }else{
                        System.out.println(ConsoleColor.colored("没有找到对应路径",ConsoleColor.RED));
                        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                    }
            }
        }
        this.status = s;
    }
    public String getAddress(){
        return this.address;
    }
}
