package org.example.CommandFunction.crypt;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;
import org.example.util.Crypt;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Encrypt implements CommandStatus {
    String address;
    int Status;


    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    //encyrpt 原始文件路径 目标文件路径 模式
    @Override
    public void excute(String[] command) {
        //首先判断指令格式
        if(command.length<4){
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        }else{
            //解析输入指令的各个参数
            String filepath = command[1];
            String targetpath = command[2];
            String mode = command[3];
            // 获取文件后缀
            File originalFile = new File(filepath);
            String originalFileName = originalFile.getName();
            String originalFileExtension = "";

            // 获取原文件的后缀
            int dotIndex = originalFileName.lastIndexOf('.');
            if (dotIndex > 0 && dotIndex < originalFileName.length() - 1) {
                originalFileExtension = originalFileName.substring(dotIndex);
            }
            Scanner sc = new Scanner(System.in);
            System.out.print(ConsoleColor.colored("请输入加密文件名: ", ConsoleColor.GREEN));
            String filename = sc.nextLine();
            String newFileName = filename + originalFileExtension;
            //绝对路径的构建
            File file;
            Path path = Paths.get(filepath);
            if(!path.isAbsolute()){
                file = new File(this.address,filepath);
            }else{
                file = new File(filepath);
            }
            File file1;
            Path path1 = Paths.get(targetpath);
            if(!path1.isAbsolute()){
                file1 = new File(this.address,targetpath);
            }else{
                file1 = new File(targetpath);
            }
            File file2 = new File(file1,newFileName);
            //然后判断文件是否存在
            if(!file.exists()){
                System.out.println(ConsoleColor.colored("未找到指定文件！！", ConsoleColor.RED));
                System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
            }else{
                //进行模式的选择
                if(mode.equals("-1")){
                    Scanner scanner = new Scanner(System.in);
                    System.out.print(ConsoleColor.colored("请输入密钥(16个字符): ", ConsoleColor.GREEN));
                    String secretKey = scanner.nextLine();//获取秘钥
                    // 检查密钥长度
                    if (secretKey.length() != 16) {
                        System.out.println(ConsoleColor.colored("密钥长度必须为16个字符！", ConsoleColor.RED));
                        System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
                    }else{
                        try {
                            Crypt.encryptFile(file.getAbsolutePath(), secretKey,file2.getAbsolutePath());
                            System.out.println(ConsoleColor.colored("文件加密成功！", ConsoleColor.GREEN));
                            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
                        } catch (Exception e) {
                            System.out.println(ConsoleColor.colored("处理文件时发生错误！"+e, ConsoleColor.RED));
                            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
                        }
                    }

                }else if(mode.equals("-2")){
                    try {
                        Crypt.xorEncryptDecryptFile(file.getAbsolutePath(),file2.getAbsolutePath());
                        System.out.println(ConsoleColor.colored("文件加密成功！", ConsoleColor.GREEN));
                        System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
                    } catch (Exception e) {
                        System.out.println(ConsoleColor.colored("处理文件时发生错误！"+e, ConsoleColor.RED));
                        System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
                    }
                }
            }
        }
    }
}
