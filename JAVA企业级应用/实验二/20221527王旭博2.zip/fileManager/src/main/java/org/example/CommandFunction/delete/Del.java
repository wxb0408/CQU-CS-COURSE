package org.example.CommandFunction.delete;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;

import java.io.File;
import java.io.FilenameFilter;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Del implements CommandStatus {
    String address;
    int status;



    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    /**
     * 支持通配符，相对路径，绝对路径，批处理
     * @param command 输入的命令数组
     */
    @Override
    public void excute(String[] command) {
        this.status = CommandStatus.UNDONE;
        if(command.length == 1||command.length == 0){//指令格式错误
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！",ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
        }else{//遍历command后面所有的字符串，一个一个操作，实现批处理
            for(int i = 1;i<command.length;i++){
                String zh = command[i];//存储当前处理的文件
                //针对包含通配符文件的处理
                if(command[i].contains("*")){//对包含通配符的操作
                    File dir = new File(address);
                    String[] filesToDelete = dir.list(new FilenameFilter() {//过滤文件
                        @Override
                        public boolean accept(File dir, String name) {
                            return name.matches(zh.replace("*", ".*"));
                        }
                    });
                    if (filesToDelete != null) {
                        for (String fileName : filesToDelete) {
                            File file = new File(dir, fileName);
                            if (file.delete()) {
                                System.out.println(ConsoleColor.colored("删除文件: " + file.getAbsolutePath() + " 成功",ConsoleColor.RED));
                            } else {
                                System.out.println(ConsoleColor.colored("删除文件: " + file.getAbsolutePath() + " 失败",ConsoleColor.RED));
                            }
                        }
                    } else {
                        System.out.println(ConsoleColor.colored("没有匹配的文件.",ConsoleColor.RED));
                    }
                }
                //针对普通文件的处理
                else{
                    //可以处理完整路径或相对路径
                    Path path = Paths.get(zh);
                    File file;
                    if(!path.isAbsolute()){
                        file = new File(this.address,zh);
                    }
                    else{
                        file = new File(zh);
                    }
                    if(file.exists()){
                        if(file.delete()){
                            //删除文件成功
                            System.out.println(ConsoleColor.colored("删除文件"+zh+"成功",ConsoleColor.RED));
                        }
                        else{
                            System.out.println(ConsoleColor.colored("删除文件"+zh+"失败",ConsoleColor.RED));
                        }
                    }else{
                        System.out.println(ConsoleColor.colored("没有匹配"+zh+"的文件",ConsoleColor.RED));
                    }
                }
            }
            System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
        }
    }
}
