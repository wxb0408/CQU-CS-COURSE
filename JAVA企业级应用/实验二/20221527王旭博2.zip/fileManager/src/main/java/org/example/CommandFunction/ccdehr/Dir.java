package org.example.CommandFunction.ccdehr;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;

public class Dir implements CommandStatus {
    String address;
    int Status;

    @Override
    public void excute(String[] command) {
        excute(command, true); // 最外层调用，设置标志位为 true
    }


    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    //dir <文件夹名> [filter name "er" size ">1000B"] [sort <排序依据>]
    //过滤条件可以叠加，排序不可叠加，默认名称排序
    //dir cmdtest filter name 1 size >30 time >2024-11-03-17:06:03 sort time

    public void excute(String[] command, boolean isOuter) {
        // 不符合命令格式，直接错误返回
        if (command.length < 3) {
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
            return;
        }

        // 初始化文件夹名，过滤条件，排序依据
        String folderName = command[2];
        String filterName = null;// 用于文件名过滤
        String filterSize = null;// 用于文件大小过滤 (格式: >100B, <200B, =150B)
        String filterTime = null;// 用于最后修改时间过滤 (格式: >1622548800000, <1622635200000)
        String filterfType = null;// 用于文件类型的过滤
        String sortBy = "name"; // 默认排序依据为文件名
        String mode = command[1];
        // 解析给定的可选参数（过滤条件，排序条件）
        for (int i = 3; i < command.length; i++) {
            if (command[i].equals("filter") && i + 1 < command.length) {
                i++; // 跳过 filter
                while (i < command.length && !command[i].equals("sort")) {
                    String filterType = command[i];
                    switch (filterType) {
                        case "name":
                            if (i + 1 < command.length) {
                                // 获取过滤名称，去掉引号
                                filterName = command[++i];
                            }
                            break;
                        case "size":
                            if (i + 1 < command.length) {
                                filterSize = command[++i]; // 直接获取大小条件
                            }
                            break;
                        case "time":
                            if (i + 1 < command.length) {
                                filterTime = command[++i]; // 获取时间条件
                            }
                            break;
                        case "type":
                            if (i + 1 < command.length) {
                                filterfType = command[++i]; // 获取时间条件
                            }
                            break;
                        default:
                            // 忽略未知的过滤器类型
                            break;
                    }
                    i++; // 移动到下一个参数
                }
                i--; // 调整以处理下一轮循环中可能的 sort
            } else if (command[i].equals("sort") && i + 1 < command.length) {
                sortBy = command[++i]; // 获取排序依据
            }
        }
        // 确保路径为绝对路径
        File directory;
        Path path = Paths.get(folderName);
        if (!path.isAbsolute()) {
            directory = new File(this.address, folderName);
        } else {
            directory = new File(folderName);
        }
        if (!directory.isDirectory()) {
            System.out.println("指定的路径不是文件夹: " + directory.getAbsolutePath());
            return;
        }
        // 获取文件列表
        File[] files = directory.listFiles();
        if (files == null || files.length == 0) {
            System.out.println("该文件夹是空的.");
            return;
        }

        // 过滤文件名
        if (filterName != null) {
            String finalFilterName = filterName;
            files = Arrays.stream(files)
                    .filter(file -> file.isDirectory() || file.getName().contains(finalFilterName)) // 保留文件夹
                    .toArray(File[]::new);
        }

        // 过滤文件大小
        if (filterSize != null) {
            String finalfilterSize = filterSize;
            files = Arrays.stream(files)
                    .filter(file -> {
                        if (file.isDirectory()) return true; // 保留文件夹

                        long size = file.length();
                        char operator = finalfilterSize.charAt(0);  // 获取比较符号
                        long limit;

                        // 解析 limit 的值
                        String limitString = finalfilterSize.substring(1); // 去掉符号，比如>30 -> 30
                        // 如果 limitString 结尾有 B，去掉它
                        if (limitString.endsWith("B")) {
                            limitString = limitString.substring(0, limitString.length() - 1);
                        }

                        limit = Long.parseLong(limitString); // 转换为 long 类型

                        switch (operator) {
                            case '>':
                                return size > limit;
                            case '<':
                                return size < limit;
                            case '=':
                                return size == limit;
                            default:
                                return true; // 如果没有匹配的操作符，则返回 true
                        }
                    })
                    .toArray(File[]::new);
        }

        // 过滤最后修改时间
        if (filterTime != null) {
            String finalfilterTime = filterTime;
            files = Arrays.stream(files)
                    .filter(file -> {
                        if (file.isDirectory()) return true; // 保留文件夹

                        long lastModified = file.lastModified();
                        char operator = finalfilterTime.charAt(0);

                        // 去掉运算符并解析日期
                        String dateString = finalfilterTime.substring(1).trim(); // 去掉运算符字符
                        long limit;

                        try {
                            // 将日期字符串转换为时间戳，确保格式匹配
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
                            limit = sdf.parse(dateString).getTime(); // 获取对应的时间戳
                        } catch (ParseException e) {
                            e.printStackTrace(); // 处理解析日期时的异常
                            return true; // 如果解析失败，返回 true，表示不过滤
                        }

                        switch (operator) {
                            case '>':
                                return lastModified > limit;
                            case '<':
                                return lastModified < limit;
                            case '=':
                                return lastModified == limit;
                            default:
                                return true; // 如果没有匹配的操作符，则返回 true
                        }
                    })
                    .toArray(File[]::new);
        }

        // 过滤文件类型
        if (filterfType != null) {
            String finalFilterType = filterfType.startsWith(".") ? filterfType : "." + filterfType; // 确保以.开头
            files = Arrays.stream(files)
                    .filter(file -> !file.getName().endsWith(finalFilterType)) //取反条件，过滤掉指定类型的文件
                    .toArray(File[]::new);
        }


        // 排序
        switch (sortBy.toLowerCase()) {
            case "size":
                Arrays.sort(files, Comparator.comparingLong(File::length)
                        .thenComparing(file -> file.isDirectory() ? 1 : 0)); // 文件夹排到最后
                break;
            case "time":
                Arrays.sort(files, Comparator.comparingLong(File::lastModified)
                        .thenComparing(file -> file.isDirectory() ? 1 : 0)); // 文件夹排到最后
                break;
            case "name":
            default:
                Arrays.sort(files, Comparator.comparing(File::getName)
                        .thenComparing(file -> file.isDirectory() ? 1 : 0)); // 文件夹排到最后
                break;
        }

        int fileTypeWidth = 10; // 文件类型宽度
        int fileNameWidth = 50; // 文件名宽度
        int fileSizeWidth = 20; // 文件大小宽度
        int lastModifiedWidth = 20; // 最后修改时间宽度
        //dir Downloads filter size >3000 sort size
        // 输出文件信息
        System.out.println(ConsoleColor.colored(directory+"",ConsoleColor.BLUE));
        for (File file : files) {
            String fileType = file.isDirectory() ? "[文件夹]" : "[文件]";
            long fileSize = file.isDirectory() ? 0 : file.length();
            String lastModified = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                    .format(file.lastModified());
            // 格式化输出，使用一定的宽度对齐
            if(fileType.equals("[文件]")) {
                System.out.printf("%-" + fileTypeWidth + "s\t %-" + fileNameWidth + "s\t %-" + fileSizeWidth + "s\t"+"最后修改时间: %-" + lastModifiedWidth + "s\t%n",
                        fileType, file.getName(), fileSize+"  bytes", lastModified);
            }
            if(fileType.equals("[文件夹]")&&mode.equals("all")){
                String[] command1 = command;
                command1[2] = file.getAbsolutePath();
                this.excute(command1,false);
            }
        }

        // 提示符
        if(isOuter) {
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        }else{
            System.out.println(ConsoleColor.colored("---------------------------------------------------------------------------------------------------------", ConsoleColor.GREEN));
        }
    }
}
