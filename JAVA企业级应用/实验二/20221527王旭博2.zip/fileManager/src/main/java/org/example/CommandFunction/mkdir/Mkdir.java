package org.example.CommandFunction.mkdir;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Mkdir implements CommandStatus {
    //接收目前所处于的目录，为后续操作提供相应路径
    String address;
    //记录该条命令的执行状态
    int status;
    //构造函数，初始化当前目录

    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    @Override
    public void excute(String[] command) {
        this.status = CommandStatus.UNDONE;
        if(command.length == 2){
            //一、拼接路径
            String str = command[1];//除指令外的完整内容
            String filename;//找到要创建的文件
            File file = null;
            if(str.contains("\\")){
                //得到完整的文件名
                filename = str.substring(str.lastIndexOf("\\"));
                file = new File(str);
            }else{//没有路径，需要拼接
                filename = str;
                file = new File(this.address+"\\"+str);
            }
            //二、检查文件是否存在
            if(file.exists()){
                System.out.print("已经存在"+filename+"文件，是否替换？[y/n]");
                Scanner scanner = new Scanner(System.in);
                String command1 = scanner.next();
                if(command1.equals("y")){
                    file.delete();//删除文件
                    try{
                        file.createNewFile();
                        System.out.println(ConsoleColor.colored("文件替换成功",ConsoleColor.RED));
                        System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                        this.status = CommandStatus.SUCCESS;
                    }catch(IOException e){
                        e.printStackTrace();
                    }
                }else{
                    System.out.println(ConsoleColor.colored("操作取消",ConsoleColor.RED));
                    System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                    this.status = CommandStatus.SUCCESS;
                }
            }else{
                try {
                    file.createNewFile();
                    file.mkdir();
                    System.out.println(ConsoleColor.colored("文件创建成功",ConsoleColor.RED));
                    System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                }catch(IOException e){
                    e.printStackTrace();
                }
            }
        }else{
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！",ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
        }
    }
}
