package org.example.CommandFunction.delete;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Stack;

public class Rmdir implements CommandStatus {
    String address;
    int Status;


    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    //rmdir
    @Override
    public void excute(String[] command) {
        if(command.length<2){
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        }else{
            //拼成绝对路径
            File directory;
            Path path = Paths.get(command[1]);
            if(path.isAbsolute()){
                directory = new File(command[1]);
            }else{
                directory = new File(this.address,command[1]);
            }
            //使用栈结构进行文件夹的删除
            // 检查目标是否是目录
            if (!directory.exists()) {
                System.out.println(ConsoleColor.colored("指定的路径不存在: " + directory.getAbsolutePath(),ConsoleColor.RED));
                return;
            }

            if (!directory.isDirectory()) {
                System.out.println(ConsoleColor.colored("指定的路径不是文件夹: " + directory.getAbsolutePath(),ConsoleColor.RED));
                return;
            }

            // 使用栈结构进行文件夹的删除
            Stack<File> stack = new Stack<>();
            stack.push(directory);

            while (!stack.isEmpty()) {
                File currentFile = stack.peek();
                // 获取当前目录下的所有文件和文件夹
                File[] files = currentFile.listFiles();
                if (files != null) {
                    for (File file : files) {
                        // 如果是文件夹，先压入栈中
                        if (file.isDirectory()) {
                            stack.push(file);
                        } else {
                            // 删除文件
                            if (file.delete()) {
                                System.out.println(ConsoleColor.colored("已删除文件: " + file.getAbsolutePath(),ConsoleColor.RED));
                            }
                        }
                    }
                }

                // 删除当前文件夹
                if (stack.peek().delete()) {
                    stack.pop();
                    System.out.println(ConsoleColor.colored("已删除文件夹: " + currentFile.getAbsolutePath(), ConsoleColor.RED));
                }
            }
            if(!stack.empty()) {
                if (directory.delete()) {
                    System.out.println(ConsoleColor.colored("已删除文件夹: " + directory.getAbsolutePath(), ConsoleColor.RED));
                } else {
                    System.out.println(ConsoleColor.colored("无法删除文件夹: " + directory.getAbsolutePath(), ConsoleColor.RED));
                }
            }

            // 完成后打印提示符
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        }
    }
}
