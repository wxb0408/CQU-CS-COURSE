package org.example.util;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Crypt {
    //原始文件路径 秘钥 目标路径
    public static void encryptFile(String filePath, String secretKey, String outputFilePath) throws Exception {
        // 生成密钥
        SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(), "AES");
        // 创建加密器
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, keySpec);
        // 读取源文件
        File inputFile = new File(filePath);
        byte[] inputFileBytes = new byte[(int) inputFile.length()];
        FileInputStream fileInputStream = new FileInputStream(inputFile);
        fileInputStream.read(inputFileBytes);
        fileInputStream.close();
        // 执行加密
        byte[] encryptedBytes = cipher.doFinal(inputFileBytes);
        // 将加密后的内容写入新的文件
        FileOutputStream fileOutputStream = new FileOutputStream(outputFilePath);
        fileOutputStream.write(encryptedBytes);
        fileOutputStream.close();
    }

    // 解密文件
    public static void decryptFile(String filePath, String secretKey, String outputFilePath) throws Exception {
        // 生成密钥
        SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(), "AES");

        // 创建解密器
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, keySpec);

        // 读取加密文件
        File inputFile = new File(filePath);
        byte[] encryptedFileBytes = new byte[(int) inputFile.length()];
        FileInputStream fileInputStream = new FileInputStream(inputFile);
        fileInputStream.read(encryptedFileBytes);
        fileInputStream.close();

        // 执行解密
        byte[] decryptedBytes = cipher.doFinal(encryptedFileBytes);

        // 将解密后的内容写入新的文件
        FileOutputStream fileOutputStream = new FileOutputStream(outputFilePath);
        fileOutputStream.write(decryptedBytes);
        fileOutputStream.close();
    }

    //异或的加密与解密
    public static void xorEncryptDecryptFile(String filePath, String outputFilePath) throws Exception {
        // 读取源文件
        File inputFile = new File(filePath);
        byte[] fileBytes = new byte[(int) inputFile.length()];
        FileInputStream fileInputStream = new FileInputStream(inputFile);
        fileInputStream.read(fileBytes);
        fileInputStream.close();

        // 使用一个简单的固定的异或值进行加密解密
        byte xorValue = 0x5A; // 一个简单的字节值作为异或的依据
        for (int i = 0; i < fileBytes.length; i++) {
            fileBytes[i] ^= xorValue; // 异或操作
        }

        // 将处理后的内容写入新的文件
        FileOutputStream fileOutputStream = new FileOutputStream(outputFilePath);
        fileOutputStream.write(fileBytes);
        fileOutputStream.close();
    }
}
