package org.example.CommandFunction.ccdehr;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;

import java.io.File;
import java.nio.file.Paths;

public class Rename implements CommandStatus {
    String address;
    int status;

    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    @Override
    public void excute(String[] command) {
        if(command.length<3){
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！",ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
        }else{
            String oldname = command[1];//获取旧文件名
            String newname = command[2];//获取新文件名
            File oldfile = new File(this.address,oldname);
            File newfile = new File(this.address,newname);
            if(oldfile.exists()){
                if(oldfile.renameTo(newfile)){
                    System.out.println(ConsoleColor.colored("文件"+oldname+"重命名为"+newname,ConsoleColor.RED));
                    System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                }else{
                    System.out.println(ConsoleColor.colored("文件"+oldname+"重命名失败",ConsoleColor.RED));
                    System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
                }
            }else{
                System.out.println(ConsoleColor.colored("未找到文件"+oldname,ConsoleColor.RED));
                System.out.print(ConsoleColor.colored(this.address+">",ConsoleColor.GREEN));
            }

        }
    }
}
