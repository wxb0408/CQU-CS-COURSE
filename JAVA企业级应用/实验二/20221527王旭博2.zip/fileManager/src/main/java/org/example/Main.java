package org.example;

import org.example.Menu.MenuController;

public class Main {
    public static void main(String[] args) {
        MenuController menuController = new MenuController();
        menuController.mainMenu();
    }
}