package org.example.util;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class compress {
    public static void zipFile(File fileToZip, ZipOutputStream zipOut, String basePath) throws IOException {
        try (FileInputStream fis = new FileInputStream(fileToZip)) {
            // 使用basePath和文件名组合为ZipEntry名称
            ZipEntry zipEntry = new ZipEntry(basePath + fileToZip.getName());
            zipOut.putNextEntry(zipEntry);
            byte[] bytes = new byte[1024];
            int length;
            while ((length = fis.read(bytes)) >= 0) {
                zipOut.write(bytes, 0, length);
            }
            zipOut.closeEntry();
        }
    }

    // 压缩文件夹
    public static void zipDirectory(File folderToZip, ZipOutputStream zipOut, String basePath) throws IOException {
        File[] files = folderToZip.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    // 递归调用zipDirectory，更新basePath以包含当前文件夹名称
                    zipDirectory(file, zipOut, basePath + file.getName() + "/");
                } else {
                    // 在这里调用zipFile时传递basePath
                    zipFile(file, zipOut, basePath);
                }
            }
        }
    }

    public static void unzip(File zipFile, File destDir) throws IOException {
        try (ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry entry;
            while ((entry = zipIn.getNextEntry()) != null) {
                File outputFile = new File(destDir, entry.getName());
                if (entry.isDirectory()) {
                    // 创建目录
                    if (!outputFile.exists()) {
                        outputFile.mkdirs();
                    }
                } else {
                    // 确保父目录存在
                    new File(outputFile.getParent()).mkdirs();
                    // 写入文件
                    try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(outputFile))) {
                        byte[] bytesIn = new byte[1024];
                        int read;
                        while ((read = zipIn.read(bytesIn)) != -1) {
                            bos.write(bytesIn, 0, read);
                        }
                    }
                }
                zipIn.closeEntry();
            }
        }
    }
}
