package org.example.CommandFunction.copy;

import org.example.util.CommandStatus;
import org.example.util.ConsoleColor;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;

public class Copy implements CommandStatus {
    String address;
    int status;
    private long copiedBytes = 0; // 用于记录已复制的字节数
    private volatile boolean copying = true; // 用于控制进度条线程



    @Override
    public void updateAddress(String newAddress) {
        this.address = newAddress;
    }

    // copy -F/B target source
    @Override
    public void excute(String[] command) {
        // 判断指令的格式是否正确
        if (command.length < 4) {
            System.out.println(ConsoleColor.colored("命令格式错误，输入help查看具体实现！", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
            return;
        }
        // 获取文件目标地址
        String destinationPath = command[2];
        // 获取要复制的文件（支持批量处理）
        String[] filesToCopy = Arrays.copyOfRange(command, 3, command.length);
        // 检查是前台执行还是后台执行
        String mode = command[1];
        if (mode.equals("-F")) {
            // 前台执行
            copyFilesInForeground(destinationPath, filesToCopy);
        } else {
            // 后台执行，将当前进程设置为一个全新的进程
            new Thread(() -> copyFilesInBackground(destinationPath, filesToCopy)).start();
            System.out.println(ConsoleColor.colored("拷贝任务已在后台启动", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        }
    }

    // 前台拷贝
    private void copyFilesInForeground(String destinationPath, String[] filesToCopy) {
        long startTime = System.currentTimeMillis(); // 记录拷贝的开始时间
        long totalBytes = calculateTotalBytes(filesToCopy); // 记录需要拷贝的总字节数
        copiedBytes = 0; // 本地拷贝的字节数
        copying = true; // 设置为 true，表示拷贝开始

        // 创建一个新的线程来显示进度条
        Thread progressThread = new Thread(() -> {
            while (copying) {
                displayProgressBar(copiedBytes, totalBytes);
                try {
                    Thread.sleep(1); // 每隔500毫秒更新一次
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            // 拷贝完成后显示总耗时
            long totalTime = System.currentTimeMillis() - startTime;
            System.out.println("\n拷贝完成，总耗时: " + (totalTime) + "ms");
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        });
        progressThread.start();

        try {
            for (String file : filesToCopy) {
                //通配符的检查
                if (file.contains("*")) {
                    String filePattern = file.replace("*", "");
                    File directory = new File(address);
                    File[] matchedFiles = directory.listFiles((dir, name) -> name.startsWith(filePattern));

                    if (matchedFiles != null) {
                        for (File matchedFile : matchedFiles) {
                            copiedBytes += copyFileWithProgress(matchedFile.toPath(), Paths.get(destinationPath, matchedFile.getName()));
                        }
                    }
                } else {
                    //一定绝对路径的构建
                    File file1;
                    Path path = Paths.get(file);
                    if (path.isAbsolute()) {
                        file1 = new File(file);
                    } else {
                        file1 = new File(this.address, file);
                    }
                    File sourceFile = file1;
                    if (!sourceFile.exists()) {
                        System.out.println(ConsoleColor.colored("文件 " + sourceFile + " 不存在", ConsoleColor.RED));
                    } else {
                        copiedBytes += copyFileWithProgress(sourceFile.toPath(), Paths.get(destinationPath, sourceFile.getName()));

                    }
                }
            }
            displayProgressBar(100, 100);
        } catch (IOException e) {
            System.out.println(ConsoleColor.colored("拷贝失败", ConsoleColor.RED));
        } finally {
            copying = false; // 设置为 false，结束进度条线程
            progressThread.interrupt(); // 中断进度条线程
        }
    }

    // 后台拷贝
    private void copyFilesInBackground(String destinationPath, String[] filesToCopy) {
        long startTime = System.currentTimeMillis();
        long totalBytes = calculateTotalBytes(filesToCopy);
        long copiedBytes = 0;

        try {
            //检查每一个文件
            for (String file : filesToCopy) {
                //绝对路径的构建
                File file1;
                Path path = Paths.get(file);
                if (path.isAbsolute()) {
                    file1 = new File(file);
                } else {
                    file1 = new File(this.address, file);
                }
                File sourceFile = file1;
                //通配符的检查
                if (file.contains("*")) {
                    String filePattern = file.replace("*", "");
                    File directory = new File(address);
                    File[] matchedFiles = directory.listFiles((dir, name) -> name.startsWith(filePattern));

                    if (matchedFiles != null) {
                        for (File matchedFile : matchedFiles) {
                            copiedBytes += copyFileWithProgress(matchedFile.toPath(), Paths.get(destinationPath, matchedFile.getName()));
                        }
                    }
                } else {
                    if (!sourceFile.exists()) {
                        System.out.println(ConsoleColor.colored("文件 " + sourceFile + " 不存在", ConsoleColor.RED));
                        continue;
                    } else {
                        copyFile(sourceFile.toPath(), Paths.get(destinationPath, sourceFile.getName()));
                    }
                }
            }
            long endTime = System.currentTimeMillis();
            System.out.println();
            System.out.println(ConsoleColor.colored("拷贝完成, 总耗时: " + (endTime - startTime) + " 毫秒", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        } catch (IOException e) {
            System.out.println(ConsoleColor.colored("拷贝失败", ConsoleColor.RED));
            System.out.print(ConsoleColor.colored(this.address + ">", ConsoleColor.GREEN));
        }
    }

    private long copyFileWithProgress(Path source, Path destination) throws IOException {
        try (InputStream in = Files.newInputStream(source);
             OutputStream out = Files.newOutputStream(destination)) {
            byte[] buffer = new byte[1024]; // 1KB buffer
            long totalBytesCopied = 0;
            int bytesRead;

            long lastReportedProgress = 0; // 记录上一次更新的进度
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
                totalBytesCopied += bytesRead;
                copiedBytes += bytesRead;

                // 每当复制达到2%的进度时更新进度条
                long currentProgress = (copiedBytes * 100) / calculateTotalBytes(new String[]{source.toString()});
                if (currentProgress >= lastReportedProgress + 2) {
                    lastReportedProgress += 2; // 更新上次报告的进度
                    displayProgressBar(copiedBytes, calculateTotalBytes(new String[]{source.toString()}));
                }
            }
            return totalBytesCopied;
        }
    }

    private void copyFile(Path source, Path destination) throws IOException {
        try (InputStream in = Files.newInputStream(source);
             OutputStream out = Files.newOutputStream(destination)) {
            byte[] buffer = new byte[1024]; // 1KB buffer
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }
    }

    // 计算给定的所有文件的总字节数
    private long calculateTotalBytes(String[] filesToCopy) {
        long totalBytes = 0;
        for (String file : filesToCopy) {
            File file1;
            Path path = Paths.get(file);
            if (path.isAbsolute()) {
                file1 = new File(file);
            } else {
                file1 = new File(this.address, file);
            }
            File sourceFile = file1;
            if (sourceFile.exists()) {
                totalBytes += sourceFile.length();
            } else if (file.contains("*")) { // 通配符的判断
                String filePattern = file.replace("*", "");
                File directory = new File(address); // 只拿到当前所在的目录
                File[] matchedFiles = directory.listFiles((dir, name) -> name.startsWith(filePattern)); // 正则表达式判断通配符包含的文件
                if (matchedFiles != null) {
                    for (File matchedFile : matchedFiles) {
                        totalBytes += matchedFile.length(); // 计算对应字节数
                    }
                }
            }
        }
        return totalBytes;
    }

    // 绘制进度条
    private void displayProgressBar(long copiedBytes, long totalBytes) {
        int percent = (int) ((copiedBytes * 100) / totalBytes);
        int barLength = 50; // 进度条长度
        int progressLength = (percent * barLength) / 100;

        StringBuilder progressBar = new StringBuilder("[");
        for (int i = 0; i < barLength; i++) {
            if (i < progressLength) {
                progressBar.append('#');
            } else {
                progressBar.append(' ');
            }
        }
        progressBar.append("] ").append(percent).append("%");

        System.out.print("\r" + progressBar.toString());
    }
}
