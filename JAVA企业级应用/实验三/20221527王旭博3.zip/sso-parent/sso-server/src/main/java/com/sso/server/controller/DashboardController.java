package com.sso.server.controller;

import com.sso.server.service.UserService;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.sso.server.model.User;
import com.sso.server.service.TokenService;

/**
 * 处理管理员的后台首页请求
 */
public class DashboardController extends HttpServlet {
    private UserService userService;
    private TokenService tokenService;

    /**
     * 获取一些必要的服务
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        userService = (UserService) getServletContext().getAttribute("userService");
        tokenService = (TokenService) getServletContext().getAttribute("tokenService");
    }

    /**
     * 展示后台首页数据
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // 验证用户是否已登录
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            if (currentUser == null) {
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }
            // 获取统计数据
            Map<String, Object> stats = userService.getUserStatistics();
            request.setAttribute("stats", stats);
            // 获取最近登录记录
            List<Map<String, Object>> recentLogins = userService.getRecentLogins(5);
            request.setAttribute("recentLogins", recentLogins);
            // 获取在线用户
            List<Map<String, Object>> activeUsers = userService.getActiveUsers();
            request.setAttribute("activeUsers", activeUsers);
            // 转发到首页
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }

}