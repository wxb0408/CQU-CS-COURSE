package com.sso.server.util;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import com.sso.server.model.User;

/**
 * 用户会话令牌管理类
 */
public class TokenManager {
    //单例模式
    private static final TokenManager instance = new TokenManager();
    private final Map<String, TokenInfo> tokenStore = new ConcurrentHashMap<>();

    private TokenManager() {}

    public static TokenManager getInstance() {
        return instance;
    }

    /**
     * 为指定用户生成令牌
     * @param user
     * @return
     */
    public String generateToken(User user) {
        String token = UUID.randomUUID().toString();
        tokenStore.put(token, new TokenInfo(user, System.currentTimeMillis()));
        return token;
    }

    /**
     * 验证令牌是否有效
     * @param token
     * @return
     */
    public boolean validateToken(String token) {
        return token != null && tokenStore.containsKey(token);
    }

    /**
     * 根据令牌获取相关用户信息
     * @param token
     * @return
     */
    public User getUserByToken(String token) {
        TokenInfo info = tokenStore.get(token);
        return info != null ? info.getUser() : null;
    }

    /**
     * 移除指定令牌
     * @param token
     */
    public void removeToken(String token) {
        tokenStore.remove(token);
    }

    /**
     * 内部类，存储令牌的相关信息
     */
    private static class TokenInfo {
        private final User user;//用户对象
        private final long timestamp;//获取令牌时的时间戳

        /**
         * 构造函数初始化令牌信息
         * @param user
         * @param timestamp
         */
        public TokenInfo(User user, long timestamp) {
            this.user = user;
            this.timestamp = timestamp;
        }

        /**
         * 获取用户
         * @return
         */
        public User getUser() {
            return user;
        }

        public long getTimestamp() {
            return timestamp;
        }
    }
}
