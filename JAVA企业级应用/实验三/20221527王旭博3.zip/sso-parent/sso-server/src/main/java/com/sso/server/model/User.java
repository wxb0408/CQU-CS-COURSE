package com.sso.server.model;

import lombok.Data;

import java.util.Date;

/**
 * 用户实体类
 */
@Data
public class User {
    private Long id;//用户id
    private String username;//用户名称
    private String password;//用户密码
    private boolean enabled;//用户的状态（表示用户是否被启动或禁用）
    private Date createTime;//用户创建时间

    public User() {}

    public User(Long id, String username, String password, boolean enabled, Date createTime) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.enabled = enabled;
        this.createTime = createTime;
    }
}