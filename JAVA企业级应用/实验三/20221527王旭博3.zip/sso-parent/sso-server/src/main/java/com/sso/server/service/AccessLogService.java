package com.sso.server.service;

import com.sso.server.dao.AccessLogDAO;
import com.sso.server.model.AccessLog;
import com.sso.server.model.LoginRecord;

import javax.servlet.http.HttpServletRequest;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 对日志操作的具体逻辑
 */
public class AccessLogService {
    //创建数据库操作类的实例
    private final AccessLogDAO accessLogDAO;

    //初始化日志操作对象
    public AccessLogService(AccessLogDAO accessLogDAO) {
        this.accessLogDAO = accessLogDAO;
    }

    /**
     * 记录访问日志
     * @param request
     * @param userId
     * @param username
     * @param actionType
     * @param status
     * @param details
     */
    public void logAccess(HttpServletRequest request, Long userId, String username,
                          String actionType, String status, String details) {
        try {
            AccessLog log = new AccessLog();
            log.setUserId(userId);
            log.setUsername(username);
            log.setActionType(actionType);
            log.setRequestUrl(request.getRequestURI());
            log.setClientIp(getClientIp(request));
            log.setUserAgent(request.getHeader("User-Agent"));
            log.setAccessTime(new Date());
            log.setStatus(status);
            log.setDetails(details);

            accessLogDAO.save(log);
        } catch (SQLException e) {
            // 记录错误日志
            e.printStackTrace();
        }
    }

    /**
     * 获取指定用户的访问日志
     * @param userId
     * @return
     */
    public List<LoginRecord> getUserLogs(Long userId) {
        try {
            return accessLogDAO.findByUserId(userId);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    /**
     * 获取分页系统的日志
     * @param page
     * @param pageSize
     * @return
     */
    public List<AccessLog> getSystemLogs(int page, int pageSize) {
        try {
            int offset = (page - 1) * pageSize;
            return accessLogDAO.findAll(pageSize, offset);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    /**
     * 获取访问日志的总记录数
     * @return
     */
    public int getTotalLogsCount() {
        try {
            return accessLogDAO.getTotalCount();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 获取客户端的ip地址
     * @param request
     * @return
     */
    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }
}