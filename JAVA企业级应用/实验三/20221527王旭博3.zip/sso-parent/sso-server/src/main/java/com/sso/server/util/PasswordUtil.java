package com.sso.server.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

/**
 * 用户密码管理类
 */
public class PasswordUtil {
    /**
     * 使用SHA-256对密码进行加密处理
     * @param password
     * @return
     */
    public static String encrypt(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error encrypting password", e);
        }
    }

    /**
     * 密码验证功能
     * @param password
     * @param storedHash
     * @return
     */
    public static boolean verify(String password, String storedHash) {
        String newHash = encrypt(password);
        return newHash.equals(storedHash);
    }
}
