package com.sso.server.controller;

import com.sso.server.model.User;
import com.sso.server.service.TokenService;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 处理用户信息请求
 */
public class UserInfoController extends HttpServlet {
    private TokenService tokenService;
    private ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 初始化获取必要的服务
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        tokenService = (TokenService) getServletContext().getAttribute("tokenService");
    }

    /**
     * 根据token获取用户信息返回json数据
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String token = request.getParameter("token");
        User user = tokenService.getUserByToken(token);

        if (user != null) {
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            objectMapper.writeValue(response.getWriter(), user);
        } else {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        }
    }
}
