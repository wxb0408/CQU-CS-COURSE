package com.sso.server.listener;

import javax.servlet.http.HttpSessionListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSession;

/**
 * 会话监听
 */
public class SessionListener implements HttpSessionListener {

    /**
     * 会话创建并设定5分钟会话超时时间
     * @param se
     */
    @Override
    public void sessionCreated(HttpSessionEvent se) {
        HttpSession session = se.getSession();
        System.out.println("会话创建，Session ID: " + session.getId());
        // 设置会话超时时间（例如 5 分钟）
        session.setMaxInactiveInterval(5 * 60); // 30分钟
        session.setAttribute("sessionStartTime", System.currentTimeMillis()); // 记录会话开始时间
    }

    /**
     * 销毁会话的处理逻辑
     * @param se
     */
    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        HttpSession session = se.getSession();
        System.out.println("会话销毁，Session ID: " + session.getId());
        Object sessionStartTime = session.getAttribute("sessionStartTime");
        if (sessionStartTime != null) {
            long sessionDuration = System.currentTimeMillis() - (long) sessionStartTime;
            System.out.println("会话持续时间: " + sessionDuration + " 毫秒");
        }
        session.removeAttribute("sessionStartTime");
    }
}