package com.sso.server.controller;

import com.sso.server.model.User;
import com.sso.server.service.UserService;
import com.sso.server.service.TokenService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;


/**
 * 处理登录请求
 */
public class LoginController extends HttpServlet {
    private UserService userService;
    private TokenService tokenService;

    /**
     * 获取必要的服务
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        // 初始化服务
        userService = (UserService) getServletContext().getAttribute("userService");
        tokenService = (TokenService) getServletContext().getAttribute("tokenService");
    }

    /**
     * 处理get请求，展示登录界面
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String redirect = request.getParameter("redirect");
        if (redirect != null) {
            request.getSession().setAttribute("redirect", redirect);
        }
        //重定向登录界面
        request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
    }

    /**
     * 处理post请求，进行用户登录验证
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Map<String, Object>> activeLogins;
        try {
            activeLogins = userService.getActiveLogins(); // 获取所有活跃用户的登录信息
        } catch (SQLException e) {
            throw new ServletException("Error retrieving active logins", e);
        }

        // 检查用户是否已经在活跃用户列表中
        String username1 = request.getParameter("username");

        boolean isUserActive = activeLogins.stream()
                .anyMatch(login -> login.get("username").equals(username1));


        if(isUserActive){
            request.setAttribute("error", "Current user has been login");
            request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
        }
        String username = request.getParameter("username");
        String password = request.getParameter("password");


        try {
            User user = userService.authenticate(username, password);
            if (user != null) {
                // 生成token并保存用户会话
                String token = tokenService.generateToken(user, response, request);
                // 记录登录
                userService.recordLogin(user.getId(), "sso-server");
                String redirect = request.getParameter("redirect");
                if (redirect != null && !redirect.trim().isEmpty()) {
                    response.sendRedirect(redirect + "?token=" + token);
                } else {
                    response.sendRedirect("dashboard");
                }
            } else {
                request.setAttribute("error", "Invalid username or password");
                request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }
}