package com.sso.server.service;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.sso.server.model.User;
import com.sso.server.util.TokenManager;

/**
 * 管理单点登录系统中
 */
public class TokenService {
    //在cookie中存储token的名称
    private static final String TOKEN_COOKIE_NAME = "sso_token";
    //实例化token的管理对象
    private final TokenManager tokenManager;

    //初始化token对象
    public TokenService() {
        this.tokenManager = TokenManager.getInstance();
    }

    /**
     * 为用户生成token并存储在会话和cookie当中
     * @param user
     * @param response
     * @param request
     * @return
     */
    public String generateToken(User user, HttpServletResponse response, HttpServletRequest request) {
        String token = tokenManager.generateToken(user);
        addTokenCookie(token, response);
        // 在会话中保存用户信息
        request.getSession().setAttribute("user", user);
        return token;
    }

    /**
     * 验证token是否有效
     * @param token
     * @return
     */
    public boolean validateToken(String token) {
        return tokenManager.validateToken(token);
    }

    /**
     * 根据token获取对应的用户信息
     * @param token
     * @return
     */
    public User getUserByToken(String token) {
        return tokenManager.getUserByToken(token);
    }

    /**
     * 移除指定的token，同时删除cookie信息
     * @param token
     * @param response
     */
    public void removeToken(String token, HttpServletResponse response) {
        tokenManager.removeToken(token);
        removeTokenCookie(response);
    }

    /**
     * 将Token添加到HTTP响应的Cookie中
     * @param token
     * @param response
     */
    private void addTokenCookie(String token, HttpServletResponse response) {
        Cookie cookie = new Cookie(TOKEN_COOKIE_NAME, token);
        cookie.setPath("/");
        cookie.setHttpOnly(true);
        cookie.setMaxAge(3600); // 1小时过期
        response.addCookie(cookie);
    }

    /**
     *移除指定Token，同时删除Cookie并清空会话信息
     * @param token
     * @param response
     * @param request
     */
    public void removeToken(String token, HttpServletResponse response, HttpServletRequest request) {
        if (token != null) {
            tokenManager.removeToken(token);
        }
        removeTokenCookie(response);
        // 清除会话中的用户信息
        request.getSession().removeAttribute("user");
        request.getSession().invalidate();
    }

    /**
     * 移除token的cookie
     * @param response
     */
    private void removeTokenCookie(HttpServletResponse response) {
        Cookie cookie = new Cookie(TOKEN_COOKIE_NAME, "");
        cookie.setPath("/");
        cookie.setHttpOnly(true);
        cookie.setMaxAge(0);
        response.addCookie(cookie);
    }

    /**
     * 从http响应中提取token
     * @param request
     * @return
     */
    public String getTokenFromCookies(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (TOKEN_COOKIE_NAME.equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
}