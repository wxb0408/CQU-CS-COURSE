package com.sso.server.dao;

import com.sso.server.model.AccessLog;
import com.sso.server.model.LoginRecord;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/**
 * 管理访问日志数据。
 * 保存日志、按用户ID查询日志、查询所有日志、统计日志总数
 */
public class AccessLogDAO {
    private DataSource dataSource;
    private LoginRecordDAO loginRecordDAO;

    /**
     * 获取数据源
     * @param dataSource
     */
    public AccessLogDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * 获取数据库中存储的所有访问日志的总数
     * @return
     * @throws SQLException
     */
    public int getTotalCount() throws SQLException {
        //编写sql语句
        String sql = "SELECT COUNT(*) FROM access_logs";
        //从数据源获取数据库的连接
        try (Connection conn = dataSource.getConnection();
             //创建statement对象，用于执行sql语句
             Statement stmt = conn.createStatement();
             //获取sql语句的执行结果
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
        }
    }

    /**
     * 将访问日志实例保存到数据库
     * @param log
     * @throws SQLException
     */
    public void save(AccessLog log) throws SQLException {
        String sql = "INSERT INTO access_logs (user_id, username, action_type, request_url, client_ip, " +
                "user_agent, access_time, status, details) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setObject(1, log.getUserId());
            ps.setString(2, log.getUsername());
            ps.setString(3, log.getActionType());
            ps.setString(4, log.getRequestUrl());
            ps.setString(5, log.getClientIp());
            ps.setString(6, log.getUserAgent());
            ps.setTimestamp(7, new Timestamp(log.getAccessTime().getTime()));
            ps.setString(8, log.getStatus());
            ps.setString(9, log.getDetails());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                log.setId(rs.getLong(1));
            }
        }
    }

    /**
     * 根据用户id查询访问日志
     * @param userId
     * @return
     * @throws SQLException
     */
    public List<LoginRecord> findByUserId(Long userId) throws SQLException {
        List<LoginRecord> logs = new ArrayList<>();
        String sql = "SELECT * FROM login_records WHERE user_id = ? ORDER BY login_time DESC";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                logs.add(loginRecordDAO.mapLoginRecord(rs));
            }
        }
        return logs;
    }

    /**
     * 分页查询访问日志
     * @param limit
     * @param offset
     * @return
     * @throws SQLException
     */
    public List<AccessLog> findAll(int limit, int offset) throws SQLException {
        List<AccessLog> logs = new ArrayList<>();
        String sql = "SELECT * FROM access_logs ORDER BY access_time DESC LIMIT ? OFFSET ?";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, limit);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                logs.add(mapAccessLog(rs));
            }
        }
        return logs;
    }

    /**
     * 将数据库的查询结果映射为AccessLog对象
     * @param rs
     * @return
     * @throws SQLException
     */
    private AccessLog mapAccessLog(ResultSet rs) throws SQLException {
        AccessLog log = new AccessLog();
        log.setId(rs.getLong("id"));
        log.setUserId(rs.getObject("user_id", Long.class));
        log.setUsername(rs.getString("username"));
        log.setActionType(rs.getString("action_type"));
        log.setRequestUrl(rs.getString("request_url"));
        log.setClientIp(rs.getString("client_ip"));
        log.setUserAgent(rs.getString("user_agent"));
        log.setAccessTime(new Date(rs.getTimestamp("access_time").getTime()));
        log.setStatus(rs.getString("status"));
        log.setDetails(rs.getString("details"));
        return log;
    }
}