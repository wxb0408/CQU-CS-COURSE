package com.sso.server.model;

import lombok.Data;

import java.util.Date;

/**
 * 登录记录实体类
 */
@Data
public class LoginRecord {
    private Long id;//编号
    private Long userId;//用户id
    private String systemName;//系统名称
    private Date loginTime;//登录时间
    private Date logoutTime;//登出时间
    public LoginRecord(){}

    public LoginRecord(Long id, Long userId, String systemName, Date loginTime, Date logoutTime) {
        this.id = id;
        this.userId = userId;
        this.systemName = systemName;
        this.loginTime = loginTime;
        this.logoutTime = logoutTime;
    }
}