package com.sso.server.controller;

import com.sso.server.service.TokenService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 验证请求中的token是否有效
 */
public class ValidateController extends HttpServlet {
    private TokenService tokenService;

    /**
     * 初始化获取需要的服务
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        tokenService = (TokenService) getServletContext().getAttribute("tokenService");
    }

    /**
     * 判断给定的token是否有效
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String token = request.getParameter("token");
        if (token != null && tokenService.validateToken(token)) {
            response.setStatus(HttpServletResponse.SC_OK);
        } else {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        }
    }
}