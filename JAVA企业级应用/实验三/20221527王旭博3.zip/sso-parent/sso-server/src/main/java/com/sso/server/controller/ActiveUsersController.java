package com.sso.server.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sso.server.service.UserService;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 管理活跃用户的数据。
 */
public class ActiveUsersController extends HttpServlet {
    private UserService userService;
    private ObjectMapper objectMapper;

    /**
     * 初始化 Servlet。
     * 从 Servlet 上下文中获取 {@code UserService} 实例，
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        userService = (UserService) getServletContext().getAttribute("userService");
        objectMapper = new ObjectMapper();
    }

    /**
     * 处理 HTTP GET 请求以获取当前活跃的用户登录信息。
     * 此方法将活跃用户信息作为 JSON 格式响应客户端。
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            objectMapper.writeValue(response.getWriter(), userService.getActiveLogins());
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }
}
