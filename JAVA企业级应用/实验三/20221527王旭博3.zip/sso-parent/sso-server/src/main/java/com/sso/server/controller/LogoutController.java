package com.sso.server.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.sso.server.model.User;
import com.sso.server.service.TokenService;
import com.sso.server.service.UserService;
import java.sql.SQLException;

/**
 * 处理用户登出请求
 */
public class LogoutController extends HttpServlet {
    private UserService userService;
    private TokenService tokenService;

    /**
     * 获取必须的服务
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        userService = (UserService) getServletContext().getAttribute("userService");
        tokenService = (TokenService) getServletContext().getAttribute("tokenService");
    }

    /**
     * 处理get请求，执行用户登出操作
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // 获取当前登录用户
            User user = (User) request.getSession().getAttribute("user");
            String token = tokenService.getTokenFromCookies(request);

            if (user != null) {
                // 记录登出
                userService.recordLogout(user.getId(), "sso-server");
            }

            // 清除token和会话
            tokenService.removeToken(token, response, request);

            // 重定向到登录页面
            request.setAttribute("error", "Current user has been login");
            request.getRequestDispatcher("/jsp/logout.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Error during logout", e);
        }
    }
}

