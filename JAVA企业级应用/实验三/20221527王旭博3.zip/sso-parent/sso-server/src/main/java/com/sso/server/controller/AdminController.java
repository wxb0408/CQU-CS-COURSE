package com.sso.server.controller;

import com.sso.server.model.User;
import com.sso.server.model.AccessLog;
import com.sso.server.service.UserService;
import com.sso.server.service.AccessLogService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * 管理员控制类,内含各种对用户信息的操作
 */
public class AdminController extends HttpServlet {
    //引入服务层的实例化
    private UserService userService;
    private AccessLogService accessLogService;

    /**
     * 初始化控制器，获取必需的服务。
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        //获取服务层的方法
        super.init();
        userService = (UserService) getServletContext().getAttribute("userService");
        accessLogService = (AccessLogService) getServletContext().getAttribute("accessLogService");

        if (userService == null || accessLogService == null) {
            throw new ServletException("Required services are not initialized");
        }
    }

    /**
     * 处理 GET 请求。
     * 根据请求的 URL 路径分发到不同的处理方法。
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String servletPath = request.getServletPath();

        try {
            if ("/admin/logs".equals(servletPath)) {
                handleLogsRequest(request, response);
            } else if ("/admin/users".equals(servletPath)) {
                listUsers(request, response);
            } else if ("/admin/edit".equals(servletPath)) {
                showEditForm(request, response);
            } else {
                // 默认重定向到用户列表
                response.sendRedirect(request.getContextPath() + "/admin/users");
            }
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String action = request.getParameter("action");
            if (action == null || action.trim().isEmpty()) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Action is required");
                return;
            }

            switch (action) {
                case "update":
                    updateUser(request, response);
                    break;
                case "delete":
                    deleteUser(request, response);
                    break;
                case "enable":
                    toggleUserStatus(request, response, true);
                    break;
                case "disable":
                    toggleUserStatus(request, response, false);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }

    /**
     * 处理日志请求
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     * @throws SQLException
     */
    private void handleLogsRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String type = request.getParameter("type");

        if ("system".equals(type)) {
            viewSystemLogs(request, response);
        } else if ("user".equals(type)) {
            String userId = request.getParameter("id");
            if (userId == null || userId.trim().isEmpty()) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "User ID is required");
                return;
            }
            try {
                Long userIdLong = Long.parseLong(userId);
                viewUserLogs(request, response, userIdLong);
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid user ID");
            }
        } else {
            // 如果没有指定类型，默认显示系统日志
            viewSystemLogs(request, response);
        }
    }

    /**
     * 显示所有的用户列表
     * @param request
     * @param response
     * @throws SQLException
     * @throws ServletException
     * @throws IOException
     */
    private void listUsers(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        List<User> users = userService.findAllUsers();
        request.setAttribute("users", users);
        request.getRequestDispatcher("/jsp/admin/users.jsp").forward(request, response);
    }

    /**
     * 显示编辑用户信息的菜单
     * @param request
     * @param response
     * @throws SQLException
     * @throws ServletException
     * @throws IOException
     */
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String userId = request.getParameter("id");
        if (userId == null || userId.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "User ID is required");
            return;
        }

        try {
            Long userIdLong = Long.parseLong(userId);
            User user = userService.findById(userIdLong);
            if (user != null) {
                request.setAttribute("user", user);
                request.getRequestDispatcher("/jsp/admin/edit-user.jsp").forward(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "User not found");
            }
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid user ID");
        }
    }

    /**
     * 更新用户信息
     * @param request
     * @param response
     * @throws SQLException
     * @throws IOException
     */
    private void updateUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String userId = request.getParameter("id");
        String username = request.getParameter("username");

        if (userId == null || userId.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "User ID is required");
            return;
        }
        if (username == null || username.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Username is required");
            return;
        }

        try {
            Long userIdLong = Long.parseLong(userId);
            boolean enabled = "on".equals(request.getParameter("enabled"));

            User user = userService.findById(userIdLong);
            if (user != null) {
                user.setUsername(username.trim());
                user.setEnabled(enabled);
                userService.updateUser(user);
                response.sendRedirect(request.getContextPath() + "/admin/users");
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "User not found");
            }
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid user ID");
        }
    }

    /**
     * 启用或禁用用户
     * @param request
     * @param response
     * @param status
     * @throws SQLException
     * @throws IOException
     */
    private void toggleUserStatus(HttpServletRequest request, HttpServletResponse response, boolean status)
            throws SQLException, IOException {
        String userId = request.getParameter("id");
        if (userId == null || userId.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "User ID is required");
            return;
        }

        try {
            Long userIdLong = Long.parseLong(userId);
            userService.updateUserStatus(userIdLong, status);
            response.sendRedirect(request.getContextPath() + "/admin/users");
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid user ID");
        }
    }

    /**
     * 删除用户
     * @param request
     * @param response
     * @throws SQLException
     * @throws IOException
     */
    private void deleteUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String userId = request.getParameter("id");
        if (userId == null || userId.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "User ID is required");
            return;
        }

        try {
            Long userIdLong = Long.parseLong(userId);
            userService.deleteUser(userIdLong);
            response.sendRedirect(request.getContextPath() + "/admin/users");
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid user ID");
        }
    }

    /**
     * 查看某个用户的访问日志
     * @param request
     * @param response
     * @param userId
     * @throws SQLException
     * @throws ServletException
     * @throws IOException
     */
    private void viewUserLogs(HttpServletRequest request, HttpServletResponse response, Long userId)
            throws SQLException, ServletException, IOException {
        User user = userService.findById(userId);
        if (user == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "User not found");
            return;
        }

        List<Map<String, Object>> logs = userService.getUserAccessLogs(userId);
        request.setAttribute("user", user);
        request.setAttribute("logs", logs);
        request.getRequestDispatcher("/jsp/admin/user-logs.jsp").forward(request, response);
    }

    /**
     * 查看系统访问日志
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void viewSystemLogs(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        List<Map<String, Object>> recentLogins = userService.getRecentLogins(100);
        request.setAttribute("recentLogins", recentLogins);
        request.getRequestDispatcher("/jsp/admin/system-logs.jsp").forward(request, response);
    }
}