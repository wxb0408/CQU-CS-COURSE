package com.sso.server.dao;

import com.sso.server.model.LoginRecord;
import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

/**
 * 管理登录记录的表
 */
public class LoginRecordDAO {
    private final DataSource dataSource;

    /**
     * 获取数据源
     * @param dataSource
     */
    public LoginRecordDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * 查找最近的登录记录
     * @param limit
     * @return
     * @throws SQLException
     */
    public List<LoginRecord> findRecentLogins(int limit) throws SQLException {
        String sql = "SELECT * FROM login_records ORDER BY login_time DESC LIMIT ?";
        List<LoginRecord> records = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, limit);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    records.add(mapLoginRecord(rs));
                }
            }
        }

        return records;
    }

    /**
     * 获取指定时间之后的登录次数
     * @param timestamp
     * @return
     * @throws SQLException
     */
    public long countLoginsSince(Timestamp timestamp) throws SQLException {
        String sql = "SELECT COUNT(*) FROM login_records WHERE login_time >= ?";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setTimestamp(1, timestamp);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        }
        return 0;
    }

    /**
     * 查找当前活跃的登录记录
     * @return
     * @throws SQLException
     */
    public List<LoginRecord> findActiveLogins() throws SQLException {
        String sql = "SELECT * FROM login_records WHERE logout_time IS NULL ORDER BY login_time DESC";
        List<LoginRecord> records = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                records.add(mapLoginRecord(rs));
            }
        }

        return records;
    }

    /**
     * 添加新的登录记录
     * @param record
     * @throws SQLException
     */
    public void save(LoginRecord record) throws SQLException {
        String sql = "INSERT INTO login_records (user_id, system_name, login_time) VALUES (?, ?, ?)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, record.getUserId());
            ps.setString(2, record.getSystemName());
            ps.setTimestamp(3, new Timestamp(record.getLoginTime().getTime()));
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                record.setId(rs.getLong(1));
            }
        }
    }

    /**
     * 更新指定用户的登出时间
     * @param userId
     * @param systemName
     * @param logoutTime
     * @throws SQLException
     */
    public void updateLogoutTime(Long userId, String systemName, Date logoutTime) throws SQLException {
        String sql = "UPDATE login_records SET logout_time = ? " +
                "WHERE user_id = ? AND system_name = ? AND logout_time IS NULL";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setTimestamp(1, new Timestamp(logoutTime.getTime()));
            ps.setLong(2, userId);
            ps.setString(3, systemName);

            ps.executeUpdate();
        }
    }

    /**
     * 将数据库查询结果映射为LoginRecord对象
     * @param rs
     * @return
     * @throws SQLException
     */
    public LoginRecord mapLoginRecord(ResultSet rs) throws SQLException {
        LoginRecord record = new LoginRecord();
        record.setId(rs.getLong("id"));
        record.setUserId(rs.getLong("user_id"));
        record.setSystemName(rs.getString("system_name"));
        Timestamp loginTime = rs.getTimestamp("login_time");
        if (loginTime != null) {
            record.setLoginTime(new Date(loginTime.getTime()));
        }
        Timestamp logoutTime = rs.getTimestamp("logout_time");
        if (logoutTime != null) {
            record.setLogoutTime(new Date(logoutTime.getTime()));
        }
        return record;
    }
}