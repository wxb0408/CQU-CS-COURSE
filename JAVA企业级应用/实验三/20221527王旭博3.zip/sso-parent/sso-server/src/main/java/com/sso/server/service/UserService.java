package com.sso.server.service;

import com.sso.server.dao.UserDAO;
import com.sso.server.dao.LoginRecordDAO;
import com.sso.server.model.User;
import com.sso.server.model.LoginRecord;
import com.sso.server.util.PasswordUtil;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;

import com.sso.server.model.AccessLog;
import java.util.stream.Collectors;

/**
 * 用户相关逻辑实现
 */
public class UserService {
    private final UserDAO userDAO;
    private final LoginRecordDAO loginRecordDAO;
    private final AccessLogService accessLogService;

    public UserService(UserDAO userDAO, LoginRecordDAO loginRecordDAO, AccessLogService accessLogService) {
        this.userDAO = userDAO;
        this.loginRecordDAO = loginRecordDAO;
        this.accessLogService = accessLogService;
    }

    /**
     * 获取最近的limit条用户登录记录
     * @param limit
     * @return
     * @throws SQLException
     */
    public List<Map<String, Object>> getRecentLogins(int limit) throws SQLException {
        List<LoginRecord> records = loginRecordDAO.findRecentLogins(limit);
        List<Map<String, Object>> result = new ArrayList<>();

        for (LoginRecord record : records) {
            User user = userDAO.findById(record.getUserId());
            if (user != null) {
                Map<String, Object> loginInfo = new HashMap<>();
                loginInfo.put("username", user.getUsername());
                loginInfo.put("loginTime", record.getLoginTime());
                loginInfo.put("systemName", record.getSystemName());
                loginInfo.put("status", record.getLogoutTime() == null ? "ACTIVE" : "ENDED");
                loginInfo.put("userId", user.getId());
                result.add(loginInfo);
            }
        }

        return result;
    }

    /**
     * 统计所有的用户信息
     * @return
     * @throws SQLException
     */
    public Map<String, Object> getUserStatistics() throws SQLException {
        Map<String, Object> stats = new HashMap<>();

        // 获取所有用户
        List<User> allUsers = userDAO.findAll();
        // 获取活跃登录记录
        List<LoginRecord> activeLogins = loginRecordDAO.findActiveLogins();

        // 计算统计数据
        stats.put("totalUsers", allUsers.size());
        stats.put("activeUsers", activeLogins.size());

        // 计算今日登录数
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        // 转换为 Timestamp
        Timestamp todayStart = new Timestamp(calendar.getTimeInMillis());

        long todayLogins = loginRecordDAO.countLoginsSince(todayStart);
        stats.put("todayLogins", todayLogins);

        // 获取接入的系统数量
        Set<String> systems = activeLogins.stream()
                .map(LoginRecord::getSystemName)
                .collect(Collectors.toSet());
        stats.put("totalSystems", systems.size());

        return stats;
    }

    /**
     * 获取指定用户的访问日志
     * @param userId
     * @return
     */
    public List<Map<String, Object>> getUserAccessLogs(Long userId) throws SQLException {
        List<LoginRecord> logs = accessLogService.getUserLogs(userId);
        List<Map<String, Object>> result = new ArrayList<>();

        for (LoginRecord record : logs) {
            User user = userDAO.findById(record.getUserId());
            if (user != null) {
                Map<String, Object> loginInfo = new HashMap<>();
                loginInfo.put("username", user.getUsername());
                loginInfo.put("loginTime", record.getLoginTime());
                loginInfo.put("systemName", record.getSystemName());
                loginInfo.put("status", record.getLogoutTime() == null ? "ACTIVE" : "ENDED");
                loginInfo.put("userId", user.getId());
                result.add(loginInfo);
            }
        }

        return result;
    }

    /**
     * 获取所有的用户
     * @return
     * @throws SQLException
     */
    public List<User> findAllUsers() throws SQLException {
        return userDAO.findAll();
    }

    /**
     * 根据id查找用户
     * @param id
     * @return
     * @throws SQLException
     */
    public User findById(Long id) throws SQLException {
        return userDAO.findById(id);
    }

    /**
     * 更新用户的信息
     * @param user
     * @throws SQLException
     */
    public void updateUser(User user) throws SQLException {
        User existingUser = userDAO.findById(user.getId());
        if (existingUser == null) {
            throw new IllegalArgumentException("User not found");
        }
        user.setPassword(existingUser.getPassword());
        userDAO.update(user);
    }

    /**
     * 更新用户的登录状态（启用/禁用）
     * @param userId
     * @param enabled
     * @throws SQLException
     */
    public void updateUserStatus(Long userId, boolean enabled) throws SQLException {
        User user = userDAO.findById(userId);
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }
        user.setEnabled(enabled);
        userDAO.update(user);
    }

    /**
     * 删除用户
     * @param userId
     * @throws SQLException
     */
    public void deleteUser(Long userId) throws SQLException {
        updateUserStatus(userId, false);
    }

    /**
     * 根据关键字模糊查询用户
     * @param keyword
     * @return
     * @throws SQLException
     */
    public List<User> searchUsers(String keyword) throws SQLException {
        return userDAO.search(keyword);
    }

    /**
     * 检查用户名是否可以使用
     * @param username
     * @return
     * @throws SQLException
     */
    public boolean isUsernameAvailable(String username) throws SQLException {
        return userDAO.findByUsername(username) == null;
    }

    /**
     * 注册新用户
     * @param username
     * @param password
     * @return
     * @throws SQLException
     */
    public User register(String username, String password) throws SQLException {
        User existingUser = userDAO.findByUsername(username);
        if (existingUser != null) {
            throw new IllegalArgumentException("Username already exists");
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(PasswordUtil.encrypt(password));
        user.setEnabled(true);
        user.setCreateTime(new Date());

        userDAO.save(user);
        return user;
    }

    /**
     * 用户登录验证操作
     * @param username
     * @param password
     * @return
     * @throws SQLException
     */
    public User authenticate(String username, String password) throws SQLException {
        User user = userDAO.findByUsername(username);
        if (user != null && user.isEnabled() &&
                PasswordUtil.verify(password, user.getPassword())) {
            return user;
        }
        return null;
    }

    /**
     * 记录用户的登录的信息
     * @param userId
     * @param systemName
     * @throws SQLException
     */
    public void recordLogin(Long userId, String systemName) throws SQLException {
        LoginRecord record = new LoginRecord();
        record.setUserId(userId);
        record.setSystemName(systemName);
        record.setLoginTime(new Date());
        loginRecordDAO.save(record);
    }

    /**
     * 记录用户的登出的信息
     * @param userId
     * @param systemName
     * @throws SQLException
     */
    public void recordLogout(Long userId, String systemName) throws SQLException {
        loginRecordDAO.updateLogoutTime(userId, systemName, new Date());
    }

    /**
     * 记录当前所有的活跃用户
     * @return
     * @throws SQLException
     */
    public List<Map<String, Object>> getActiveUsers() throws SQLException {
        List<LoginRecord> records = loginRecordDAO.findActiveLogins();
        List<Map<String, Object>> result = new ArrayList<>();

        for (LoginRecord record : records) {
            User user = userDAO.findById(record.getUserId());
            if (user != null) {
                Map<String, Object> userInfo = new HashMap<>();
                userInfo.put("username", user.getUsername());
                userInfo.put("loginTime", record.getLoginTime());
                userInfo.put("systemName", record.getSystemName());
                result.add(userInfo);
            }
        }
        return result;
    }

//    public void disableUser(Long userId) throws SQLException {
//        User user = userDAO.findById(userId);
//        if (user != null) {
//            user.setEnabled(false);
//            userDAO.update(user);
//        }
//    }

    //获取活跃的登录用户
    public List<Map<String, Object>> getActiveLogins() throws SQLException {
        return getActiveUsers(); // 使用已有的方法
    }


    public void del(Long id, String s) throws SQLException  {
        userDAO.deluser(id);
    }
}