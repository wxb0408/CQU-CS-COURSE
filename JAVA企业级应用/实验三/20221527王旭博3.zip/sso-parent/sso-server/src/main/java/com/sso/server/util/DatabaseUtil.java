package com.sso.server.util;

import com.mysql.cj.jdbc.MysqlDataSource;
import javax.sql.DataSource;

/**
 * 数据库工具类
 */
public class DatabaseUtil {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/ssoserver?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "123456";
    private static DataSource dataSource;

    /**
     * 单例模式确保只有一个数据源实例
     * @return
     */
    public static DataSource getDataSource() {
        if (dataSource == null) {
            MysqlDataSource mysqlDS = new MysqlDataSource();
            mysqlDS.setURL(DB_URL);
            mysqlDS.setUser(DB_USER);
            mysqlDS.setPassword(DB_PASSWORD);
            dataSource = mysqlDS;
        }
        return dataSource;
    }
}