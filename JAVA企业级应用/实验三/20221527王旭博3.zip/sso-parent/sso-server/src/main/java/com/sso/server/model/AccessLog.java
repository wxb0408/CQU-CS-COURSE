package com.sso.server.model;

import lombok.Data;

import java.util.Date;

/**
 * 访问日志实体类
 */
@Data
public class AccessLog {
    private Long id;//日志id
    private Long userId;//用户id
    private String username;//用户名
    private String actionType;//操作类型（登录，退出...）
    private String requestUrl;//用户请求的url
    private String clientIp;//客户端的url
    private String userAgent;//客户端设备信息
    private Date accessTime;//访问的时间
    private String status;//操作的状态
    private String details;//详细操作描述
}

