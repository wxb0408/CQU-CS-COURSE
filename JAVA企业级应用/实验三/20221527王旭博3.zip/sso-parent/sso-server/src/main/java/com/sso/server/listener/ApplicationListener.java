package com.sso.server.listener;

import com.mysql.cj.jdbc.AbandonedConnectionCleanupThread;
import com.mysql.cj.jdbc.MysqlDataSource;
import com.sso.server.dao.UserDAO;
import com.sso.server.dao.LoginRecordDAO;
import com.sso.server.dao.AccessLogDAO;
import com.sso.server.service.UserService;
import com.sso.server.service.TokenService;
import com.sso.server.service.AccessLogService;
import com.sso.server.util.DatabaseUtil;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * 资源监听器（启动/关闭）
 */
@WebListener
public class ApplicationListener implements ServletContextListener {
    /**
     * 应用程序启动时初始化服务层和数据访问层
     * @param sce
     */
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        // 初始化所有DAO
        UserDAO userDAO = new UserDAO(DatabaseUtil.getDataSource());
        LoginRecordDAO loginRecordDAO = new LoginRecordDAO(DatabaseUtil.getDataSource());
        AccessLogDAO accessLogDAO = new AccessLogDAO(DatabaseUtil.getDataSource());
        // 初始化所有Service
        AccessLogService accessLogService = new AccessLogService(accessLogDAO);
        UserService userService = new UserService(userDAO, loginRecordDAO, accessLogService);
        TokenService tokenService = new TokenService();
        // 将service存入ServletContext
        sce.getServletContext().setAttribute("userService", userService);
        sce.getServletContext().setAttribute("tokenService", tokenService);
        sce.getServletContext().setAttribute("accessLogService", accessLogService);
    }

    /**
     * 释放清理资源
     * @param sce
     */
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        ServletContext context = sce.getServletContext();

        // 从 ServletContext 获取服务对象
        UserService userService = (UserService) context.getAttribute("userService");
        TokenService tokenService = (TokenService) context.getAttribute("tokenService");
        AccessLogService accessLogService = (AccessLogService) context.getAttribute("accessLogService");

        // 停止任何后台任务
        stopBackgroundTasks();

        // 清理 ServletContext 中的服务对象
        context.removeAttribute("userService");
        context.removeAttribute("tokenService");
        context.removeAttribute("accessLogService");
    }

    private void stopBackgroundTasks() {
        try {
            // 假设应用中有清理连接池的后台线程，比如 MySQL 驱动中的连接清理线程
            if (AbandonedConnectionCleanupThread.isAlive()) {
                AbandonedConnectionCleanupThread.uncheckedShutdown();
            }
        } catch (Exception e) {
            e.printStackTrace();  // 处理异常
        }
    }
}