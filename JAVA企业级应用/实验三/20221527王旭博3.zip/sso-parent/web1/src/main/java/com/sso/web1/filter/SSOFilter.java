// web1/src/main/java/com/sso/web1/filter/SSOFilter.java
package com.sso.web1.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;

/**
 * 拦截所有的HTTP请求，检查用户是否已经登录
 */
@WebFilter("/*")
public class SSOFilter implements Filter {
    //SSO的URL，用于后续的重定向操作
    private static final String SSO_SERVER_URL = "http://localhost:8080/sso-server";
    //存储SSOtoken的cookie名称
    private static final String TOKEN_NAME = "sso_token";

    /**
     * 过滤请求并验证用户是否已经登录，根据token是否存在决定下面的操作
     * @param request
     * @param response
     * @param chain
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // 不拦截登出请求
        if (httpRequest.getRequestURI().endsWith("/logout")) {
            chain.doFilter(request, response);
            return;
        }

        // 获取token
        String token = getTokenFromCookie(httpRequest);
        if (token != null) {
            // 验证token
            if (validateToken(token)) {
                chain.doFilter(request, response);
                return;
            }
        }

        // 重定向到SSO服务器
        String currentUrl = httpRequest.getRequestURL().toString();
        httpResponse.sendRedirect(SSO_SERVER_URL + "/login?redirect=" +
                URLEncoder.encode(currentUrl, "UTF-8"));
    }

    /**
     * 从cookie中获取token
     * @param request
     * @return
     */
    private String getTokenFromCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (TOKEN_NAME.equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

    /**
     * 验证token是否有效
     * @param token
     * @return
     */
    private boolean validateToken(String token) {
        try {
            // 调用SSO服务器验证token
            String validateUrl = SSO_SERVER_URL + "/validate?token=" + token;
            java.net.URL url = new java.net.URL(validateUrl);
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            return conn.getResponseCode() == 200;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void destroy() {}
}
