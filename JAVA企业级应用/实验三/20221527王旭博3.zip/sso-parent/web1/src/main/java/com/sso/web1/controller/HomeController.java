// web1/src/main/java/com/sso/web1/controller/HomeController.java
package com.sso.web1.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

/**
 * 处理首页的请求，从SSO服务器获取活跃用户列表
 */
public class HomeController extends HttpServlet {
    //SSO服务器的URL
    private static final String SSO_SERVER_URL = "http://localhost:8080/sso-server";
    private ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 检查请求中是否包含有效token，并获取相关的信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String token = getTokenFromCookie(request);
        if (token != null) {
            String userInfo = getUserInfo(token);
            request.setAttribute("userInfo", userInfo);
        }

        List<Map<String, Object>> activeUsers = getActiveUsers();
        request.setAttribute("activeUsers", activeUsers);

        request.getRequestDispatcher("/jsp/home.jsp").forward(request, response);
    }

    /**
     * 获取当前的活跃用户列表
     * @return
     * @throws IOException
     */
    private List<Map<String, Object>> getActiveUsers() throws IOException {
        URL url = new URL(SSO_SERVER_URL + "/active-users");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream()))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            // 将JSON字符串转换为List<Map<String, Object>>
            return objectMapper.readValue(
                    response.toString(),
                    new TypeReference<List<Map<String, Object>>>() {}
            );
        }
    }

    /**
     * 从cookies中获取token
     * @param request
     * @return
     */
    private String getTokenFromCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("sso_token".equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

    /**
     * 根据token获取对应的用户信息
     * @param token
     * @return
     * @throws IOException
     */
    private String getUserInfo(String token) throws IOException {
        URL url = new URL(SSO_SERVER_URL + "/userinfo?token=" + token);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;

        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        return response.toString();
    }
}

