package com.sso.web1.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 用户退出web1的逻辑
 */
@WebServlet("/logout")
public class LogoutController extends HttpServlet {
    //SSO服务器的地址，用于重定向回去
    private static final String SSO_SERVER_URL = "http://localhost:8080/sso-server";

    /**
     * 重定向到SSO服务器并清楚本地存储的cookie
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 清除本地cookie
        Cookie cookie = new Cookie("sso_token", "");
        cookie.setMaxAge(0);
        cookie.setPath("/");
        response.addCookie(cookie);

        // 重定向到SSO服务器的登出
        response.sendRedirect(SSO_SERVER_URL + "/logout");
    }
}