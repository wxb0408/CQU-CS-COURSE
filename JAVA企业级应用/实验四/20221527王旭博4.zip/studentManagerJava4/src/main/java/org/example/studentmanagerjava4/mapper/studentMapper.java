package org.example.studentmanagerjava4.mapper;

import org.apache.ibatis.annotations.*;
import org.example.studentmanagerjava4.pojo.table.Student;
import org.example.studentmanagerjava4.pojo.table.course;
import org.springframework.stereotype.Repository;
import java.util.List;

@Mapper
@Repository
public interface studentMapper {
    @Select("select * from student where studentId=#{studentid} and name = #{name}")
    List<Student> selectStudent(String studentid, String name);

    @Update("update student set password = #{password} where studentId = #{studentid}")
    Integer addPassward(String studentid, String password);

    @Select("select * from student where studentId = #{id} and password = #{repassword}")
    List<Student> getStudent(String id, String repassword);

    @Update("update student set phone = #{phone}, province = #{province},city = #{city},gender = #{gender},political = #{political},email = #{email},academy = #{academy} where studentId = #{studentid}")
    Integer updateinformation(String studentid, String phone, String province, String city, String gender, String political, String email, String academy);

    @Delete("delete from student where studentId = #{id}")
    Integer deleteAccount(String id);

    @Select("select * from student LIMIT #{pageSize} OFFSET #{pageNum}")
    List<Student> getAllStudent(Integer pageNum, Integer pageSize);

    @Update("update student set name = #{name} where studentId = #{studentId}")
    int updateStudent(String studentId, String name);

    @Insert("insert into student (studentId,name) values (#{studentId},#{name})")
    int addStudent(String studentId, String name);

    @Delete("delete from student where studentId = #{studentId}")
    int deleteStudent(String studentId);

    @Select("select * from student where studentId = #{studentId}")
    List<Student> getOneStudentBystudentId(String studentId);

    @Select("select * from student where name = #{name}")
    List<Student> getOneStudentByName(String name);

    @Select("select * from student where name = #{name} and studentId = #{studentId}")
    List<Student> getOneStudent(String name, String studentId);

    @Select("select count(*) from student")
    Integer getCount();
}
