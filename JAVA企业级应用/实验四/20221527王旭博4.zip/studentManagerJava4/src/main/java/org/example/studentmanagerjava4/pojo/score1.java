package org.example.studentmanagerjava4.pojo;

import lombok.Data;

@Data
public class score1 {
    private String studentName;//学生姓名
    private String teacherName;//教师姓名
    private String courseName;//课程名称
    private String className;//教学班号
    private Integer grade;//课程学分
    private Integer semester;//开课学期
}
