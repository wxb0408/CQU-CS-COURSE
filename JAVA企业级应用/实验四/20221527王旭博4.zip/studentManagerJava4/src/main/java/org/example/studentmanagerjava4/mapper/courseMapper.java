package org.example.studentmanagerjava4.mapper;

import org.apache.ibatis.annotations.*;
import org.example.studentmanagerjava4.pojo.table.course;
import org.springframework.stereotype.Repository;

import java.util.List;



@Mapper
@Repository
public interface courseMapper {
    @Select("select * from course LIMIT #{pageSize} OFFSET #{pageNum}")
    List<course> getAllClass(Integer pageNum, Integer pageSize);

    @Update("update course set courseName = #{courseName},academy = #{academy},grade = #{grade},semester = #{semester} where courseId = #{courseId}")
    int updateCourse(String courseName, String courseId, String academy, Integer grade, Integer semester);

    @Insert("insert into course (courseName, grade, semester, courseId, academy) values (#{courseName},#{grade},#{semester},#{courseId},#{academy})")
    int addCourse(String courseName, String courseId, String academy, Integer grade, Integer semester);

    @Delete("delete from course where courseId = #{courseId}")
    int deleteCourse(String courseId);

    @Select("select * from course where courseName = #{courseName}")
    List<course> getOneClass(String courseName);

    @Select("select * from course")
    List<course> getAllClasss();
}
