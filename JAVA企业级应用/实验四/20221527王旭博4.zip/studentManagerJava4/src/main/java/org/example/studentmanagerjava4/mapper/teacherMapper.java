package org.example.studentmanagerjava4.mapper;

import org.apache.ibatis.annotations.*;
import org.example.studentmanagerjava4.pojo.table.teacher;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface teacherMapper {
    @Select("select * from teacher where teacherId = #{id} and password = #{password}")
    List<teacher> getTeacher(String id, String password);

    @Update("update teacher set phone = #{phone},gender = #{gender},email = #{email} where teacherId = #{teacherId}")
    Integer updateTeacherInformation(String teacherId, String phone, String gender, String email);

    @Delete("delete from teacher where teacherId = #{id}")
    Integer deleteAccount(String id);

    @Select("select * from teacher LIMIT #{pageSize} OFFSET #{pageNum}")
    List<teacher> getAllTeacher(Integer pageNum, Integer pageSize);

    @Update("update teacher set name = #{name},email = #{email},phone = #{phone},gender = #{gender} where teacherId = #{teacherId}")
    int updateTeacher(String teacherId, String name, String email, String phone, String gender);

    @Insert("insert into teacher (teacherId,name,email,phone,gender) values (#{teacherId},#{name},#{email},#{phone},#{gender})")
    int addTeacher(String teacherId, String name, String email, String phone, String gender);

    @Delete("delete from teacher where teacherId = #{teacherId}")
    int deleteTeacher(String teacherId);

    @Select("select * from teacher where teacherId = #{teacherId}")
    List<teacher> getOneTeacherByteacherId(String teacherId);

    @Select("select * from teacher where name = #{name}")
    List<teacher> getOneTeacherByName(String name);

    @Select("select * from teacher where name = #{name} and teacherId = #{teacherId}")
    List<teacher> getOneTeacher(String name, String teacherId);

    @Select("select count(*) from teacher")
    Integer getCount();

    @Select("select * from teacher")
    List<teacher> getAllTeachers();
}
