package org.example.studentmanagerjava4.pojo.table;

import lombok.Data;

/**
 * 排行榜专用
 */
@Data
public class rank {
    private String studentName;
    private Integer course001;
    private Integer course002;
    private Integer course003;
    private Integer course004;
    private Integer course005;
    private Integer course006;
    private Integer course007;
    private Double gpa;
}
