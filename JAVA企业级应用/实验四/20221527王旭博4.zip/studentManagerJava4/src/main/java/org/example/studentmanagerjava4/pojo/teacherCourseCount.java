package org.example.studentmanagerjava4.pojo;

import lombok.Data;

@Data
public class teacherCourseCount {
    private String teacherName;
    private String teacherCount;
}
