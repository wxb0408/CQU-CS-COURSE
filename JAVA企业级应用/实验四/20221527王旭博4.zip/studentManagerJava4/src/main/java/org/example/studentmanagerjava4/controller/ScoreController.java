package org.example.studentmanagerjava4.controller;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.pingfen;
import org.example.studentmanagerjava4.pojo.score1;
import org.example.studentmanagerjava4.service.ScoreService;
import org.example.studentmanagerjava4.service.impl.ScoreServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController //绑定HTTP响应体和返回，HTTP参数和方法参数
@RequestMapping("score") //类中的所有处理方法都将继承这个基础路径
public class ScoreController {

    @Autowired
    private ScoreServiceImpl scoreService;

    /**
     * 添加学生选课数据
     * @param score
     * @return
     */
    @PostMapping("/selectCourse")
    public ResultTest<?> selectCourse(@RequestBody score1 score) {
        return scoreService.selectCourse(score);
    }

    /**
     * 查询学生选课数据
     * @param
     * @return
     */
    @GetMapping("haveSelectCourseByStudentName")
    public ResultTest<?> haveSelectCourseByStudentName(@RequestParam("studentName") String studentName) {
        return scoreService.haveSelectCourseByStudentName(studentName);
    }

    /**
     * 删除学生选课数据
     * @param
     * @return
     */
    @GetMapping("deleteCourseByStudentName")
    public ResultTest<?> deleteCourseByStudentName(@RequestParam("studentName") String studentName,@RequestParam("courseName") String courseName) {
        return scoreService.deleteCourseByStudentName(studentName,courseName);
    }

    /**
     * 根据教师名查询选课信息
     * @param teacherName
     * @return
     */
    @GetMapping("/getInformationByTeacherName")
    public ResultTest<?> getInformationByTeacherName(@RequestParam("teacherName") String teacherName) {
        return scoreService.getInformationByTeacherName(teacherName);
    }

    /**
     * 根据教师名和课程名称查询选课信息
     * @param teacherName
     * @return
     */
    @GetMapping("/getInformationByTeacherNameAndCourse")
    public ResultTest<?> getInformationByTeacherNameAndCourse(@RequestParam("teacherName") String teacherName,@RequestParam("courseName") String courseName) {
        return scoreService.getInformationByTeacherNameAndCourse(teacherName,courseName);
    }

    /**
     * 根据教学班获取分数信息
     * @param
     * @param className
     * @return
     */
    @GetMapping("/getScoreWithClassName")
    public ResultTest<?> getScoreWithClassName(@RequestParam("pageNum") Integer pageNum,@RequestParam("pageSize") Integer pageSize, @RequestParam("className") String className,@RequestParam("sortField") String sortField) {
        return scoreService.getScoreWithClassName(pageNum,pageSize,className,sortField);
    }

    /**
     * 根据教学班获取分数信息(不分页)
     * @param pageNum
     * @param pageSize
     * @param className
     * @param sortField
     * @return
     */
    @GetMapping("/getAllScoreWithClassName")
    public ResultTest<?> getAllScoreWithClassName(@RequestParam("className") String className) {
        return scoreService.getAllScoreWithClassName(className);
    }

    /**
     * 获取教学班总人数
     * @param className
     * @return
     */
    @GetMapping("/getScoreCount")
    public ResultTest<?> getScoreCount(@RequestParam("className") String className) {
        return scoreService.getScoreCount(className);
    }

    /**
     * 单人评分
     * @param score
     * @return
     */
    @PostMapping("/pingfen")
    public ResultTest<?> pingfen(@RequestBody pingfen score) {
        return scoreService.pingfen(score);
    }

    /**
     * 根据学生姓名和教学班获取分数信息
     * @param studentName
     * @param className
     * @return
     */
    @GetMapping("/getStudentScore")
    public ResultTest<?> getStudentScore(@RequestParam("studentName") String studentName,@RequestParam("className") String className) {
        return scoreService.getStudentScore(studentName,className);
    }

    /**
     * 统一设置学生分数
     * @param score
     * @return
     */
    @PostMapping("/setStudentScore")
    public ResultTest<?> setStudentScore(@RequestBody pingfen score) {
        return scoreService.setStudentScore(score);
    }

    /**
     * 根据学期和学生姓名获取学生所有课程成绩
     * @param semester
     * @param studentName
     * @return
     */
    @GetMapping("/getScoreStudentSemester")
    public ResultTest<?> getScoreStudentSemester(@RequestParam("semester") Integer semester,@RequestParam("studentName") String studentName){
        return scoreService.getScoreStudentSemester(semester,studentName);
    }

    /**
     * 获取排行榜
     * @return
     */
    @GetMapping("/paihangbang")
    public ResultTest<?> getPaihangbang() {
        return scoreService.getPaihangbang();
    }

    @GetMapping("/queryrank")
    public ResultTest<?> queryrank(@RequestParam("studentName") String studentName,@RequestParam("studentId") String studentId) {
        return scoreService.queryrank(studentName,studentId);
    }
}
