package org.example.studentmanagerjava4.controller;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.table.Student;
import org.example.studentmanagerjava4.pojo.table.admin;
import org.example.studentmanagerjava4.service.impl.AdminServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 管理员控制类
 */
@RestController //绑定HTTP响应体和返回，HTTP参数和方法参数
@RequestMapping("admin") //类中的所有处理方法都将继承这个基础路径
public class AdminController {
    @Autowired
    private AdminServiceImpl adminService;

    /**
     * 更新管理员信息
     * @param admin
     * @return
     */
    @PostMapping("/updateInformation")
    public ResultTest<admin> updateStudentInformation(@RequestBody admin admin){
        return adminService.updateAdminInformation(admin);
    }
}
