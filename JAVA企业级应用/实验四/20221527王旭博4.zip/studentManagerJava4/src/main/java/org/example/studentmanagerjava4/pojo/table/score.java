package org.example.studentmanagerjava4.pojo.table;

import lombok.Data;

/**
 * 学生课程学分汇总
 */
@Data
public class score {
    private String studentName;//学生姓名
    private String teacherName;//教师姓名
    private String courseName;//课程名称
    private String className;//教学班号
    private Integer grade;//课程学分
    private Integer pingshigrade;//平时成绩
    private Integer shiyangrade;//实验成绩
    private Integer qizhonggrade;//期中成绩
    private Integer qimograde;//期末成绩
    private Integer finalgrade;//总成绩
    private Integer semester;//开课学期
}
