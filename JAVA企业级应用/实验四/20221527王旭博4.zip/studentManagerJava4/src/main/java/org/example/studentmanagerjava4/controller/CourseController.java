package org.example.studentmanagerjava4.controller;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.table.course;
import org.example.studentmanagerjava4.service.impl.CourseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 课程信息控制器
 */
@RestController //绑定HTTP响应体和返回，HTTP参数和方法参数
@RequestMapping("course") //类中的所有处理方法都将继承这个基础路径
public class CourseController {

    @Autowired
    private CourseServiceImpl courseService;

    /**
     * 获取所有课程信息的接口方法
     * @return 返回所有课程信息的结果，包含课程列表和可能的错误信息
     */
    @GetMapping("/getAllCourse")
    public ResultTest<?> getAllCourse(@RequestParam("pageNum") Integer pageNum,@RequestParam("pageSize") Integer pageSize){
        return courseService.getAllCourse(pageNum,pageSize);
    }

    /**
     * 获取所有课程信息的接口方法
     * @return 返回所有课程信息的结果，包含课程列表和可能的错误信息
     */
    @GetMapping("/getAllCourses")
    public ResultTest<?> getAllCourses(){
        return courseService.getAllCourses();
    }

    /**
     * 更新课程信息的接口方法
     * @param course 课程对象，包含需更新的课程信息
     * @return 返回更新操作的结果，包含成功与否的标志和可能的错误信息
     */
    @PostMapping("/updateCourse")
    public ResultTest<?> updateCourse(@RequestBody course course){
        return courseService.updateCourse(course);
    }

    /**
     * 添加课程信息的接口方法
     * @param course 课程对象，包含需添加的课程信息
     * @return 返回添加操作的结果，包含成功与否的标志和可能的错误信息
     */
    @PostMapping("/addCourse")
    public ResultTest<?> addCourse(@RequestBody course course){
        return courseService.addCourse(course);
    }

    /**
     * 删除课程信息的接口方法
     * @param course 课程对象，包含需删除的课程信息
     * @return 返回删除操作的结果，包含成功与否的标志和可能的错误信息
     */
    @PostMapping("/deleteCourse")
    public ResultTest<?> deleteCourse(@RequestBody course course){
        return courseService.deleteCourse(course);
    }

    /**
     * 根据课程名称获取课程信息的接口方法
     * @param courseName 课程名称
     * @return 返回根据课程名称获取到的课程信息的结果，包含课程信息和可能的错误信息
     */
    @GetMapping("/getOneCourse")
    public ResultTest<?> getOneCourse(@RequestParam("courseName") String courseName){
        return courseService.getOneCourse(courseName);
    }


}
