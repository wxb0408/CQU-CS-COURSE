package org.example.studentmanagerjava4.pojo.table;

import lombok.Data;

/**
 * 教师信息实体类
 */

@Data
public class teacher {
    private String teacherId;//教师编号
    private String name;//姓名
    private String password;//密码
    private String userType;//账号类型
    private String email;//邮箱
    private String phone;//电话
    private String gender;//性别
    private String fileData;//头像
    private Integer role;//账号类型
}
