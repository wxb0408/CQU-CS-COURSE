package org.example.studentmanagerjava4.service;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.table.admin;

public interface AdminService {
    //修改管理员信息
    ResultTest<admin> updateAdminInformation(admin admin);
}
