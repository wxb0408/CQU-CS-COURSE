package org.example.studentmanagerjava4.service.impl;

import org.example.studentmanagerjava4.mapper.teacherMapper;
import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.table.Student;
import org.example.studentmanagerjava4.pojo.table.teacher;
import org.example.studentmanagerjava4.pojo.teacher1;
import org.example.studentmanagerjava4.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherServiceImpl implements TeacherService {
    @Autowired
    private teacherMapper teachermapper;

    @Override
    public ResultTest<teacher> updateTeacherInformation(teacher teacher) {
        String teacherId = teacher.getTeacherId();
        String phone =teacher.getPhone();
        String gender = teacher.getGender();
        String email = teacher.getEmail();
        Integer i = teachermapper.updateTeacherInformation(teacherId,phone,gender,email);
        if(i.equals(1)){
            return ResultTest.success(teacher);
        }
        else{
            return ResultTest.error(404,"更新信息失败");
        }
    }

    @Override
    public ResultTest<?> getAllTeacher(Integer pageNum, Integer pageSize) {
        pageNum = (pageNum - 1) * pageSize;
        List<teacher> teacherList = teachermapper.getAllTeacher(pageNum,pageSize);
        return ResultTest.success(teacherList);
    }

    @Override
    public ResultTest<?> updateTeacher(teacher1 teacher) {
        String teacherId = teacher.getTeacherId();
        String name = teacher.getName();
        String email = teacher.getEmail();
        String phone = teacher.getPhone();
        String gender = teacher.getGender();
        if(teachermapper.updateTeacher(teacherId,name,email,phone,gender) == 1){
            return ResultTest.success();
        }else{
            return ResultTest.error(404,"编辑失败");
        }
    }

    @Override
    public ResultTest<?> addTeacher(teacher1 teacher) {
        String teacherId = teacher.getTeacherId();
        String name = teacher.getName();
        String email = teacher.getEmail();
        String phone = teacher.getPhone();
        String gender = teacher.getGender();
        if(teachermapper.addTeacher(teacherId,name,email,phone,gender) == 1){
            return ResultTest.success();
        }else{
            return ResultTest.error(404,"添加失败");
        }
    }

    @Override
    public ResultTest<?> deleteTeacher(teacher1 teacher) {
        String teacherId = teacher.getTeacherId();
        if(teachermapper.deleteTeacher(teacherId) == 1){
            return ResultTest.success();
        }else{
            return ResultTest.error(404,"删除失败");
        }
    }

    @Override
    public ResultTest<?> getOneTeacher(String name, String teacherId) {
        if(name == ""){
            List<teacher> teacherList = teachermapper.getOneTeacherByteacherId(teacherId);
            if(teacherList.size()>0){
                return ResultTest.success(teacherList);
            }else{
                return ResultTest.error(404,"查询失败");
            }
        }else if(teacherId == ""){
            List<teacher> teacherList = teachermapper.getOneTeacherByName(name);
            if(teacherList.size()>0){
                return ResultTest.success(teacherList);
            }else{
                return ResultTest.error(404,"查询失败");
            }
        }else{
            List<teacher> teacherList = teachermapper.getOneTeacher(name,teacherId);
            if(teacherList.size()>0){
                return ResultTest.success(teacherList);
            }else{
                return ResultTest.error(404,"查询失败");
            }
        }
    }

    @Override
    public ResultTest<?> getCount() {
        Integer count = teachermapper.getCount();
        return ResultTest.success(count);
    }

    @Override
    public ResultTest<?> getAllTeachers() {
        List<teacher> teachers = teachermapper.getAllTeachers();
        return ResultTest.success(teachers);
    }
}
