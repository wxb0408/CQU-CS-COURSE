package org.example.studentmanagerjava4.service;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.student;
import org.example.studentmanagerjava4.pojo.student1;
import org.example.studentmanagerjava4.pojo.table.teacher;
import org.example.studentmanagerjava4.pojo.teacher1;

public interface TeacherService {
    //更新教师信息
    ResultTest<teacher> updateTeacherInformation(teacher teacher);

    //获取所有教师信息
    ResultTest<?> getAllTeacher(Integer pageNum, Integer pageSize);

    //更新教师基本信息
    ResultTest<?> updateTeacher(teacher1 teacher);

    //添加教师
    ResultTest<?> addTeacher(teacher1 teacher);

    //删除教师
    ResultTest<?> deleteTeacher(teacher1 teacher);

    //查询某一教师
    ResultTest<?> getOneTeacher(String name, String teacherId);

    //获取教师总数
    ResultTest<?> getCount();

    //获取所有教师（不分页）
    ResultTest<?> getAllTeachers();
}
