package org.example.studentmanagerjava4.service.impl;

import org.example.studentmanagerjava4.mapper.adminMapper;
import org.example.studentmanagerjava4.mapper.studentMapper;
import org.example.studentmanagerjava4.mapper.teacherMapper;
import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.accountLogin;
import org.example.studentmanagerjava4.pojo.registerInfo;
import org.example.studentmanagerjava4.pojo.table.Student;
import org.example.studentmanagerjava4.pojo.table.admin;
import org.example.studentmanagerjava4.pojo.table.teacher;
import org.example.studentmanagerjava4.service.LoginService;
import org.example.studentmanagerjava4.utils.MD5PasswordEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    private studentMapper studentmapper;

    @Autowired
    private adminMapper adminmapper;

    @Autowired
    private teacherMapper teachermapper;
    @Autowired
    private MD5PasswordEncoder md5PasswordEncoder;

    /**
     * 学生注册
     * @param registerinfo
     * @return
     */
    @Override
    public ResultTest<?> registerinfo(registerInfo registerinfo) {
        if(studentmapper.selectStudent(registerinfo.getStudentid(),registerinfo.getName()).size()>0){
            String repassword = md5PasswordEncoder.encode(registerinfo.getPassword());
            Integer influenceRow = studentmapper.addPassward(registerinfo.getStudentid(),repassword);
            if(influenceRow.equals(1)){
                return ResultTest.success();
            }
            else{
                return ResultTest.error(404,"注册失败");
            }
        }else{
            return ResultTest.error(404,"未找到对应学生");
        }
    }

    @Override
    public ResultTest<?> loginStudentService(accountLogin accountlogin) {
        String repassword = md5PasswordEncoder.encode(accountlogin.getPassword());
        List<Student> studentlist = studentmapper.getStudent(accountlogin.getId(),repassword);
        if(studentlist.size() == 0){
            return ResultTest.error(404,"用户名或密码错误");
        }else{
            return ResultTest.success(studentlist.get(0));
        }
    }

    @Override
    public ResultTest<?> loginTeacherService(accountLogin accountlogin) {
        List<teacher> teacherlist = teachermapper.getTeacher(accountlogin.getId(),accountlogin.getPassword());
        if(teacherlist.size() == 0){
            return ResultTest.error(404,"用户名或密码错误");
        }else{
            return ResultTest.success(teacherlist.get(0));
        }
    }

    @Override
    public ResultTest<?> loginAdminService(accountLogin accountlogin) {
        List<admin> adminlist = adminmapper.getAdmin(accountlogin.getId(),accountlogin.getPassword());
        if(adminlist.size() == 0){
            return ResultTest.error(404,"用户名或密码错误");
        }else{
            return ResultTest.success(adminlist.get(0));
        }
    }

    @Override
    public ResultTest<?> deleteAccount(Integer role, String id) {
        if(role.equals(1)){
            Integer i1 = studentmapper.deleteAccount(id);
            if(i1.equals(1)){
                return ResultTest.success("注销成功");
            }else{
                return ResultTest.error(404,"注销失败");
            }
        }
        else if(role.equals(2)){
            Integer i2 = teachermapper.deleteAccount(id);
            if(i2.equals(1)){
                return ResultTest.success("注销成功");
            }else{
                return ResultTest.error(404,"注销失败");
            }
        }
        else{
            Integer i3 = adminmapper.deleteAccount(id);
            if(i3.equals(1)){
                return ResultTest.success("注销成功");
            }else{
                return ResultTest.error(404,"注销失败");
            }
        }
    }
}
