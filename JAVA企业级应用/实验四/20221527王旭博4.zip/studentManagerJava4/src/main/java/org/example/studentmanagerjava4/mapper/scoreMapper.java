package org.example.studentmanagerjava4.mapper;

import org.apache.ibatis.annotations.*;
import org.example.studentmanagerjava4.pojo.pingfen;
import org.example.studentmanagerjava4.pojo.table.rank;
import org.example.studentmanagerjava4.pojo.table.score;
import org.example.studentmanagerjava4.pojo.teacherclass;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface scoreMapper {
    @Insert("insert into score (studentName,teacherName,courseName,className,grade,semester) values (#{studentName},#{teacherName},#{courseName},#{className},#{grade},#{semester})")
    int selectCourse(String studentName, String teacherName, String courseName, String className, Integer grade, Integer semester);

    @Select("select * from score where studentName = #{studentName}")
    List<score> haveSelectCourseByStudentName(String studentName);

    @Delete("delete from score where studentName = #{studentName} and courseName = #{courseName}")
    int deleteCourseByStudentName(String studentName, String courseName);

    @Select("select teacherName, courseName, className, grade, semester, COUNT(studentName) AS studentNum FROM score WHERE teacherName = #{teacherName}GROUP BY teacherName, courseName, className, grade, semester ORDER BY courseName, className")
    List<teacherclass> getInformationByTeacherName(String teacherName);

    @Select("select teacherName, courseName, className, grade, semester, COUNT(studentName) AS studentNum FROM score WHERE teacherName = #{teacherName} and courseName = #{courseName} GROUP BY teacherName, courseName, className, grade, semester ORDER BY courseName, className")
    List<teacherclass> getInformationByTeacherNameAndCourse(String teacherName, String courseName);

    @Select("SELECT s.studentId, sc.studentName, sc.courseName, sc.pingshigrade, sc.shiyangrade, sc.qizhonggrade, sc.qimograde, sc.finalgrade " +
            "FROM score sc " +
            "JOIN student s ON sc.studentName = s.name " +
            "WHERE sc.className = #{className}")
    List<pingfen> getScoreWithClassName(String className);

    @Select("select count(*) from score where className = #{className}")
    Integer getScoreCount(String className);

    @Update("update score set pingshigrade = #{pingshigrade}, shiyangrade = #{shiyangrade}, qizhonggrade = #{qizhonggrade}, qimograde = #{qimograde} where studentName = #{studentName} and courseName = #{courseName}")
    int pingfen(String studentName, String courseName, Integer pingshigrade, Integer shiyangrade, Integer qizhonggrade, Integer qimograde);

    @Select("SELECT s.studentId, sc.studentName, sc.courseName, sc.pingshigrade, sc.shiyangrade, sc.qizhonggrade, sc.qimograde, sc.finalgrade " +
            "FROM score sc " +
            "JOIN student s ON sc.studentName = s.name " +
            "WHERE sc.className = #{className} and sc.studentName = #{studentName}")
    List<pingfen> getScoreWithClassNameAndStudentName(String className, String studentName);

    @Update("update score set pingshigrade = #{pingshigrade},shiyangrade = #{shiyangrade},qizhonggrade = #{qizhonggrade},qimograde = #{qimograde} where className = #{className}")
    int setStudentScore(String className, Integer pingshigrade, Integer shiyangrade, Integer qizhonggrade, Integer qimograde);

    @Select("select * from score where semester = #{semester} and studentName = #{studentName}")
    List<score> getScoreStudentSemester(Integer semester, String studentName);

    @Select("select * from `rank`")
    List<rank> getPaihangbang();

    @Select("select name from student where studentId = #{studentId}")
    String getStudentName(String studentId);

    @Select("select * from `rank` where studentName = #{studentName}")
    List<rank> queryrank(String studentName);
}
