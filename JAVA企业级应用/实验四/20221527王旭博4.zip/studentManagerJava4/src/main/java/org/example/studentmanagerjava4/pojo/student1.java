package org.example.studentmanagerjava4.pojo;

import lombok.Data;

@Data
public class student1 {
    private String studentId;//学生学号
    private String name;//学生姓名
    private String phone;//电话
    private String province;//省
    private String city;//市
    private String gender;//性别
    private String political;//政治面貌
    private String email;//邮箱
    private String academy;//学院
}
