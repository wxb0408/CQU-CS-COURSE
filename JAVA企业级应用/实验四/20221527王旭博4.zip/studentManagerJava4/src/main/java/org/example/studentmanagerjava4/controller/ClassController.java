package org.example.studentmanagerjava4.controller;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.table.teacher_class;
import org.example.studentmanagerjava4.service.impl.ClassServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 教学班控制类
 */
@RestController //绑定HTTP响应体和返回，HTTP参数和方法参数
@RequestMapping("class") //类中的所有处理方法都将继承这个基础路径
public class ClassController {

    @Autowired
    private ClassServiceImpl classService;

    /**
     * 查询所有的教学班级
     * @param pageNum
     * @param pageSize
     * @return
     */
    @GetMapping("/getAllClass")
    public ResultTest<?> getAllClass(@RequestParam("pageNum") Integer pageNum, @RequestParam("pageSize") Integer pageSize){
        return classService.getAllClass(pageNum,pageSize);
    }

    /**
     * 没有分页的查询所有教学班
     * @return
     */
    @GetMapping("/getAllClasses")
    public ResultTest<?> getAllClasses(){
        return classService.getAllClasses();
    }

    /**
     * 获取当前教学班的数量
     * @return
     */
    @GetMapping("/getCount")
    public ResultTest<?> getCount(){
        return classService.getCount();
    }

    /**
     * 条件查询部分的教学班信息
     * @param teacherName
     * @param className
     * @param courseName
     * @return
     */
    @GetMapping("/getSomeClass")
    public ResultTest<?> getSomeClass(@RequestParam("teacherName") String teacherName,@RequestParam("className") String className,@RequestParam("courseName") String courseName){
        return classService.getSomeClass(teacherName,className,courseName);
    }

    /**
     * 更新某一课程的信息
     * @param classes
     * @return
     */
    @PostMapping("/updateClass")
    public ResultTest<?> updateClass(@RequestBody teacher_class classes){
        return classService.updateClass(classes);
    }

    /**
     * 删除教学班信息
     * @param classes
     * @return
     */
    @PostMapping("/deleteClass")
    public ResultTest<?> deleteClass(@RequestBody teacher_class classes){
        return classService.deleteClass(classes);
    }

    /**
     * 添加班级信息的接口方法
     * @param classes 通过请求体接收的班级信息对象，包含要添加的班级详细信息
     * @return 返回添加班级操作的结果，封装在ResultTest对象中，类型为泛型？
     */
    @PostMapping("/addClass")
    public ResultTest<?> addClass(@RequestBody teacher_class classes){
        return classService.addClass(classes);
    }

    /**
     * 获取当前教学班中老师数量
     * @return
     */
    @GetMapping("/getTeacherCount")
    public ResultTest<?> getTeacherCount(){
        return classService.getTeacherCount();
    }

    /**
     * 获取当前教学班中课程数量
     * @return
     */
    @GetMapping("/getCourseCount")
    public ResultTest<?> getCourseCount(){
        return classService.getCourseCount();
    }

    /**
     * 根据课程名查询班级信息
     * @param courseName
     * @return
     */
    @GetMapping("getClassByCourseName")
    public ResultTest<?> getClassByCourseName(@RequestParam("courseName") String courseName){
        return classService.getClassByCourseName(courseName);
    }
}
