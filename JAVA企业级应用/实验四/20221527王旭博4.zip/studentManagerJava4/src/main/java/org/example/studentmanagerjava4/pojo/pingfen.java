package org.example.studentmanagerjava4.pojo;

import lombok.Data;

/**
 * 处理评分系统相关表单
 */
@Data
public class pingfen {
    private String studentId;//学生学号
    private String studentName;//学生姓名
    private String courseName;//课程名称
    private Integer pingshigrade;//平时成绩
    private Integer shiyangrade;//实验成绩
    private Integer qizhonggrade;//期中成绩
    private Integer qimograde;//期末成绩
    private Integer finalgrade;//总成绩
}
