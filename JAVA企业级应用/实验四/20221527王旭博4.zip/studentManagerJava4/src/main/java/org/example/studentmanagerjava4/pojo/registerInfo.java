package org.example.studentmanagerjava4.pojo;

import lombok.Data;

/**
 * 注册时用于接收数据的实体类
 */
@Data
public class registerInfo {
    private String studentid;//学生学号
    private String name;//学生姓名
    private String password;//账号密码
}
