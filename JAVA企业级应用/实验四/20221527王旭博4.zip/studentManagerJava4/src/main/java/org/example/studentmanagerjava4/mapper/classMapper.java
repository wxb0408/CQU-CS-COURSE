package org.example.studentmanagerjava4.mapper;

import org.apache.ibatis.annotations.*;
import org.example.studentmanagerjava4.pojo.courseTeacherCount;
import org.example.studentmanagerjava4.pojo.table.teacher_class;
import org.example.studentmanagerjava4.pojo.teacherCourseCount;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface classMapper {
    @Select("select * from teacher_class LIMIT #{pageSize} OFFSET #{pageNum}")
    List<teacher_class> getAllClass(Integer pageNum, Integer pageSize);

    @Select("select count(*) from teacher_class")
    Integer getCount();

    @Select("select * from teacher_class")
    List<teacher_class> getAllClasses();

    @Update("update teacher_class set teacherName = #{teacherName},courseName = #{courseName},grade = #{grade},semester = #{semester} where className = #{className}")
    int updateClass(String teacherName, String className, String courseName, Integer grade, Integer semester);
    @Delete("delete from teacher_class where className = #{className}")
    int deleteClass(String className);

    @Insert("insert into teacher_class (teacherName,className,courseName,grade,semester) values (#{teacherName},#{className},#{courseName},#{grade},#{semester})")
    int addClass(String teacherName, String className, String courseName, Integer grade, Integer semester);

    @Select("select teacherName,count(*) as teacherCount from teacher_class group by teacherName")
    List<teacherCourseCount> getTeacherCount();

    @Select("select courseName,count(*) as courseCount from teacher_class group by courseName")
    List<courseTeacherCount> getCourseCount();

    @Select("select * from teacher_class where courseName = #{courseName}")
    List<teacher_class> getClassByCourseName(String courseName);
}
