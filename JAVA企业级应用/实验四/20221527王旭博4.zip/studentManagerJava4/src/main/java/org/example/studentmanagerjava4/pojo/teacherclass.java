package org.example.studentmanagerjava4.pojo;

import lombok.Data;

@Data
public class teacherclass {
    private String teacherName;//教师姓名
    private String courseName;//课程名称
    private String className;//教学班号
    private Integer grade;//课程学分
    private Integer semester;//开课学期
    private Integer studentNum;//学生人数
}
