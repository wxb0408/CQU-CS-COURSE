package org.example.studentmanagerjava4.service;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.student;
import org.example.studentmanagerjava4.pojo.student1;
import org.example.studentmanagerjava4.pojo.table.Student;

public interface StudentService {
    //更新学生的信息
    ResultTest<Student> updateStudentInformation(Student student);

    //获取全部学生的信息
    ResultTest<?> getAllStudent(Integer pageNum, Integer pageSize);

    //编辑学生信息
    ResultTest<?> updateStudent(student student);

    //管理员添加学生
    ResultTest<?> addStudent(student student);

    //管理员删除学生
    ResultTest<?> deleteStudent(student1 student);

    //管理员查询学生
    ResultTest<?> getOneStudent(String name, String studentId);

    //获取学生总数
    ResultTest<?> getCount();
}
