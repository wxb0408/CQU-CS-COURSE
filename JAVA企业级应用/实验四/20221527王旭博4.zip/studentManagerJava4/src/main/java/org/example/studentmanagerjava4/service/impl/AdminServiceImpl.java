package org.example.studentmanagerjava4.service.impl;

import org.example.studentmanagerjava4.mapper.adminMapper;
import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.table.admin;
import org.example.studentmanagerjava4.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private adminMapper adminmapper;

    /**
     * 管理员的信息更新
     * @param admin
     * @return
     */
    @Override
    public ResultTest<admin> updateAdminInformation(admin admin) {
        String administratorId = admin.getAdministratorId();
        String phone =admin.getPhone();
        String gender = admin.getGender();
        String email = admin.getEmail();
        Integer i = adminmapper.updateAdminInformation(administratorId,phone,gender,email);
        if(i.equals(1)){
            return ResultTest.success(admin);
        }
        else{
            return ResultTest.error(404,"更新信息失败");
        }
    }
}
