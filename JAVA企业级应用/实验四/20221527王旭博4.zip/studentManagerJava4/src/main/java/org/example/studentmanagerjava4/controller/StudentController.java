package org.example.studentmanagerjava4.controller;


import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.student;
import org.example.studentmanagerjava4.pojo.student1;
import org.example.studentmanagerjava4.pojo.table.Student;
import org.example.studentmanagerjava4.pojo.table.course;
import org.example.studentmanagerjava4.service.impl.StudentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 学生控制层
 */
@RestController //绑定HTTP响应体和返回，HTTP参数和方法参数
@RequestMapping("student") //类中的所有处理方法都将继承这个基础路径
public class StudentController {

    @Autowired
    private StudentServiceImpl studentservice;

    /**
     * 更新学生信息
     * @param student
     * @return
     */
    @PostMapping("/updateInformation")
    public ResultTest<Student> updateStudentInformation(@RequestBody Student student){
        return studentservice.updateStudentInformation(student);
    }

    /**
     * 获取所有学生
     * @param pageNum
     * @param pageSize
     * @return
     */
    @GetMapping("/getAllStudent")
    public ResultTest<?> getAllStudent(@RequestParam("pageNum") Integer pageNum,@RequestParam("pageSize") Integer pageSize){
        return studentservice.getAllStudent(pageNum,pageSize);
    }

    /**
     * 更新学生信息
     * @param student
     * @return
     */
    @PostMapping("/updateStudent")
    public ResultTest<?> updateStudent(@RequestBody student student){
        return studentservice.updateStudent(student);
    }

    /**
     * 添加学生
     * @param student
     * @return
     */
    @PostMapping("/addStudent")
    public ResultTest<?> addStudent(@RequestBody student student){
        return studentservice.addStudent(student);
    }

    /**
     * 删除学生
     * @param student
     * @return
     */
    @PostMapping("/deleteStudent")
    public ResultTest<?> deleteStudent(@RequestBody student1 student){
        return studentservice.deleteStudent(student);
    }

    /**
     * 获取学生信息
     * @param name
     * @param studentId
     * @return
     */
    @GetMapping("/getOneStudent")
    public ResultTest<?> getOneStudent(@RequestParam("name") String name,@RequestParam("studentId") String studentId){
        return studentservice.getOneStudent(name,studentId);
    }

    /**
     * 获取学生数量
     * @return
     */
    @GetMapping("/getCount")
    public ResultTest<?> getCount(){
        return studentservice.getCount();
    }

}
