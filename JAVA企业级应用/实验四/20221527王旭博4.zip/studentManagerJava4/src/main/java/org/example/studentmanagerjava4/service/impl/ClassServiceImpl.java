package org.example.studentmanagerjava4.service.impl;

import org.example.studentmanagerjava4.mapper.classMapper;
import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.courseTeacherCount;
import org.example.studentmanagerjava4.pojo.table.course;
import org.example.studentmanagerjava4.pojo.table.teacher_class;
import org.example.studentmanagerjava4.pojo.teacherCourseCount;
import org.example.studentmanagerjava4.service.ClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 教学班级对应的服务层
 */
@Service
public class ClassServiceImpl implements ClassService {
    @Autowired
    private classMapper classmapper;

    /**
     * 查询所有的教学班级
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public ResultTest<?> getAllClass(Integer pageNum, Integer pageSize) {
        pageNum = (pageNum - 1) * pageSize;
        List<teacher_class> classList = classmapper.getAllClass(pageNum,pageSize);
        return ResultTest.success(classList);
    }

    /**
     * 查看当前教学班的数量
     * @return
     */
    @Override
    public ResultTest<?> getCount() {
        Integer count = classmapper.getCount();
        return ResultTest.success(count);
    }

    /**
     * 条件查询部分教学班信息
     * @param teacherName
     * @param className
     * @param courseName
     * @return
     */
    @Override
    public ResultTest<?> getSomeClass(String teacherName, String className, String courseName) {
        // 第一步：先查询所有教学班信息
        List<teacher_class> classList = classmapper.getAllClasses();  // 获取所有班级信息
        // 第二步：如果 teacherName 不为空，进行过滤
        if (teacherName != null && !teacherName.isEmpty()) {
            classList = classList.stream()
                    .filter(c -> c.getTeacherName().contains(teacherName))  // 根据教师名称过滤
                    .collect(Collectors.toList());
        }
        // 第三步：如果 className 不为空，进行过滤
        if (className != null && !className.isEmpty()) {
            classList = classList.stream()
                    .filter(c -> c.getClassName().contains(className))  // 根据班级名称过滤
                    .collect(Collectors.toList());
        }
        // 第四步：如果 courseName 不为空，进行过滤
        if (courseName != null && !courseName.isEmpty()) {
            classList = classList.stream()
                    .filter(c -> c.getCourseName().contains(courseName))  // 根据课程名称过滤
                    .collect(Collectors.toList());
        }
        // 返回最终的结果
        return ResultTest.success(classList);
    }

    @Override
    public ResultTest<?> updateClass(teacher_class classes) {
        String teacherName = classes.getTeacherName();
        String className = classes.getClassName();
        String courseName = classes.getCourseName();
        Integer grade = classes.getGrade();
        Integer semester = classes.getSemester();
        if(classmapper.updateClass(teacherName,className,courseName,grade,semester) == 1){
            return ResultTest.success();
        }else {
            return ResultTest.error(404,"编辑失败");
        }
    }

    @Override
    public ResultTest<?> deleteClass(teacher_class classes) {
        String className = classes.getClassName();
        if(classmapper.deleteClass(className) == 1){
            return ResultTest.success();
        }else {
            return ResultTest.error(404,"编辑失败");
        }
    }

    @Override
    public ResultTest<?> addClass(teacher_class classes) {
        String teacherName = classes.getTeacherName();
        String className = classes.getClassName();
        String courseName = classes.getCourseName();
        Integer grade = classes.getGrade();
        Integer semester = classes.getSemester();
        if(classmapper.addClass(teacherName,className,courseName,grade,semester) == 1){
            return ResultTest.success();
        }else {
            return ResultTest.error(404,"添加失败");
        }
    }

    @Override
    public ResultTest<?> getTeacherCount() {
        List<teacherCourseCount> teacherCourseCountList = classmapper.getTeacherCount();
        return ResultTest.success(teacherCourseCountList);
    }

    @Override
    public ResultTest<?> getCourseCount() {
        List<courseTeacherCount> courseTeacherCountList = classmapper.getCourseCount();
        return ResultTest.success(courseTeacherCountList);
    }

    @Override
    public ResultTest<?> getAllClasses() {
        List<teacher_class> classList = classmapper.getAllClasses();
        return ResultTest.success(classList);
    }

    @Override
    public ResultTest<?> getClassByCourseName(String courseName) {
        List<teacher_class> classList = classmapper.getClassByCourseName(courseName);
        return ResultTest.success(classList);
    }

}
