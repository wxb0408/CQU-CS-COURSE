package org.example.studentmanagerjava4.pojo.table;

import lombok.Data;

/**
 * 管理员相关实体类
 */
@Data
public class admin {
    private String administratorId;//管理员id号
    private String name;//管理员姓名
    private String password;//密码
    private String phone;//管理员电话
    private String email;//管理员邮箱
    private String gender;//性别
    private String fileData;//头像
    private Integer role;//账号类型
}
