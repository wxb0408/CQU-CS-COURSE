package org.example.studentmanagerjava4.controller;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.student;
import org.example.studentmanagerjava4.pojo.student1;
import org.example.studentmanagerjava4.pojo.table.admin;
import org.example.studentmanagerjava4.pojo.table.teacher;
import org.example.studentmanagerjava4.pojo.teacher1;
import org.example.studentmanagerjava4.service.impl.TeacherServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 教师控制层
 */
@RestController //绑定HTTP响应体和返回，HTTP参数和方法参数
@RequestMapping("teacher") //类中的所有处理方法都将继承这个基础路径
public class TeacherController {
    @Autowired
    private TeacherServiceImpl teacherService;

    /**
     *
     * @param teacher
     * @return
     */
    @PostMapping("/updateInformation")
    public ResultTest<teacher> updateTeacherInformation(@RequestBody teacher teacher){
        return teacherService.updateTeacherInformation(teacher);
    }

    /**
     * 获取所有教师
     * @return
     */
    @GetMapping("/getAllTeachers")
    public ResultTest<?> getAllTeachers(){
        return teacherService.getAllTeachers();
    }

    /**
     * 获取所有教师
     * @param pageNum
     * @param pageSize
     * @return
     */
    @GetMapping("/getAllTeacher")
    public ResultTest<?> getAllTeacher(@RequestParam("pageNum") Integer pageNum,@RequestParam("pageSize") Integer pageSize){
        return teacherService.getAllTeacher(pageNum,pageSize);
    }

    /**
     * 更新教师信息
     * @param teacher
     * @return
     */
    @PostMapping("/updateTeacher")
    public ResultTest<?> updateTeacher(@RequestBody teacher1 teacher){
        return teacherService.updateTeacher(teacher);
    }

    /**
     * 添加教师
     * @param teacher
     * @return
     */
    @PostMapping("/addTeacher")
    public ResultTest<?> addTeacher(@RequestBody teacher1 teacher){
        return teacherService.addTeacher(teacher);
    }

    /**
     * 删除教师
     * @param teacher
     * @return
     */
    @PostMapping("/deleteTeacher")
    public ResultTest<?> deleteTeacher(@RequestBody teacher1 teacher){
        return teacherService.deleteTeacher(teacher);
    }

    /**
     * 获取教师信息
     * @param name
     * @param teacherId
     * @return
     */
    @GetMapping("/getOneTeacher")
    public ResultTest<?> getOneTeacher(@RequestParam("name") String name,@RequestParam("teacherId") String teacherId){
        return teacherService.getOneTeacher(name,teacherId);
    }

    /**
     * 统计教师数量
     * @return
     */
    @GetMapping("/getCount")
    public ResultTest<?> getCount(){
        return teacherService.getCount();
    }
}
