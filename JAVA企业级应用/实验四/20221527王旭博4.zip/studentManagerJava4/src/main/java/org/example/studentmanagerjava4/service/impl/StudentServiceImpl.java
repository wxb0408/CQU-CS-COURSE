package org.example.studentmanagerjava4.service.impl;

import org.example.studentmanagerjava4.mapper.studentMapper;
import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.student;
import org.example.studentmanagerjava4.pojo.student1;
import org.example.studentmanagerjava4.pojo.table.Student;
import org.example.studentmanagerjava4.pojo.table.course;
import org.example.studentmanagerjava4.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.example.studentmanagerjava4.utils.MD5PasswordEncoder;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    private studentMapper studentmapper;
    @Autowired
    private MD5PasswordEncoder md5PasswordEncoder;

    /**
     * 更新学生的信息
     * @param student
     * @return
     */
    @Override
    public ResultTest<Student> updateStudentInformation(Student student) {
        String studentid = student.getStudentId();
        String password = md5PasswordEncoder.encode(student.getPassword());
        String phone = student.getPhone();
        String province = student.getProvince();
        String city = student.getCity();
        String gender = student.getGender();
        String political = student.getPolitical();
        String email = student.getEmail();
        String academy = student.getAcademy();
        System.out.println(gender);
        Integer influencerow = studentmapper.updateinformation(studentid,phone,province,city,gender,political,email,academy);
        if(influencerow.equals(1)){
            return ResultTest.success(student);
        }else{
            return ResultTest.error(404,"更新失败");
        }
    }

    @Override
    public ResultTest<?> getAllStudent(Integer pageNum, Integer pageSize) {
        pageNum = (pageNum - 1) * pageSize;
        List<Student> studentList = studentmapper.getAllStudent(pageNum,pageSize);
        return ResultTest.success(studentList);
    }

    @Override
    public ResultTest<?> updateStudent(student student) {
        String studentId = student.getStudentId();
        String name = student.getName();
        if(studentmapper.updateStudent(studentId,name) == 1){
            return ResultTest.success();
        }else{
            return ResultTest.error(404,"编辑失败");
        }
    }

    @Override
    public ResultTest<?> addStudent(student student) {
        String studentId = student.getStudentId();
        String name = student.getName();
        if(studentmapper.addStudent(studentId,name) == 1){
            return ResultTest.success();
        }else{
            return ResultTest.error(404,"添加失败");
        }
    }

    @Override
    public ResultTest<?> deleteStudent(student1 student) {
        String studentId = student.getStudentId();
        if(studentmapper.deleteStudent(studentId) == 1){
            return ResultTest.success();
        }else{
            return ResultTest.error(404,"删除失败");
        }
    }

    @Override
    public ResultTest<?> getOneStudent(String name, String studentId) {
        if(name == ""){
            List<Student> studentList = studentmapper.getOneStudentBystudentId(studentId);
            if(studentList.size()>0){
                return ResultTest.success(studentList);
            }else{
                return ResultTest.error(404,"查询失败");
            }
        }else if(studentId == ""){
            List<Student> studentList = studentmapper.getOneStudentByName(name);
            if(studentList.size()>0){
                return ResultTest.success(studentList);
            }else{
                return ResultTest.error(404,"查询失败");
            }
        }else{
            List<Student> studentList = studentmapper.getOneStudent(name,studentId);
            if(studentList.size()>0){
                return ResultTest.success(studentList);
            }else{
                return ResultTest.error(404,"查询失败");
            }
        }
    }

    @Override
    public ResultTest<?> getCount() {
        Integer count = studentmapper.getCount();
        return ResultTest.success(count);
    }
}
