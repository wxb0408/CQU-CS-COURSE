package org.example.studentmanagerjava4.service.impl;

import org.example.studentmanagerjava4.mapper.courseMapper;
import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.table.course;
import org.example.studentmanagerjava4.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseServiceImpl implements CourseService {
    @Autowired
    private courseMapper coursemapper;


    @Override
    public ResultTest<?> getAllCourse(Integer pageNum, Integer pageSize) {
        pageNum = (pageNum - 1) * pageSize;
        List<course> courseList = coursemapper.getAllClass(pageNum,pageSize);
        return ResultTest.success(courseList);
    }

    @Override
    public ResultTest<?> updateCourse(course course) {
        String courseName = course.getCourseName();
        String courseId = course.getCourseId();
        String academy = course.getAcademy();
        Integer grade = course.getGrade();
        Integer semester = course.getSemester();
        if(coursemapper.updateCourse(courseName,courseId,academy,grade,semester) == 1){
            return ResultTest.success();
        }else {
            return ResultTest.error(404,"编辑失败");
        }
    }

    @Override
    public ResultTest<?> addCourse(course course) {
        String courseName = course.getCourseName();
        String courseId = course.getCourseId();
        String academy = course.getAcademy();
        Integer grade = course.getGrade();
        Integer semester = course.getSemester();
        if(coursemapper.addCourse(courseName,courseId,academy,grade,semester) == 1){
            return ResultTest.success();
        }else {
            return ResultTest.error(404,"添加失败");
        }
    }

    @Override
    public ResultTest<?> deleteCourse(course course) {
        String courseId = course.getCourseId();
        if(coursemapper.deleteCourse(courseId) == 1){
            return ResultTest.success();
        }else {
            return ResultTest.error(404,"删除失败");
        }
    }

    @Override
    public ResultTest<?> getOneCourse(String courseName) {
        List<course> courseList = coursemapper.getOneClass(courseName);
        if(courseList.size() == 1){
            return ResultTest.success(courseList);
        }
        else{
            return ResultTest.error(404,"未找到相关课程信息");
        }
    }

    @Override
    public ResultTest<?> getAllCourses() {
        List<course> courses = coursemapper.getAllClasss();
        return ResultTest.success(courses);
    }
}
