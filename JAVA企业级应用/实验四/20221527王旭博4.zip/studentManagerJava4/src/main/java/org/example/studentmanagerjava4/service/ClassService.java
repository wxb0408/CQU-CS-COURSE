package org.example.studentmanagerjava4.service;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.table.teacher_class;

public interface ClassService {
    //查询所有的教学班级
    ResultTest<?> getAllClass(Integer pageNum, Integer pageSize);

    //获取当前教学班的数量
    ResultTest<?> getCount();

    //条件查询部分教学班信息
    ResultTest<?> getSomeClass(String teacherName, String className, String courseName);

    //更新某一课程的信息
    ResultTest<?> updateClass(teacher_class classes);

    //删除某一教学班
    ResultTest<?> deleteClass(teacher_class classes);

    //添加某一课程信息
    ResultTest<?> addClass(teacher_class classes);

    //查询所有教师教学班数量
    ResultTest<?> getTeacherCount();

    //查询所有课程教学班数量
    ResultTest<?> getCourseCount();

    //查询所有的教学班信息
    ResultTest<?> getAllClasses();

    //通过课程名查询课程对应的教学班
    ResultTest<?> getClassByCourseName(String courseName);
}
