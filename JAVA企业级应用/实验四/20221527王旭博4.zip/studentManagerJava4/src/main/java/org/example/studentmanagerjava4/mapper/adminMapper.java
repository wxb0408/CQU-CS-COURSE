package org.example.studentmanagerjava4.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.example.studentmanagerjava4.pojo.table.admin;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface adminMapper {
    @Select("select * from admin where administratorId = #{id} and password = #{password}")
    List<admin> getAdmin(String id, String password);

    @Update("update admin set phone = #{phone},gender = #{gender},email = #{email} where administratorId = #{administratorId}")
    Integer updateAdminInformation(String administratorId, String phone, String gender, String email);

    @Delete("delete from admin where administratorId = #{id}")
    Integer deleteAccount(String id);
}
