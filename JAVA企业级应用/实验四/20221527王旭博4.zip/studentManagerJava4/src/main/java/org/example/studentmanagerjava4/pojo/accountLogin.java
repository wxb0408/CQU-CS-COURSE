package org.example.studentmanagerjava4.pojo;

import lombok.Data;

/**
 * 接收登录账号格式用的实体类
 */
@Data
public class accountLogin {
    private Integer role;//登录账号的角色
    private String id;//id号
    private String password;//登录密码
}
