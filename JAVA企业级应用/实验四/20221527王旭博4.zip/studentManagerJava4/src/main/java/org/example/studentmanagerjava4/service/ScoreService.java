package org.example.studentmanagerjava4.service;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.pingfen;
import org.example.studentmanagerjava4.pojo.score1;

public interface ScoreService {
    //添加学生选课信息
    ResultTest<?> selectCourse(score1 score);

    //判断学生是否已经选过该门课
    ResultTest<?> haveSelectCourseByStudentName(String studentName);

    //删除学生选课数据
    ResultTest<?> deleteCourseByStudentName(String studentName, String courseName);

    //根据教师名获取选课信息
    ResultTest<?> getInformationByTeacherName(String teacherName);

    //根据教师名和课程名称查询选课信息
    ResultTest<?> getInformationByTeacherNameAndCourse(String teacherName, String courseName);

    //根据教学班查询成绩信息
    ResultTest<?> getScoreWithClassName(Integer pageNum, Integer pageSize, String className,String sortField);

    //获取教学班人数
    ResultTest<?> getScoreCount(String className);

    //评分
    ResultTest<?> pingfen(pingfen score);

    //获取学生成绩
    ResultTest<?> getStudentScore(String studentName, String className);

    //统一设置学生分数
    ResultTest<?> setStudentScore(pingfen score);

    //根据教学班查询成绩信息（不分页）
    ResultTest<?> getAllScoreWithClassName(String className);

    //根据学期和学生姓名获取学生课程信息
    ResultTest<?> getScoreStudentSemester(Integer semester, String studentName);

    //获取学生排名
    ResultTest<?> getPaihangbang();

    //查询某一学生排名
    ResultTest<?> queryrank(String studentName, String studentId);
}
