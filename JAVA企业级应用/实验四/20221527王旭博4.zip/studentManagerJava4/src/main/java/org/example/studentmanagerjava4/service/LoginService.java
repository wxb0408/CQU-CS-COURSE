package org.example.studentmanagerjava4.service;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.accountLogin;
import org.example.studentmanagerjava4.pojo.registerInfo;

public interface LoginService {
    //学生注册
    ResultTest<?> registerinfo(registerInfo registerinfo);

    //学生登录
    ResultTest<?> loginStudentService(accountLogin accountlogin);

    //教师登录
    ResultTest<?> loginTeacherService(accountLogin accountlogin);

    //管理员登录
    ResultTest<?> loginAdminService(accountLogin accountlogin);

    //注销账户
    ResultTest<?> deleteAccount(Integer role, String id);
}
