package org.example.studentmanagerjava4.service;

import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.table.course;

public interface CourseService {
    //分页查询所有课程
    ResultTest<?> getAllCourse(Integer pageNum, Integer pageSize);

    //编辑课程信息
    ResultTest<?> updateCourse(course course);

    //添加课程信息
    ResultTest<?> addCourse(course course);

    //删除课程信息
    ResultTest<?> deleteCourse(course course);

    //查询某一个课程
    ResultTest<?> getOneCourse(String courseName);

    //获取所有的课程信息（不分页）
    ResultTest<?> getAllCourses();
}
