package org.example.studentmanagerjava4.pojo.table;

import lombok.Data;

/**
 * 教师和班级的对应信息
 */
@Data
public class teacher_class {
    private String teacherName;//教师姓名
    private String className;//班级名称
    private String courseName;//课程名称
    private Integer grade;//学分
    private Integer semester;//开课学期
}
