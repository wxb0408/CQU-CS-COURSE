package org.example.studentmanagerjava4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManagerJava4Application {

    public static void main(String[] args) {
        SpringApplication.run(StudentManagerJava4Application.class, args);
    }

}
