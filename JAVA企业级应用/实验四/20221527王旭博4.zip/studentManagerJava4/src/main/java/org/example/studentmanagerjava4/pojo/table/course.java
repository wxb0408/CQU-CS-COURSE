package org.example.studentmanagerjava4.pojo.table;

import lombok.Data;

/**
 * 课程对应实体类
 */
@Data
public class course {
    private String courseName;//课程名称
    private Integer grade;//课程对应学分
    private Integer semester;//开课学期
    private String courseId;//课程编号
    private String academy;//学院
}
