package org.example.studentmanagerjava4.service.impl;

import org.example.studentmanagerjava4.mapper.scoreMapper;
import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.pingfen;
import org.example.studentmanagerjava4.pojo.score1;
import org.example.studentmanagerjava4.pojo.table.rank;
import org.example.studentmanagerjava4.pojo.table.score;
import org.example.studentmanagerjava4.pojo.teacherclass;
import org.example.studentmanagerjava4.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;

@Service
public class ScoreServiceImpl implements ScoreService {

    @Autowired
    private scoreMapper scoremapper;

    /**
     * 添加学生选课信息
     * @param score
     * @return
     */
    @Override
    public ResultTest<?> selectCourse(score1 score) {
        System.out.println(score);
        String studentName = score.getStudentName();
        String teacherName = score.getTeacherName();
        String courseName = score.getCourseName();
        String className = score.getClassName();
        Integer grade = score.getGrade();
        Integer semester = score.getSemester();
        if(scoremapper.selectCourse(studentName,teacherName,courseName,className,grade,semester) == 1){
            return ResultTest.success();
        }else {
            return ResultTest.error(404,"添加失败");
        }
    }

    @Override
    public ResultTest<?> haveSelectCourseByStudentName(String studentName) {
        List<score> scorelist = scoremapper.haveSelectCourseByStudentName(studentName);
        return ResultTest.success(scorelist);
    }

    @Override
    public ResultTest<?> deleteCourseByStudentName(String studentName, String courseName) {
        if(scoremapper.deleteCourseByStudentName(studentName,courseName) == 1){
            return ResultTest.success();
        }else {
            return ResultTest.error(404,"删除失败");
        }
    }

    @Override
    public ResultTest<?> getInformationByTeacherName(String teacherName) {
        List<teacherclass> teacherclasslist = scoremapper.getInformationByTeacherName(teacherName);
        return ResultTest.success(teacherclasslist);
    }

    @Override
    public ResultTest<?> getInformationByTeacherNameAndCourse(String teacherName, String courseName) {
        List<teacherclass> teacherclasslist = scoremapper.getInformationByTeacherNameAndCourse(teacherName,courseName);
        return ResultTest.success(teacherclasslist);
    }

    @Override
    public ResultTest<?> getScoreWithClassName(Integer pageNum, Integer pageSize, String className, String sortField) {
        List<pingfen> pingfenlist = scoremapper.getScoreWithClassName(className);
        int offset = (pageNum - 1) * pageSize; // 计算分页偏移量
        // 定义一个映射，将字段名称映射到对应的排序函数
        Map<String, Function<pingfen, Comparable>> sortFieldMap = new HashMap<>();
        sortFieldMap.put("studentId", pingfen::getStudentId);
        sortFieldMap.put("pingshigrade", pingfen::getPingshigrade);
        sortFieldMap.put("shiyangrade", pingfen::getShiyangrade);
        sortFieldMap.put("qizhonggrade", pingfen::getQizhonggrade);
        sortFieldMap.put("qimograde", pingfen::getQimograde);
        sortFieldMap.put("finalgrade", pingfen::getFinalgrade);
        // 如果 sortField 非空且存在于映射中，则按对应的字段排序
        if (sortField != null && !sortField.isEmpty() && sortFieldMap.containsKey(sortField)) {
            pingfenlist.sort(Comparator.comparing(sortFieldMap.get(sortField)));
        }
        // 进行分页操作
        int total = pingfenlist.size(); // 总数据量
        int startIndex = Math.min(offset, total); // 确保偏移量不会越界
        int endIndex = Math.min(startIndex + pageSize, total); // 确保分页范围合法
        // 获取分页后的数据
        List<pingfen> pagedList = pingfenlist.subList(startIndex, endIndex);

        // 封装分页结果
        return ResultTest.success(pagedList);
    }

//    @Override
//    public ResultTest<?> getScoreWithClassName(Integer pageNum, Integer pageSize, String className,String sortField) {
//        List<pingfen> pingfenlist = scoremapper.getScoreWithClassName(className);
//        int offset = (pageNum - 1) * pageSize; // 计算分页偏移量
//        if (sortField != null && !sortField.isEmpty()) {
//            switch (sortField) {
//                case "studentId":
//                    pingfenlist.sort(Comparator.comparing(pingfen::getStudentId));
//                    break;
//                case "pingshigrade":
//                    pingfenlist.sort(Comparator.comparing(pingfen::getPingshigrade));
//                    break;
//                case "shiyangrade":
//                    pingfenlist.sort(Comparator.comparing(pingfen::getShiyangrade));
//                    break;
//                case "qizhonggrade":
//                    pingfenlist.sort(Comparator.comparing(pingfen::getQizhonggrade));
//                    break;
//                case "qimograde":
//                    pingfenlist.sort(Comparator.comparing(pingfen::getQimograde));
//                    break;
//                case "finalgrade":
//                    pingfenlist.sort(Comparator.comparing(pingfen::getFinalgrade));
//                    break;
//                default:
//                    break;
//            }
//        }
//        // 进行分页操作
//        int total = pingfenlist.size(); // 总数据量
//        int startIndex = Math.min(offset, total); // 确保偏移量不会越界
//        int endIndex = Math.min(startIndex + pageSize, total); // 确保分页范围合法
//        // 获取分页后的数据
//        List<pingfen> pagedList = pingfenlist.subList(startIndex, endIndex);
//        // 封装分页结果
//        return ResultTest.success(pagedList);
//    }

    @Override
    public ResultTest<?> getScoreCount(String className) {
        Integer count = scoremapper.getScoreCount(className);
        return ResultTest.success(count);
    }

    @Override
    public ResultTest<?> pingfen(pingfen score) {
        String studentName = score.getStudentName();
        String courseName = score.getCourseName();
        Integer pingshigrade = score.getPingshigrade();
        Integer shiyangrade = score.getShiyangrade();
        Integer qizhonggrade = score.getQizhonggrade();
        Integer qimograde = score.getQimograde();

        if(scoremapper.pingfen(studentName,courseName,pingshigrade,shiyangrade,qizhonggrade,qimograde) == 1){
            return ResultTest.success();
        }else{
            return ResultTest.error(404,"评分失败");
        }
    }

    @Override
    public ResultTest<?> getStudentScore(String studentName, String className) {
        List<pingfen> pingfenlist = scoremapper.getScoreWithClassNameAndStudentName(className,studentName);
        return ResultTest.success(pingfenlist);
    }

    @Override
    public ResultTest<?> setStudentScore(pingfen score) {
        String className = score.getCourseName();
        Integer pingshigrade = score.getPingshigrade();
        Integer shiyangrade = score.getShiyangrade();
        Integer qizhonggrade = score.getQizhonggrade();
        Integer qimograde = score.getQimograde();
        if(scoremapper.setStudentScore(className,pingshigrade,shiyangrade,qizhonggrade,qimograde) > 0){
            return ResultTest.success();
        }else {
            return ResultTest.error(404, "设置失败");
        }
    }

    @Override
    public ResultTest<?> getAllScoreWithClassName(String className) {
        List<pingfen> pingfenlist = scoremapper.getScoreWithClassName(className);
        return ResultTest.success(pingfenlist);
    }

    @Override
    public ResultTest<?> getScoreStudentSemester(Integer semester, String studentName) {
        List<score> scoreList = scoremapper.getScoreStudentSemester(semester,studentName);
        if(scoreList.size() >= 0){
            return ResultTest.success(scoreList);
        }else{
            return ResultTest.error(404,"查询失败");
        }
    }

    @Override
    public ResultTest<?> getPaihangbang() {
        List<rank> ranklist = scoremapper.getPaihangbang();
        return ResultTest.success(ranklist);
    }

    @Override
    public ResultTest<?> queryrank(String studentName, String studentId) {
        if(studentName == ""){
            String name = scoremapper.getStudentName(studentId);
            studentName = name;
        }
        List<rank> ranklist = scoremapper.queryrank(studentName);
        return ResultTest.success(ranklist);
    }
}
