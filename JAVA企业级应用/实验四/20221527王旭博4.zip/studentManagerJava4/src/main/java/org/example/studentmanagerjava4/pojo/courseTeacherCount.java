package org.example.studentmanagerjava4.pojo;

import lombok.Data;

@Data
public class courseTeacherCount {
    private String courseName;
    private String courseCount;
}
