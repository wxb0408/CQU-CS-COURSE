package org.example.studentmanagerjava4.controller;

import io.swagger.annotations.ApiOperation;
import org.example.studentmanagerjava4.pojo.ResultTest;
import org.example.studentmanagerjava4.pojo.accountLogin;
import org.example.studentmanagerjava4.pojo.registerInfo;
import org.example.studentmanagerjava4.service.impl.LoginServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 登录控制层
 */
@RestController //绑定HTTP响应体和返回，HTTP参数和方法参数
@RequestMapping("login") //类中的所有处理方法都将继承这个基础路径
public class LoginController {
    @Autowired
    public final LoginServiceImpl loginService;

    @Autowired
    public LoginController(LoginServiceImpl loginService){
        this.loginService = loginService;
    }

    /**
     * 三种人员的登录
     * @param accountlogin
     * @return
     */
    @PostMapping("/login")
    public ResultTest<?> login(@RequestBody accountLogin accountlogin){
        Integer s = accountlogin.getRole();
        if(s.equals(1)){
            return loginService.loginStudentService(accountlogin);
        } else if (accountlogin.getRole().equals(2)) {
            return loginService.loginTeacherService(accountlogin);
        }else{
            return loginService.loginAdminService(accountlogin);
        }
    }

    /**
     * 学生的注册
     * @param registerinfo
     * @return
     */
    @PostMapping("/register")
    public ResultTest<?> register(@RequestBody registerInfo registerinfo){
        return loginService.registerinfo(registerinfo);
    }

    /**
     * 三种人员账户注销
     * @param id
     * @param role
     * @return
     */
    @GetMapping("/delete")
    public ResultTest<?> deleteAccount(@RequestParam("id") String id,@RequestParam("role") Integer role)
    {
        return loginService.deleteAccount(role,id);
    }

}
