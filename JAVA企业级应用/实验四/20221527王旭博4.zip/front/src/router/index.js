import {createRouter, createWebHistory} from 'vue-router'
const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/',
            redirect: '/login'  // 当访问根路径时，自动重定向到 /login
        },
        {
            path: '/login',
            name: 'Login',
            component: () => import('@/views/LoginAccount.vue'),
        },
        {
            path: '/',
            name: 'Manager',
            component: () => import('@/views/Manager.vue'),
            redirect: '/home',
            children: [
                { path: 'home', name: 'Home', component: () => import('@/views/manager/Home.vue')},
                { path: 'course', name: 'Course', component: () => import('@/views/manager/Course.vue')},
                { path: 'student', name: 'Student', component: () => import('@/views/manager/Student.vue')},
                { path: 'class', name: 'Class', component: () => import('@/views/manager/Class.vue')},
                { path: 'selectcourse', name: 'SelectCourse', component: () => import('@/views/manager/SelectCourse.vue')},
                { path: 'teacherclass', name: 'TeacherClass', component: () => import('@/views/manager/TeacherClass.vue')},
                { path: 'teacherview', name: 'TeacherView', component: () => import('@/views/manager/TeacherView.vue')},
                { path: 'studentview', name: 'StudentView', component: () => import('@/views/manager/StudentView.vue')},
                { path: 'rank', name: 'Rank', component: () => import('@/views/manager/Rank.vue')},
                //
                // { path: 'person', name: 'Person', component: () => import('@/views/manager/Person.vue')},
                //
                { path: 'grade', name: 'Grade', component: () => import('@/views/manager/Grade.vue')},
                //
                // { path: 'grades', name: 'Grades', component: () => import('@/views/manager/Grades.vue')},
                //
                { path: 'teacher', name: 'Teacher', component: () => import('@/views/manager/Teacher.vue')},
            ]
        },

    ]
})
export default router