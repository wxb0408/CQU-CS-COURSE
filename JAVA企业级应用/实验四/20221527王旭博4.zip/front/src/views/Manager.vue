<template>
  <div>
    <div style="height: 60px; background-color: #fff; display: flex; align-items: center; border-bottom: 1px solid #ddd">
      <div style="flex: 1">
        <div style="padding-left: 20px; display: flex; align-items: center">
          <div style="font-weight: bold; font-size: 24px; margin-left: 5px">学生成绩管理系统</div>
        </div>
      </div>
      <div style="width: fit-content; padding-right: 10px; display: flex; align-items: center;">
        <img src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png" alt="" style="width: 40px; height: 40px">
        <span style="margin-left: 5px">{{user.name}}</span>
      </div>
    </div>
    <div style="display: flex">
      <div style="width: 200px; border-right: 1px solid #ddd; min-height: calc(100vh - 60px)">
        <el-menu
            router
            style="border: none"
            :default-active="$route.path"
            :default-openeds="['/home', '2','3']"
        >
          <!-- 首页菜单项 -->
          <el-menu-item index="/home">
            <el-icon><HomeFilled /></el-icon>
            <span>系统首页</span>
          </el-menu-item>
          <!-- 课程管理菜单 -->
          <el-sub-menu index="2" v-if="user.role === 3">
            <template #title>
              <el-icon><Memo /></el-icon>
              <span>教学管理</span>
            </template>
            <el-menu-item index="/course" v-if="user.role === 3">
              <el-icon><Document /></el-icon>
              <span>课程信息</span>
            </el-menu-item>
            <el-menu-item index="/class" v-if="user.role === 3">
              <el-icon><Document /></el-icon>
              <span>教学班管理</span>
            </el-menu-item>
<!--            <el-menu-item index="/grade" v-if="user.role === 2">-->
<!--              <el-icon><Document /></el-icon>-->
<!--              <span>成绩信息</span>-->
<!--            </el-menu-item>-->
          </el-sub-menu>
          <!-- 教师管理菜单 -->
          <el-sub-menu index="3" v-if="user.role === 2">
            <template #title>
              <el-icon><User /></el-icon>
              <span>教学管理</span>
            </template>
            <el-menu-item index="/teacherclass">
              <el-icon><UserFilled /></el-icon>
              <span>教学班管理</span>
            </el-menu-item>
            <el-menu-item index="/grade">
              <el-icon><UserFilled /></el-icon>
              <span>评分系统</span>
            </el-menu-item>
            <el-menu-item index="/teacherview">
              <el-icon><UserFilled /></el-icon>
              <span>成绩可视化</span>
            </el-menu-item>
          </el-sub-menu>
          <!-- 学生管理菜单 -->
          <el-sub-menu index="3" v-if="user.role === 1">
            <template #title>
              <el-icon><User /></el-icon>
              <span>课程管理</span>
            </template>
            <el-menu-item index="/selectcourse">
              <el-icon><UserFilled /></el-icon>
              <span>选课系统</span>
            </el-menu-item>
            <el-menu-item index="/studentview">
              <el-icon><UserFilled /></el-icon>
              <span>成绩信息</span>
            </el-menu-item>
          </el-sub-menu>
          <!-- 用户管理菜单 -->
          <el-sub-menu index="3" v-if="user.role === 3">
            <template #title>
              <el-icon><User /></el-icon>
              <span>用户管理</span>
            </template>
            <el-menu-item index="/teacher">
              <el-icon><UserFilled /></el-icon>
              <span>教师管理</span>
            </el-menu-item>
            <el-menu-item index="/student">
              <el-icon><UserFilled /></el-icon>
              <span>学生管理</span>
            </el-menu-item>
          </el-sub-menu>
          <!-- 个人信息菜单 -->
<!--          <el-menu-item index="/person" v-if="user.role === 1">-->
<!--            <el-icon><User /></el-icon>-->
<!--            <span>学生资料</span>-->
<!--          </el-menu-item>-->
<!--          <el-menu-item index="/teacher" v-if="user.role === 2">-->
<!--            <el-icon><User /></el-icon>-->
<!--            <span>教师资料</span>-->
<!--          </el-menu-item>-->
          <!-- 退出登录菜单 -->
          <el-menu-item index="rank">
            <el-icon><SwitchButton /></el-icon>
            <span>排行榜</span>
          </el-menu-item>
          <el-menu-item index="login" @click="logout">
            <el-icon><SwitchButton /></el-icon>
            <span>退出系统</span>
          </el-menu-item>
          <el-menu-item index="login" @click="zhuxiao">
            <el-icon><SwitchButton /></el-icon>
            <span>注销账号</span>
          </el-menu-item>
        </el-menu>
      </div>
      <div style="flex: 1; width: 0; background-color: #f8f8ff; padding: 10px">
        <router-view />
      </div>
    </div>
  </div>
</template>



<script setup>
import { useRoute } from 'vue-router'
import request from "@/utils/request.js";
import {ElMessage} from "element-plus";
const $route = useRoute()
const user = JSON.parse(localStorage.getItem('user'))
const logout = () => {
  localStorage.removeItem('user')
}


const zhuxiao = () => {
  localStorage.removeItem('user');

  // 根据 role 动态选择 id
  let id;
  if (user.role === 1) {
    id = user.studentId;  // 如果角色是学生，使用 studentId
  } else if (user.role === 2) {
    id = user.teacherId;  // 如果角色是教师，使用 teacherId
  } else if (user.role === 3) {
    id = user.administratorId;  // 如果角色是管理员，使用 administratorId
  }

  // 发送 GET 请求，动态拼接 id 和 role
  request.get(`http://localhost:8090/login/delete?id=${id}&role=${user.role}`)
      .then((res) => {
        if (res.code === 200) {
          ElMessage.success("注销成功");
        } else {
          ElMessage.error(res.message);
        }
      })
      .catch(error => {
        console.error("请求失败", error);
        ElMessage.error("请求失败");
      });
}

</script>

<style scoped>
.el-menu-item.is-active {
  background-color: #dcede9 !important;
}
.el-menu-item:hover {
  color: #11A983;
}
:deep(th)  {
  color: #333;
}
</style>