<template>
  <div>
    <div class="card" style="margin-bottom: 10px">
      <el-input style="width: 260px; margin-right: 10px" v-model="data.teacherName" class="w-50 m-2" placeholder="请输入教师姓名进行查询" :prefix-icon="Search"/>
      <el-input style="width: 260px; margin-right: 10px" v-model="data.className" class="w-50 m-2" placeholder="请输入教学班号进行查询" :prefix-icon="Search"/>
      <el-input style="width: 260px" v-model="data.courseName" class="w-50 m-2" placeholder="请输入课程名称进行查询" :prefix-icon="Search"/>
      <el-button type="primary" style="margin-left: 10px" @click="query">查询</el-button>
      <el-button type="info" @click="reset">重置</el-button>
    </div>

    <div class="card" style="margin-bottom: 10px">
      <div style="margin-bottom: 10px">
        <el-button type="primary" @click="handleAdd">新增</el-button>
      </div>

      <!-- 使用 el-row 创建左右布局 -->
      <el-row gutter="20" style="margin-top: 10px">
        <!-- 左侧表格 -->
        <el-col :span="16">
          <el-table :data="data.tableData" style="width: 100%" max-height="1000px">
            <el-table-column prop="teacherName" label="教师姓名" width="120"/>
            <el-table-column prop="className" label="教学班号" width="120"/>
            <el-table-column prop="courseName" label="课程名称" width="120"/>
            <el-table-column prop="grade" label="学分" width="150"/>
            <el-table-column prop="semester" label="开课学期" width="150"/>
            <el-table-column label="操作">
              <template #default="scope">
                <el-button type="primary" size="small" plain @click="handleEdit(scope.row)">编辑</el-button>
                <el-button type="danger" size="small" plain @click="handleDelete(scope.row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-col>

        <!-- 右侧表格区域 -->
        <el-col :span="8">
          <el-row gutter="10">
            <!-- 第一个表格框 -->
            <el-col :span="24" style="height: 50%; padding-bottom: 10px;">
              <el-card>
                <div slot="header">教师信息</div>
                <el-table :data="data.tableData1" style="width: 100%" max-height="260px">
                  <el-table-column prop="teacherName" label="教师姓名" width="200" />
                  <el-table-column prop="teacherCount" label="教学班数" width="200" />
                </el-table>
              </el-card>
            </el-col>

            <!-- 第二个表格框 -->
            <el-col :span="24" style="height: 50%; padding-top: 10px;">
              <el-card>
                <div slot="header">课程信息</div>
                <el-table :data="data.tableData2" style="width: 100%" max-height="260px">
                  <el-table-column prop="courseName" label="课程名称" width="200" />
                  <el-table-column prop="courseCount" label="课程班数" width="200" />
                </el-table>
              </el-card>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
    </div>

    <div class="card">
      <el-pagination v-model:current-page="data.pageNum" v-model:page-size="data.pageSize"
                     @current-change="handelCurrentChange"
                     background layout="prev, pager, next" :total="data.total" />
    </div>

    <el-dialog width="35%" v-model="data.formVisible" title="教学班信息">
      <el-form :model="data.form" label-width="100px" label-position="right" style="padding-right: 40px">
        <!-- 教师选择 -->
        <el-form-item label="教师姓名">
          <el-select v-model="data.form.teacherName" placeholder="请选择教师" @change="handleTeacherChange">
            <el-option
                v-for="teacher in data.teacherList"
                :key="teacher.teacherId"
                :label="teacher.name"
                :value="teacher.name"
            ></el-option>
          </el-select>
        </el-form-item>
        <!-- 教学班号选择 -->
        <el-form-item label="教学班号">
          <el-input v-model="data.form.className" autocomplete="off" />
        </el-form-item>
        <!-- 课程名称选择 -->
        <el-form-item label="课程名称">
          <el-select v-model="data.form.courseName" placeholder="请选择课程名称">
            <el-option
                v-for="course in data.courseList"
                :key="course.courseId"
                :label="course.courseName"
                :value="course.courseName"
            ></el-option>
          </el-select>
        </el-form-item>
        <!-- 学分 -->
        <el-form-item label="学分">
          <el-input v-model="data.form.grade" autocomplete="off" />
        </el-form-item>
        <!-- 开课学期 -->
        <el-form-item label="开课学期">
          <el-input v-model="data.form.semester" autocomplete="off" />
        </el-form-item>
      </el-form>
      <template #footer>
    <span class="dialog-footer">
      <el-button @click="data.formVisible = false">取 消</el-button>
      <el-button type="primary" @click="save">保 存</el-button>
    </span>
      </template>
    </el-dialog>

  </div>
</template>

<script setup>
import {reactive} from "vue"
import { Search } from '@element-plus/icons-vue'
import request from "@/utils/request";
import {ElMessage, ElMessageBox} from "element-plus";
const data = reactive({
  teacherName:'',
  className:'',
  courseName:'',
  tableData:[],
  tableData1:[],
  tableData2:[],
  total:0,
  pageNum:1, //当前页码
  pageSize:10, //每页个数
  formVisible:false,
  form:{},
  isEdit: false,  // 新增或编辑标志
  teacherList: [], // 教师列表
  courseList: [], // 课程列表
})

const load = () => {

  // 获取教师列表
  request.get('http://localhost:8090/teacher/getAllTeachers').then(res => {
    data.teacherList = res.data || []
  })
  //获取教师教学班数信息
  request.get('http://localhost:8090/class/getTeacherCount',).then(res => {
    data.tableData1 = res.data || []
  })
  //获取课程教学班数信息
  request.get('http://localhost:8090/class/getCourseCount',).then(res => {
    data.tableData2 = res.data || []
  })

  // 获取课程列表
  request.get('http://localhost:8090/course/getAllCourses').then(res => {
    data.courseList = res.data || []
  })
  request.get('http://localhost:8090/class/getCount').then(res => {
    data.total = res.data|| 0
  })
  request.get('http://localhost:8090/class/getAllClass',{
    params: {
      pageNum:data.pageNum,
      pageSize:data.pageSize,
    }
  }).then(res => {
    data.tableData = res.data || []
  })
}

const query = () => {
  if(data.teacherName === ''&&data.className === ''&&data.courseName === ''){
    load()
  }
  else{
    request.get('http://localhost:8090/class/getSomeClass',{
      params: {
        teacherName:data.teacherName,
        className:data.className,
        courseName:data.courseName
      }
    }).then(res => {
      if(res.code === 200) {
        data.tableData = res.data || []
        data.total = res.data.length || 0
      }else {
        ElMessage.error(res.message);
      }
    })
  }
}

//调用方法获取后台数据
load()

const handelCurrentChange = (pageNum) => {
  //当翻页的时候重新加载数据即可
  load()
}
const reset = () => {
  data.name = ''
  load()
}

const handleAdd = () => {
  data.form = {}
  data.isEdit = false;  // 设置为新增状态
  data.formVisible = true
}
//保存数据到后台
const save = () => {
  const url = data.isEdit ? "http://localhost:8090/class/updateClass" : "http://localhost:8090/class/addClass";
  request.post(url, data.form).then((res) => {
    if (res.code === 200) {
      ElMessage.success(data.isEdit ? "编辑成功" : "添加成功");
      load();
      data.formVisible = false;
    } else {
      ElMessage.error(res.message);
    }
  });
}

const handleEdit = (row) => {
  data.form = JSON.parse(JSON.stringify(row))
  data.isEdit = true;  // 设置为新增状态
  data.formVisible = true
}

const handleDelete = (row) => {
  // 复制要删除的数据到 data.form
  data.form = JSON.parse(JSON.stringify(row));
  ElMessageBox.confirm('删除数据后无法恢复，请确认是否删除', '删除确认', { type: 'warning' })
      .then(res => {
        // 发送请求删除课程数据，传递整个 form 对象
        request.post('http://localhost:8090/class/deleteClass', data.form ).then(res => {
          if (res.code === 200) {
            load(); // 重新获取数据
            data.formVisible = false; // 关闭弹窗
            ElMessage.success("删除成功");
          } else {
            ElMessage.error(res.message);
          }
        });
      }).catch(() => {
    ElMessage({
      type: 'info',
      message: '取消删除',
    });
  });
};
</script>