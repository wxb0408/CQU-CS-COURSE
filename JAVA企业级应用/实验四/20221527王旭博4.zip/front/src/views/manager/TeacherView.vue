<template>
  <div>
    <!-- 水平排列的选择框 -->
    <div class="card" style="margin-bottom: 10px; display: flex; justify-content: space-between;">
      <!-- 班级选择 -->
      <div style="flex: 1; display: flex; align-items: center;">
        <span>班级选择：</span>
        <el-select v-model="data.className" @change="load" placeholder="请选择教学班" style="width: 150px; margin-left: 10px;">
          <el-option
              v-for="classItem in data.classes"
              :key="classItem.className"
              :label="classItem.className"
              :value="classItem.className"
          />
        </el-select>
      </div>

      <!-- 图表选择 -->
      <div style="flex: 1; display: flex; align-items: center;">
        <span>图表选择：</span>
        <el-select v-model="data.chartType" @change="load" placeholder="请选择图表类型" style="width: 150px; margin-left: 10px;">
          <el-option label="饼状图" value="pie" />
          <el-option label="折线图" value="line" />
          <el-option label="柱状图" value="bar" />
        </el-select>
      </div>

      <!-- 成绩类型选择 -->
      <div style="flex: 1; display: flex; align-items: center;">
        <span>成绩类型：</span>
        <el-select v-model="data.scoreType" @change="load" placeholder="请选择成绩类型" style="width: 150px; margin-left: 10px;">
          <el-option label="平时成绩" value="pingshigrade" />
          <el-option label="实验成绩" value="shiyangrade" />
          <el-option label="期中成绩" value="qizhonggrade" />
          <el-option label="期末成绩" value="qimograde" />
          <el-option label="总成绩" value="finalgrade" />
        </el-select>
      </div>
    </div>

    <!-- 图表展示 -->
    <div class="card" style="margin-top: 20px; display: flex; justify-content: center;">
      <div :style="chartStyle">
        <h3>{{ chartTitle }}</h3>
        <div :id="'chart'" style="width: 100%; height: 400px;"></div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, onMounted, nextTick, computed } from "vue";
import * as echarts from "echarts";
import request from "@/utils/request";
import { ElMessage } from "element-plus";

const user = JSON.parse(localStorage.getItem('user'));

const data = reactive({
  className: '', // 当前选择的教学班
  chartType: 'pie', // 默认选择饼状图
  scoreType: 'finalgrade', // 默认选择总成绩
  classes: [], // 教学班列表
  chartData: [], // 图表数据
});

// 图表标题
const chartTitles = {
  pingshigrade: '平时成绩分布',
  shiyangrade: '实验成绩分布',
  qizhonggrade: '期中成绩分布',
  qimograde: '期末成绩分布',
  finalgrade: '总成绩分布'
};

// 图表样式
const chartStyle = {
  width: '100%',
  height: '400px'  // 增加高度，设置为更大的值
};

// 获取当前选择的成绩类型的图表标题
const chartTitle = computed(() => {
  return chartTitles[data.scoreType];
});

onMounted(() => {
  // 获取教学班数据并填充到下拉选择框
  request.get('http://localhost:8090/score/getInformationByTeacherName', {
    params: { teacherName: user.name }
  }).then(res => {
    data.classes = res.data.map(item => ({ className: item.className }));
    if (data.classes.length > 0) {
      data.className = data.classes[0].className;
      load(); // 加载数据
    }
  });
});

// 加载成绩数据，并更新图表
const load = () => {
  // 获取成绩数据
  request.get('http://localhost:8090/score/getAllScoreWithClassName', {
    params: { className: data.className }
  }).then(res => {
    if (res.code === 200) {
      const scoreList = res.data;
      // 计算选择的成绩类型的分布
      const distribution = calculateDistribution(scoreList, data.scoreType);

      // 更新图表数据
      data.chartData = distribution;

      // 渲染图表
      nextTick(() => {
        const chartDom = document.getElementById('chart');
        const myChart = echarts.init(chartDom);
        let option = {};

        if (data.chartType === 'pie') {
          option = {
            tooltip: {
              trigger: 'item',
              formatter: '{a} <br/>{b}: {c} ({d}%)'
            },
            series: [
              {
                name: '成绩分布',
                type: 'pie',
                radius: '55%',
                center: ['50%', '50%'],
                data: data.chartData,
              }
            ]
          };
        } else if (data.chartType === 'line') {
          option = {
            tooltip: {
              trigger: 'axis'
            },
            xAxis: {
              type: 'category',
              data: data.chartData.map(item => item.name)
            },
            yAxis: {
              type: 'value'
            },
            series: [
              {
                data: data.chartData.map(item => item.value),
                type: 'line',
              }
            ]
          };
        } else if (data.chartType === 'bar') {
          option = {
            tooltip: {
              trigger: 'axis'
            },
            xAxis: {
              type: 'category',
              data: data.chartData.map(item => item.name)
            },
            yAxis: {
              type: 'value'
            },
            series: [
              {
                data: data.chartData.map(item => item.value),
                type: 'bar',
              }
            ]
          };
        }

        myChart.setOption(option);
      });
    } else {
      ElMessage.error(res.message);
    }
  });
};

// 计算成绩分布
const calculateDistribution = (scoreList, field) => {
  // 按照五个分段统计数据
  const segments = [
    { name: '60以下', value: 0, color: '#FF4D4D' },
    { name: '60~70', value: 0, color: '#FFA500' },
    { name: '70~80', value: 0, color: '#90EE90' },
    { name: '80~90', value: 0, color: '#00CED1' },
    { name: '90~100', value: 0, color: '#4682B4' }
  ];

  scoreList.forEach(score => {
    const value = score[field];
    if (value < 60) {
      segments[0].value++;
    } else if (value >= 60 && value < 70) {
      segments[1].value++;
    } else if (value >= 70 && value < 80) {
      segments[2].value++;
    } else if (value >= 80 && value < 90) {
      segments[3].value++;
    } else {
      segments[4].value++;
    }
  });

  // 过滤掉值为0的项
  return segments.filter(segment => segment.value > 0).map(segment => ({
    value: segment.value,
    name: segment.name,
    itemStyle: {
      color: segment.color
    }
  }));
};
</script>

<style scoped>
.card {
  margin: 20px 0;
}

.color-bar {
  width: 100%;
  height: 10px;
  margin: 0 auto;
}
</style>
