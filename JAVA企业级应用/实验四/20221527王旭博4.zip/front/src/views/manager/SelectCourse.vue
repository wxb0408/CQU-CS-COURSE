<template>
  <div class="course-selection">
    <div class="content">
      <!-- 左侧：课程列表 -->
      <div class="left-panel">
        <div v-for="(semester, index) in groupedCourses" :key="index" class="semester">
          <h3>{{ semester.name }} 课程</h3>
          <el-table :data="semester.courses" style="width: 95%">
            <el-table-column label="课程名称" prop="courseName" />
            <el-table-column label="学分" prop="grade" />
            <el-table-column label="学期" prop="semester" />
            <el-table-column label="课程编号" prop="courseId" />
            <el-table-column label="学院" prop="academy" />
            <el-table-column label="操作" width="120">
              <template #default="{ row }">
                <el-button
                    v-if="!row.selected"
                    type="primary"
                    @click="openSelectCourseDialog(row)">
                  选课
                </el-button>
                <span v-else>已选</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>

      <!-- 右侧：已选课程列表 -->
      <div class="right-panel">
        <h3>已选课程</h3>
        <el-table :data="selectedCourses" style="width: 100%">
          <el-table-column prop="courseName" label="课程名称" />
          <el-table-column prop="teacherName" label="教师姓名" />
          <!-- 新增的退课按钮列 -->
          <el-table-column label="操作" width="150">
            <template #default="{ row }">
              <el-button
                  type="danger"
                  @click="confirmDropCourse(row)">
                退课
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>

    <!-- 选课弹窗 -->
    <el-dialog v-model="isDialogVisible" title="选课" width="50%" :style="{ maxHeight: '80vh', overflowY: 'auto' }">
      <el-form>
        <el-form-item label="课程名称">
          <span>{{ selectedCourse?.courseName }}</span>
        </el-form-item>
        <!-- 教学班信息表格 -->
        <el-table :data="classList" style="width: 100%">
          <el-table-column label="教师姓名" prop="teacherName" />
          <el-table-column label="班级名称" prop="className" />
          <el-table-column label="选择" width="150">
            <template #default="{ row }">
              <el-radio v-model="selectedClass" :label="row.className" @change="setTeacherName(row)"></el-radio>
            </template>
          </el-table-column>
        </el-table>
      </el-form>

      <template #footer>
        <el-button @click="isDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="selectCourse">确认选课</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { ElButton, ElDialog, ElForm, ElRadio, ElTable, ElTableColumn, ElMessageBox, ElMessage} from 'element-plus';
import request from '@/utils/request'; // 假设你已经有request工具来调用后端接口

// 数据响应式
const groupedCourses = ref([]); // 按学期分组的课程信息
const selectedCourses = ref([]); // 已选课程列表
const classList = ref([]); // 教学班列表
const isDialogVisible = ref(false); // 控制弹窗显示
const selectedCourse = ref(null); // 当前选中的课程
const selectedClass = ref(null); // 当前选中的教学班

// 页面加载时获取数据
onMounted(() => {
  loadCourses();
  loadSelectedCourses();
});

// 加载课程数据并分组
const loadCourses = () => {
  request.get('http://localhost:8090/course/getAllCourses').then(response => {
    const courses = response.data;
    groupedCourses.value = groupBySemester(courses);
  });
};

// 加载已选课程
const loadSelectedCourses = () => {
  const user = JSON.parse(localStorage.getItem('user'));
  const studentName = user.name; // 获取学生姓名
  request.get(`http://localhost:8090/score/haveSelectCourseByStudentName?studentName=${studentName}`).then(response => {
    const selected = response.data;
    selectedCourses.value = selected; // 填充右侧的已选课程列表
    // 更新课程列表中已选状态
    selected.forEach(course => {
      groupedCourses.value.forEach(semester => {
        const match = semester.courses.find(c => c.courseName === course.courseName);
        if (match) match.selected = true; // 标记为已选
      });
    });
  });
};

// 按学期分组课程
const groupBySemester = (courses) => {
  const grouped = [];
  courses.forEach(course => {
    const semesterName = `学期 ${course.semester}`;
    let semester = grouped.find(s => s.name === semesterName);
    if (!semester) {
      semester = {name: semesterName, courses: []};
      grouped.push(semester);
    }
    semester.courses.push({...course, selected: false});
  });
  return grouped;
};

// 打开选课对话框并加载教学班信息
const openSelectCourseDialog = (course) => {
  selectedCourse.value = course;
  loadClassInfo(course.courseName);
  isDialogVisible.value = true;
};

// 加载教学班信息
const loadClassInfo = (courseName) => {
  request.get(`http://localhost:8090/class/getClassByCourseName?courseName=${courseName}`).then(response => {
    classList.value = response.data;
  });
};

// 设置教师信息
const setTeacherName = (row) => {
  selectedCourse.value.teacherName = row.teacherName;
};

// 选课操作
// 选课操作
const selectCourse = () => {
  if (selectedClass.value) {
    const user = JSON.parse(localStorage.getItem('user'));
    const studentName = user.name;
    const scoreData = {
      studentName,
      teacherName: selectedCourse.value.teacherName,
      courseName: selectedCourse.value.courseName,
      className: selectedClass.value,
      grade: selectedCourse.value.grade,
      semester: selectedCourse.value.semester,
    };

    request.post('http://localhost:8090/score/selectCourse', scoreData).then(response => {
      if (response.code === 200) {
        // 选课成功后，更新已选课程列表和课程状态
        selectedCourses.value.push({
          courseName: selectedCourse.value.courseName,
          teacherName: selectedCourse.value.teacherName,
        });

        // 更新左侧课程列表的状态
        groupedCourses.value.forEach(semester => {
          const match = semester.courses.find(c => c.courseName === selectedCourse.value.courseName);
          if (match) match.selected = true; // 标记为已选
        });

        isDialogVisible.value = false;
        ElMessage.success("选课成功");
      }
    }).catch(() => {
      ElMessage.error("选课失败");
    });
  } else {
    ElMessage.warning('请选择教学班');
  }
};


// 退课操作
const confirmDropCourse = (course) => {
  ElMessageBox.confirm(
      '你确定要退掉这门课程吗？',
      '确认退课',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
  ).then(() => {
    dropCourse(course);
  }).catch(() => {
    // 用户取消操作
  });
};

// 退课请求
// 退课请求
const dropCourse = (course) => {
  const user = JSON.parse(localStorage.getItem('user'));
  const studentName = user.name; // 获取学生姓名

  // 构造请求 URL，带上查询参数
  const url = `http://localhost:8090/score/deleteCourseByStudentName?studentName=${studentName}&courseName=${course.courseName}`;

  // 使用 GET 请求进行退课
  request.get(url).then(response => {
    if (response.code === 200) {
      // 从已选课程列表中移除退课的课程
      const index = selectedCourses.value.findIndex(c => c.courseName === course.courseName);
      if (index !== -1) {
        selectedCourses.value.splice(index, 1);
      }

      // 更新左侧课程列表的状态
      groupedCourses.value.forEach(semester => {
        const match = semester.courses.find(c => c.courseName === course.courseName);
        if (match) match.selected = false; // 标记为未选
      });

      ElMessage.success("退课成功");
    } else {
      ElMessage.error("退课失败");
    }
  }).catch(() => {
    ElMessage.error("请求失败");
  });
};



</script>

<style scoped>
.course-selection {
  display: flex;
  padding: 20px;
}

.content {
  display: flex;
  width: 100%;
}

.left-panel {
  flex: 1;
  margin-right: 20px;
}

.semester {
  margin-bottom: 20px;
}

.right-panel {
  width: 350px;
  flex-shrink: 0;
}

.right-panel h3 {
  margin-bottom: 20px;
}

.el-table {
  width: 100%;
}

.el-table-column:last-child {
  text-align: center;
}
</style>
