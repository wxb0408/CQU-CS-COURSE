<template>
  <div>
    <!-- 添加下拉选择框 -->
    <div class="card" style="margin-bottom: 10px">
      <el-select v-model="data.className" @change="load" placeholder="请选择教学班" style="width: 260px; margin-bottom: 20px;">
        <el-option
            v-for="classItem in data.classes"
            :key="classItem.className"
            :label="classItem.className"
            :value="classItem.className"
        />
      </el-select>
    </div>

    <!-- 输入框单独占一行 -->
    <div class="card" style="margin-bottom: 10px">
      <el-input style="width: 260px" v-model="data.studentName" class="w-50 m-2" placeholder="请输入姓名进行查询" :prefix-icon="Search"/>
      <el-button type="primary" style="margin-left: 10px" @click="query">查询</el-button>

      <!-- 重置按钮右侧添加排序选择框 -->
      <el-button type="info" @click="reset" style="margin-left: 10px">重置</el-button>

      <el-select v-model="data.sortField" @change="load" placeholder="排序字段" style="width: 180px; margin-left: 10px;">
        <el-option label="学号" value="studentId" />
        <el-option label="平时成绩" value="pingshigrade" />
        <el-option label="实验成绩" value="shiyangrade" />
        <el-option label="期中成绩" value="qizhonggrade" />
        <el-option label="期末成绩" value="qimograde" />
        <el-option label="总成绩" value="finalgrade" />
      </el-select>

      <span style="margin-left: 10px;">排序</span>

      <!-- 统一评分按钮 -->
      <el-button type="warning" style="margin-left: 20px" @click="openUnifiedGrading">统一评分</el-button>
    </div>

    <!-- 表格内容 -->
    <div class="card" style="margin-bottom: 10px">
      <el-table :data="data.tableData" style="width: 100%">
        <el-table-column prop="studentId" label="学号" width="150"/>
        <el-table-column prop="studentName" label="姓名" width="150"/>
        <el-table-column prop="courseName" label="课程" width="150"/>
        <el-table-column prop="pingshigrade" label="平时成绩" width="120"/>
        <el-table-column prop="shiyangrade" label="实验成绩" width="120"/>
        <el-table-column prop="qizhonggrade" label="期中成绩" width="120"/>
        <el-table-column prop="qimograde" label="期末成绩" width="120"/>
        <el-table-column prop="finalgrade" label="总成绩" width="120"/>
        <el-table-column label="操作">
          <template #default="scope">
            <el-button type="primary" size="small" plain @click="handleEdit(scope.row)">评分</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- 分页 -->
    <div class="card">
      <el-pagination v-model:current-page="data.pageNum" v-model:page-size="data.pageSize"
                     @current-change="handelCurrentChange"
                     background layout="prev, pager, next" :total="data.total" />
    </div>

    <!-- 成绩信息弹窗 -->
    <el-dialog width="35%" v-model="data.formVisible" title="成绩信息">
      <el-form :model="data.form" label-width="100px" label-position="right" style="padding-right: 40px">
        <el-form-item label="平时成绩">
          <el-input v-model="data.form.pingshigrade" autocomplete="off" />
        </el-form-item>
        <el-form-item label="实验成绩">
          <el-input v-model="data.form.shiyangrade" autocomplete="off" />
        </el-form-item>
        <el-form-item label="期中成绩">
          <el-input v-model="data.form.qizhonggrade" autocomplete="off" />
        </el-form-item>
        <el-form-item label="期末成绩">
          <el-input v-model="data.form.qimograde" autocomplete="off" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="data.formVisible = false">取 消</el-button>
          <el-button type="primary" @click="save">保 存</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { reactive, onMounted } from "vue"
import { Search } from '@element-plus/icons-vue'
import request from "@/utils/request";
import { ElMessage, ElMessageBox } from "element-plus";
import router from "@/router/index.js";

const user = JSON.parse(localStorage.getItem('user'))
const data = reactive({
  studentName:'', // 学生姓名
  tableData: [], // 表格数据
  total: 0, // 总数
  pageNum: 1, // 当前页码
  pageSize: 10, // 每页个数
  formVisible: false, // 控制弹窗显示
  form: {}, // 表单数据
  className: '', // 当前选择的教学班
  classes: [], // 教学班列表
  sortField: '' // 排序字段
})

onMounted(() => {
  // 获取教学班数据并填充到下拉选择框
  request.get('http://localhost:8090/score/getInformationByTeacherName', {
    params: { teacherName: user.name }
  }).then(res => {
    data.classes = res.data.map(item => ({ className: item.className }));
    if (data.classes.length > 0) {
      data.className = data.classes[0].className;
      load(); // 加载数据
    }
  })
})

// 加载查询数据
const load = () => {
  request.get('http://localhost:8090/score/getScoreCount',{
    params: { className: data.className }
  }).then(res => {
    data.total = res.data || 0
  })
  request.get('http://localhost:8090/score/getScoreWithClassName', {
    params: {
      pageNum: data.pageNum,
      pageSize: data.pageSize,
      className: data.className,
      sortField: data.sortField
    }
  }).then(res => {
    data.tableData = res.data || []
  })
}

// 翻页
const handelCurrentChange = (pageNum) => {
  load();
}

// 重置
const reset = () => {
  data.sortField = '' // 清空排序字段
  load();
}

// 编辑评分
const handleEdit = (row) => {
  data.form = JSON.parse(JSON.stringify(row))
  data.formVisible = true
}

// 保存成绩
const save = () => {
  // 判断是否是统一评分，如果是，则调用 setStudentScore 接口
  if (data.form.studentId) {
    request.post("http://localhost:8090/score/pingfen", data.form).then((res) => {
      if (res.code === 200) {
        ElMessage.success("评分成功");
        load();
        data.formVisible = false;
      } else {
        ElMessage.error(res.message);
      }
    });
  } else {
    // 统一评分处理
    request.post("http://localhost:8090/score/setStudentScore", data.form).then((res) => {
      if (res.code === 200) {
        ElMessage.success("统一评分成功");
        load();
        data.formVisible = false;
      } else {
        ElMessage.error(res.message);
      }
    });
  }
}

// 删除操作
const query = () => {
  if(data.studentName === ''){
    load()
  }
  else{
    request.get('http://localhost:8090/score/getStudentScore',{
      params: {
        studentName: data.studentName,
        className: data.className
      }
    }).then(res => {
      if(res.code === 200) {
        data.tableData = res.data || []
        data.total = res.data.length || 0
      } else {
        ElMessage.error(res.message);
      }
    })
  }
}

// 统一评分按钮逻辑
const openUnifiedGrading = () => {
  // 获取选中的学生信息（例如，假设选择所有学生）
  const students = data.tableData;

  // 如果没有学生数据，提示
  if (!students.length) {
    ElMessage.warning("没有学生数据可以评分！");
    return;
  }

  // 统一填充评分字段
  data.form = {
    studentId:'',
    studentName:'',
    courseName:data.className,
    pingshigrade: '',
    shiyangrade: '',
    qizhonggrade: '',
    qimograde: '',
    finalgrade:''
  }

  // 打开评分弹窗
  data.formVisible = true;
}

</script>
