<script setup>
import { reactive, onMounted } from "vue";
import request from "@/utils/request";
import { ElMessage } from "element-plus";
import {Search} from "@element-plus/icons-vue";

const data = reactive({
  rankList: [], // 所有学生的排名数据
  sortedBy: "gpa", // 默认排序字段
  sortOrder: "desc", // 默认降序排序
  studentId:'',
  studentName:''
});

onMounted(() => {
  loadRankList();
});

// 加载排名数据
const loadRankList = () => {
  request.get("http://localhost:8090/score/paihangbang").then((res) => {
    if (res.code === 200) {
      data.rankList = res.data || [];
      sortRankList(); // 默认按照 GPA 排序
    } else {
      ElMessage.error(res.message);
    }
  });
};

// 排序方法
const sortRankList = (field = "gpa") => {
  if (data.sortedBy === field) {
    // 如果点击的表头是当前排序字段，则切换排序顺序
    data.sortOrder = data.sortOrder === "asc" ? "desc" : "asc";
  } else {
    // 切换排序字段
    data.sortedBy = field;
    data.sortOrder = "desc"; // 新字段默认降序
  }

  const orderFactor = data.sortOrder === "asc" ? 1 : -1;
  data.rankList.sort((a, b) => (a[field] - b[field]) * orderFactor);
};

const reset = () => {
  data.studentName = ''
  data.studentId = ''
  loadRankList()
}

const query = () => {
  if(data.studentName === ''&&data.studentId === ''){
    loadRankList()
  }
  else{
    request.get('http://localhost:8090/score/queryrank',{
      params: {
        studentName:data.studentName,
        studentId:data.studentId
      }
    }).then(res => {
      if(res.code === 200) {
        data.rankList = res.data || []
      }else {
        ElMessage.error(res.message);
      }
    })
  }
}
</script>

<template>
  <div class="card" style="margin-bottom: 10px">
    <el-input style="width: 260px; margin-right: 10px" v-model="data.studentId" class="w-50 m-2" placeholder="请输入学号进行查询" :prefix-icon="Search"/>
    <el-input style="width: 260px" v-model="data.studentName" class="w-50 m-2" placeholder="请输入姓名进行查询" :prefix-icon="Search"/>
    <el-button type="primary" style="margin-left: 10px" @click="query">查询</el-button>
    <el-button type="info" @click="reset">重置</el-button>
  </div>
  <div class="table-container">
    <table class="rank-table">
      <!-- 表头 -->
      <thead>
      <tr>
        <th class="sticky-col">排名</th>
        <th class="sticky-col">姓名</th>
        <th>
          <button @click="sortRankList('course001')">软件工程</button>
        </th>
        <th>
          <button @click="sortRankList('course002')">操作系统</button>
        </th>
        <th>
          <button @click="sortRankList('course003')">计算机网络</button>
        </th>
        <th>
          <button @click="sortRankList('course004')">JAVA企业级应用</button>
        </th>
        <th>
          <button @click="sortRankList('course005')">移动应用软件开发</button>
        </th>
        <th>
          <button @click="sortRankList('course006')">大数据架构与技术</button>
        </th>
        <th>
          <button @click="sortRankList('course007')">形势与政策</button>
        </th>
        <th>
          <button @click="sortRankList('gpa')">综合绩点</button>
        </th>
      </tr>
      </thead>
      <!-- 表格内容 -->
      <tbody>
      <tr v-for="(item, index) in data.rankList" :key="index">
        <td class="sticky-col">{{ index + 1 }}</td>
        <td class="sticky-col">{{ item.studentName }}</td>
        <td>{{ item.course001 }}</td>
        <td>{{ item.course002 }}</td>
        <td>{{ item.course003 }}</td>
        <td>{{ item.course004 }}</td>
        <td>{{ item.course005 }}</td>
        <td>{{ item.course006 }}</td>
        <td>{{ item.course007 }}</td>
        <td>{{ item.gpa.toFixed(2) }}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>
.table-container {
  overflow-x: auto;
  max-width: 100%;
}

.rank-table {
  width: 100%;
  border-collapse: collapse;
  text-align: center;
}

.rank-table th,
.rank-table td {
  border: 1px solid #ddd;
  padding: 8px;
}

.rank-table th {
  background-color: #f2f2f2;
  cursor: pointer;
  position: sticky;
  top: 0;
}

.sticky-col {
  position: sticky;
  left: 0;
  background-color: #f9f9f9;
  z-index: 1;
}

.rank-table th button {
  background: none;
  border: none;
  color: #007bff;
  cursor: pointer;
  font-size: 14px;
  padding: 0;
}

.rank-table th button:hover {
  text-decoration: underline;
}

.rank-table tbody tr:hover {
  background-color: #f1f1f1;
}
</style>
