<template>
  <div>
    <div class="card" style="margin-bottom: 10px">
      <el-input style="width: 260px; margin-right: 10px" v-model="data.studentId" class="w-50 m-2" placeholder="请输入学号进行查询" :prefix-icon="Search"/>
      <el-input style="width: 260px" v-model="data.name" class="w-50 m-2" placeholder="请输入姓名进行查询" :prefix-icon="Search"/>
      <el-button type="primary" style="margin-left: 10px" @click="query">查询</el-button>
      <el-button type="info" @click="reset">重置</el-button>
    </div>
    <div class="card" style="margin-bottom: 10px">
      <div style="margin-bottom: 10px">
        <el-button type="primary" @click="handleAdd">新增</el-button>
      </div>
      <div>
        <el-table :data="data.tableData" style="width: 100%">
          <el-table-column prop="studentId" label="学号" width="120"/>
          <el-table-column prop="name" label="姓名" width="120"/>
          <el-table-column prop="gender" label="性别" width="120"/>
          <el-table-column prop="phone" label="电话" width="150"/>
          <el-table-column prop="email" label="邮箱" width="150"/>
          <el-table-column prop="province" label="省" width="120"/>
          <el-table-column prop="city" label="市" width="120"/>
          <el-table-column prop="academy" label="学院" width="120"/>
          <el-table-column prop="political" label="政治面貌" width="120"/>
          <el-table-column label="操作">
            <template #default="scope">
              <el-button type="primary" size="small" plain @click="handleEdit(scope.row)">编辑</el-button>
              <el-button type="danger" size="small" plain @click="handleDelete(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="card">
      <el-pagination v-model:current-page="data.pageNum" v-model:page-size="data.pageSize"
                     @current-change="handelCurrentChange"
                     background layout="prev, pager, next" :total="data.total" />
    </div>
    <el-dialog width="35%" v-model="data.formVisible" title="学生信息">
      <el-form :model="data.form" label-width="100px" label-position="right" style="padding-right: 40px">
        <el-form-item label="学号">
          <el-input v-model="data.form.studentId" autocomplete="off" />
        </el-form-item>
        <el-form-item label="姓名">
          <el-input v-model="data.form.name" autocomplete="off" />
        </el-form-item>
      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="data.formVisible = false">取 消</el-button>
        <el-button type="primary" @click="save">保 存</el-button>
      </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import {reactive} from "vue"
import { Search } from '@element-plus/icons-vue'
import request from "@/utils/request";
import {ElMessage, ElMessageBox} from "element-plus";
const data = reactive({
  name:'',
  studentId:'',
  tableData:[],
  total:0,
  pageNum:1, //当前页码
  pageSize:10, //每页个数
  formVisible:false,
  form:{},
  isEdit: false,  // 新增或编辑标志
})

const load = () => {
  request.get('http://localhost:8090/student/getCount').then(res => {
    data.total = res.data|| 0
  })
  request.get('http://localhost:8090/student/getAllStudent',{
    params: {
      pageNum:data.pageNum,
      pageSize:data.pageSize,
    }
  }).then(res => {
    data.tableData = res.data || []
  })
}

const query = () => {
  if(data.name === ''&&data.studentId === ''){
    load()
  }
  else{
    request.get('http://localhost:8090/student/getOneStudent',{
      params: {
        name:data.name,
        studentId:data.studentId
      }
    }).then(res => {
      if(res.code === 200) {
        data.tableData = res.data || []
        data.total = res.data.length || 0
      }else {
        ElMessage.error(res.message);
      }
    })
  }
}

//调用方法获取后台数据
load()

const handelCurrentChange = (pageNum) => {
  //当翻页的时候重新加载数据即可
  load()
}
const reset = () => {
  data.name = ''
  load()
}

const handleAdd = () => {
  data.form = {}
  data.isEdit = false;  // 设置为新增状态
  data.formVisible = true
}
//保存数据到后台
const save = () => {
  const url = data.isEdit ? "http://localhost:8090/student/updateStudent" : "http://localhost:8090/student/addStudent";
  request.post(url, data.form).then((res) => {
    if (res.code === 200) {
      ElMessage.success(data.isEdit ? "编辑成功" : "添加成功");
      load();
      data.formVisible = false;
    } else {
      ElMessage.error(res.message);
    }
  });
}

const handleEdit = (row) => {
  data.form = JSON.parse(JSON.stringify(row))
  data.isEdit = true;  // 设置为新增状态
  data.formVisible = true
}

const handleDelete = (row) => {
  // 复制要删除的数据到 data.form
  console.log(row)
  data.form = JSON.parse(JSON.stringify(row));
  console.log(data.form)
  ElMessageBox.confirm('删除数据后无法恢复，请确认是否删除', '删除确认', { type: 'warning' })
      .then(res => {
        // 发送请求删除课程数据，传递整个 form 对象
        request.post('http://localhost:8090/student/deleteStudent', data.form ).then(res => {
          if (res.code === 200) {
            load(); // 重新获取数据
            data.formVisible = false; // 关闭弹窗
            ElMessage.success("删除成功");
          } else {
            ElMessage.error(res.message);
          }
        });
      }).catch(() => {
    ElMessage({
      type: 'info',
      message: '取消删除',
    });
  });
};
</script>