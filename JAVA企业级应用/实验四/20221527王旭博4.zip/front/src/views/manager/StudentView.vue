<template>
  <div>
    <!-- 学期选择框：放置在左上角 -->
    <div class="semester-select" style="margin-bottom: 20px;">
      <el-select v-model="data.semester" @change="load" placeholder="请选择学期" style="width: 260px;">
        <el-option label="第一学期" value="第一学期" />
        <el-option label="第二学期" value="第二学期" />
        <el-option label="第三学期" value="第三学期" />
        <el-option label="第四学期" value="第四学期" />
        <el-option label="第五学期" value="第五学期" />
      </el-select>
    </div>

    <!-- 上半部分：成绩信息和饼状图 -->
    <div class="card" style="display: flex; justify-content: space-between; margin-bottom: 20px; align-items: center;">
      <!-- 学生成绩信息 -->
      <div class="student-info" style="flex: 2; display: flex; justify-content: space-between; text-align: center; align-items: center;">
        <div class="info-item">
          <strong>当前排名：</strong>
          <el-input v-model="data.rank" disabled placeholder="排名" style="width: 150px;" />
        </div>
        <div class="info-item">
          <strong>总人数：</strong>
          <el-input v-model="data.total" disabled placeholder="人数" style="width: 150px;" />
        </div>
        <div class="info-item">
          <strong>综合绩点：</strong>
          <el-input v-model="data.gpa" disabled placeholder="绩点" style="width: 150px;" />
        </div>
      </div>

      <!-- 饼状图 -->
      <div style="flex: 2; padding-left: 20px;">
        <div :id="'chart'" style="width: 100%; height: 300px;"></div>
      </div>
    </div>

    <!-- 下半部分：课程信息卡片 -->
    <div class="card" style="margin-bottom: 20px;">
      <div class="course-grid">
        <div v-for="course in data.courses" :key="course.courseName" class="course-card">
          <div class="course-card-header">
            <div><strong>{{ course.courseName }}</strong></div>
            <div>教师：{{ course.teacherName }}</div>
            <div><strong>总成绩：</strong>{{ course.finalgrade }}</div>
          </div>
          <!-- 右侧成绩网格 -->
          <div class="course-card-body">
            <div class="score-grid">
              <div>
                <strong>平时成绩：</strong>{{ course.pingshigrade }}
              </div>
              <div>
                <strong>实验成绩：</strong>{{ course.shiyangrade }}
              </div>
              <div>
                <strong>期中成绩：</strong>{{ course.qizhonggrade }}
              </div>
              <div>
                <strong>期末成绩：</strong>{{ course.qimograde }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup>
import { reactive, onMounted, nextTick } from "vue";
import * as echarts from "echarts";
import request from "@/utils/request";
import { ElMessage } from "element-plus";

const user = JSON.parse(localStorage.getItem('user'));

// 数据
const data = reactive({
  semester: '第五学期', // 默认第五学期
  rank: 0, // 当前排名
  total: 0, // 总人数
  gpa: 0, // 综合绩点
  courses: [], // 课程信息
  chartData: [], // 饼状图数据
  rankList: [] // 所有学生的排名数据
});

onMounted(() => {
  load(); // 加载数据
  getTotalCount(); // 获取总人数
  getRankList(); // 获取排行榜数据
});

// 获取总人数
const getTotalCount = () => {
  request.get('http://localhost:8090/student/getCount').then(res => {
    if (res.code === 200) {
      data.total = res.data || 0;
    } else {
      ElMessage.error(res.message);
    }
  });
};

// 获取排行榜数据
const getRankList = () => {
  request.get('http://localhost:8090/score/paihangbang').then(res => {
    if (res.code === 200) {
      data.rankList = res.data || [];
      calculateUserRank(); // 计算当前用户的排名
    } else {
      ElMessage.error(res.message);
    }
  });
};

// 计算当前用户的排名
const calculateUserRank = () => {
  const userRank = data.rankList.findIndex(item => item.studentName === user.name);

  // 如果找到了当前用户
  if (userRank !== -1) {
    data.rank = userRank + 1; // 排名从1开始
  } else {
    data.rank = 0; // 如果没有找到，返回0
  }
};

// 加载成绩数据
const load = () => {
  // 定义学期字符串与数字的映射关系
  const semesterMap = {
    '第一学期': 1,
    '第二学期': 2,
    '第三学期': 3,
    '第四学期': 4,
    '第五学期': 5
  };

  // 获取对应学期的数字值
  const semesterNumber = semesterMap[data.semester];

  request.get('http://localhost:8090/score/getScoreStudentSemester', {
    params: { semester: semesterNumber, studentName: user.name }
  }).then(res => {
    if (res.code === 200) {
      data.courses = res.data || [];
      data.chartData = res.data.map(course => ({
        value: course.finalgrade,
        name: course.courseName
      }));
      calculateGPA(); // 计算综合绩点
      renderChart(); // 渲染饼状图
    } else {
      ElMessage.error(res.message);
    }
  });
};

// 计算综合绩点
const calculateGPA = () => {
  let totalPoints = 0; // 加权绩点总和
  let totalCredits = 0; // 总学分

  data.courses.forEach(course => {
    let score = course.finalgrade;
    let point = 0;

    if (score >= 90) {
      point = 4.0;
    } else if (score >= 60) {
      point = 4.0 - (90 - score) * 0.1;
    } else {
      point = 0;
    }

    totalPoints += point * course.grade;
    totalCredits += course.grade;
  });

  if (totalCredits > 0) {
    data.gpa = (totalPoints / totalCredits).toFixed(2);
  } else {
    data.gpa = 0;
  }
};

// 渲染饼状图
const renderChart = () => {
  nextTick(() => {
    const chartDom = document.getElementById('chart');
    const myChart = echarts.init(chartDom);
    const option = {
      tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c} ({d}%)'
      },
      series: [
        {
          name: '总成绩分布',
          type: 'pie',
          radius: '55%',
          center: ['50%', '50%'],
          data: data.chartData,
        }
      ]
    };
    myChart.setOption(option);
  });
};
</script>

<style scoped>
.card {
  margin: 20px 0;
}

.course-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

.course-card {
  background-color: #fff;
  padding: 20px;
  border: 1px solid #eaeaea;
  border-radius: 8px;
  transition: transform 0.3s;
}

.course-card:hover {
  transform: scale(1.05);
}

.course-card-header {
  font-weight: bold;
  margin-bottom: 10px;
}

.course-card-body {
  font-size: 14px;
}

.score-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}

.el-select {
  width: 100%;
}

#chart {
  width: 100%;
  height: 300px;
}

.el-input {
  width: 150px;
  display: inline-block;
}

.student-info {
  display: flex;
  justify-content: space-between;
  width: 60%;
}

/* 学期选择框的样式 */
.semester-select {
  margin-bottom: 20px;
  display: flex;
  justify-content: flex-start;
}
</style>
