<template>
  <div class="user-info-container">
    <div class="user-info-card">
      <!-- 根据用户角色展示不同的信息 -->
      <div v-if="user.role === 1">
        <!-- 学生信息 -->
        <h3>个人信息</h3>
        <div class="info-row">
          <div class="info-item">
            <label>学号：</label>
            <input v-model="formData.student.studentId" :disabled="true" />
          </div>
          <div class="info-item">
            <label>姓名：</label>
            <input v-model="formData.student.name" :disabled="true" />
          </div>
          <div class="info-item">
            <label>性别：</label>
            <input v-model="formData.student.gender" :disabled="!isSubmit" />
          </div>
        </div>
        <div class="info-row">
          <div class="info-item">
            <label>电话：</label>
            <input v-model="formData.student.phone" :disabled="!isSubmit" />
          </div>
          <div class="info-item">
            <label>省：</label>
            <input v-model="formData.student.province" :disabled="!isSubmit" />
          </div>
          <div class="info-item">
            <label>市：</label>
            <input v-model="formData.student.city" :disabled="!isSubmit" />
          </div>
        </div>
        <div class="info-row">

          <div class="info-item">
            <label>学院：</label>
            <input v-model="formData.student.academy" :disabled="!isSubmit" />
          </div>
          <div class="info-item">
            <label>邮箱：</label>
            <input v-model="formData.student.email" :disabled="!isSubmit" />
          </div>
        </div>
        <div class="info-row">

          <div class="info-item">
            <label>政治面貌：</label>
            <input v-model="formData.student.political" :disabled="!isSubmit" />
          </div>
        </div>
      </div>

      <div v-else-if="user.role === 2">
        <!-- 教师信息 -->
        <h3>个人信息</h3>
        <div class="info-row">
          <div class="info-item">
            <label>教师编号：</label>
            <input v-model="formData.teacher.teacherId" :disabled="true" />
          </div>
          <div class="info-item">
            <label>姓名：</label>
            <input v-model="formData.teacher.name" :disabled="true" />
          </div>
          <div class="info-item">
            <label>性别：</label>
            <input v-model="formData.teacher.gender" :disabled="!isSubmit" />
          </div>
        </div>
        <div class="info-row">
          <div class="info-item">
            <label>电话：</label>
            <input v-model="formData.teacher.phone" :disabled="!isSubmit" />
          </div>
          <div class="info-item">
            <label>邮箱：</label>
            <input v-model="formData.teacher.email" :disabled="!isSubmit" />
          </div>
        </div>
      </div>

      <div v-else-if="user.role === 3">
        <!-- 管理员信息 -->
        <h3>个人信息</h3>
        <div class="info-row">
          <div class="info-item">
            <label>管理员编号：</label>
            <input v-model="formData.administrator.administratorId" :disabled="true" />
          </div>
          <div class="info-item">
            <label>姓名：</label>
            <input v-model="formData.administrator.name" :disabled="true" />
          </div>
          <div class="info-item">
            <label>性别：</label>
            <input v-model="formData.administrator.gender" :disabled="!isSubmit" />
          </div>
        </div>
        <div class="info-row">
          <div class="info-item">
            <label>邮箱：</label>
            <input v-model="formData.administrator.email" :disabled="!isSubmit" />
          </div>
          <div class="info-item">
            <label>电话：</label>
            <input v-model="formData.administrator.phone" :disabled="!isSubmit" />
          </div>
        </div>
      </div>

      <div class="action-buttons">
        <div class="button-container">
          <!-- 如果是编辑状态，显示“返回”按钮，否则显示“完善信息”按钮 -->
          <div v-if="isEditing">
            <button @click="handleReturnButton" class="return-button">返回</button>
          </div>
          <button @click="handleButtonClick" class="submit-button">
            {{ isSubmit ? '提交' : '修改信息' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import request from "@/utils/request.js";
import {ElMessage} from "element-plus";
import router from "@/router/index.js";

// 获取当前用户信息
const user = JSON.parse(localStorage.getItem('user') || '{}');

// 定义表单数据
const formData = ref({
  student: {
    studentId: user.studentId || '',
    name: user.name || '',
    userType:'',
    phone: user.phone || '',
    password:user.password||'',
    province: user.province || '',
    city: user.city || '',
    gender: user.gender || '',
    political: user.political || '',
    fileData:user.fileData || '',
    email: user.email || '',
    academy: user.academy || '',
    role:1
  },
  teacher: {
    teacherId: user.teacherId || '',
    name: user.name || '',
    password:user.password||'',
    userType:'',
    phone: user.phone || '',
    email: user.email || '',
    gender: user.gender || '',
    fileData:user.fileData || '',
    role:2
  },
  administrator: {
    administratorId: user.administratorId || '',
    name: user.name || '',
    password:user.password||'',
    phone: user.phone || '',
    email: user.email || '',
    gender: user.gender || '',
    fileData:user.fileData || '',
    role:3
  }
});

// 定义状态
const isSubmit = ref(false); // 是否是提交状态
const isEditing = ref(false); // 是否处于编辑状态
const originalData = ref({ ...formData.value }); // 保存用户初始数据

// 切换按钮状态及字段是否可编辑
const handleButtonClick = () => {
  if (isSubmit.value) {
    // 提交按钮的逻辑（此处你可以添加提交的API请求）
    // 保存修改后的信息
    originalData.value = { ...formData.value };
    if(user.role === 1){
      request.post("http://localhost:8090/student/updateInformation", formData.value.student).then((res) => {
        if (res.code === 200) {
          ElMessage.success("修改成功");
          localStorage.removeItem('user')
          localStorage.setItem("user",JSON.stringify(res.data))
        } else {
          ElMessage.error(res.message);
        }
      });
    }else if(user.role === 2){
      request.post("http://localhost:8090/teacher/updateInformation", formData.value.teacher).then((res) => {
        if (res.code === 200) {
          ElMessage.success("修改成功");
          localStorage.removeItem('user')
          localStorage.setItem("user",JSON.stringify(res.data))
        } else {
          ElMessage.error(res.message);
        }
      });
    }else{
      request.post("http://localhost:8090/admin/updateInformation", formData.value.administrator).then((res) => {
        if (res.code === 200) {
          ElMessage.success("修改成功");
          localStorage.removeItem('user')
          localStorage.setItem("user",JSON.stringify(res.data))
        } else {
          ElMessage.error(res.message);
        }
      });
    }
  }
  isSubmit.value = !isSubmit.value; // 切换“完善信息”和“提交”按钮的状态
  isEditing.value = !isEditing.value; // 切换编辑状态
};

// 点击“返回”按钮，恢复到初始状态
const handleReturnButton = () => {
  // 恢复数据为初始数据
  formData.value = { ...originalData.value };
  isSubmit.value = false;
  isEditing.value = false; // 隐藏返回按钮，恢复到“完善信息”状态
};
</script>

<style scoped>
.user-info-container {
  padding: 20px;
}

.user-info-card {
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

h3 {
  font-size: 20px;
  margin-bottom: 20px;
}

.info-row {
  display: flex;
  flex-wrap: wrap;
  gap: 100px; /* 增加字段之间的间隔 */
  margin-bottom: 15px;
}

.info-item {
  width: 260px;
  display: flex;
  justify-content: center; /* 让label和input在同一行，左右分布 */
}

label {
  font-weight: bold;
  margin-right: 10px;
  min-width: 80px;
}

input {
  width: 100%;
  padding: 8px;
  border-radius: 4px;
  border: 1px solid #ddd;
}

input[disabled] {
  background-color: #f0f0f0;
}

button {
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
}

.return-button {
  background-color: #f0f0f0;
  color: #333;
  border: 1px solid #ccc;
}

.submit-button {
  background-color: dodgerblue;
  color: white;
  border: none;
}

.submit-button:hover {
  background-color: #1e90ff;
}

.action-buttons {
  margin-top: 20px;
  display: flex;
  justify-content: flex-start; /* 靠左放置按钮 */
  margin-left: 20px; /* 添加左边距，使按钮不紧靠左边 */
}

.button-container {
  display: flex;
  gap: 10px;
}
</style>
