<template>
  <div>
    <div class="card" style="margin-bottom: 10px">
      <el-input style="width: 260px" v-model="data.name" class="w-50 m-2" placeholder="请输入课程名称进行查询" :prefix-icon="Search"/>
      <el-button type="primary" style="margin-left: 10px" @click="query">查询</el-button>
      <el-button type="info" @click="reset">重置</el-button>
    </div>
    <div class="card" style="margin-bottom: 10px">
      <div>
        <el-table :data="data.tableData" style="width: 100%">
          <el-table-column prop="teacherName" label="教师姓名" width="120"/>
          <el-table-column prop="courseName" label="课程名称" width="200"/>
          <el-table-column prop="className" label="教学班号" width="200"/>
          <el-table-column prop="grade" label="课程学分" width="120"/>
          <el-table-column prop="semester" label="开课学期" width="130"/>
          <el-table-column prop="studentNum" label="学生人数" width="130"/>
        </el-table>
      </div>
    </div>
    <div class="card">
      <el-pagination v-model:current-page="data.pageNum" v-model:page-size="data.pageSize"
                     @current-change="handelCurrentChange"
                     background layout="prev, pager, next" :total="data.total" />
    </div>
  </div>
</template>


<script setup>
import {reactive} from "vue"
import { Search } from '@element-plus/icons-vue'
import request from "@/utils/request";
import {ElMessage, ElMessageBox} from "element-plus";
const user = JSON.parse(localStorage.getItem('user'))
const data = reactive({
  name:'',
  tableData:[],
  total:0,
  pageNum:1, //当前页码
  pageSize:10, //每页个数
  formVisible:false,
  form:{},
  isEdit: false,  // 新增或编辑标志
})

const load = () => {
  request.get('http://localhost:8090/score/getInformationByTeacherName',{
    params: {
      teacherName:user.name
    }
  }).then(res => {
    data.tableData = res.data || []
    data.total = res.data.length || 0
  })
}

const query = () => {
  if(data.name === ''){
    load()
  }
  else{
    request.get('http://localhost:8090/score/getInformationByTeacherNameAndCourse',{
      params: {
        teacherName:user.name,
        courseName: data.name
      }
    }).then(res => {
      console.log(data.name)
      if(res.code === 200) {
        console.log(res.data)
        data.tableData = res.data || []
        data.total = res.data.length || 0
      }else {
        ElMessage.error(res.message);
      }
    })
  }
}

//调用方法获取后台数据
load()

const handelCurrentChange = (pageNum) => {
  //当翻页的时候重新加载数据即可
  load()
}
const reset = () => {
  data.name = ''
  load()
}

</script>