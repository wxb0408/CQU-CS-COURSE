<template>
  <div class="login-container">
    <div class="login-box">
      <div class="login-header">
        <span v-if="isRegister">注 册</span>
        <span v-else>登 录</span>
      </div>

      <!-- 登录表单 -->
      <el-form v-if="!isRegister" :model="loginForm" ref="loginFormRef" :rules="rules">
        <el-form-item label="账号" prop="id">
          <el-input prefix-icon="el-icon-user" v-model="loginForm.id" placeholder="请输入账号" />
        </el-form-item>

        <el-form-item label="密码" prop="password">
          <el-input show-password prefix-icon="el-icon-lock" v-model="loginForm.password" placeholder="请输入密码" />
        </el-form-item>

        <el-form-item label="角色" prop="role">
          <el-select v-model="loginForm.role" placeholder="选择角色">
            <el-option :value="3" label="管理员"></el-option>
            <el-option :value="1" label="学生"></el-option>
            <el-option :value="2" label="教师"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" style="width: 100%" @click="login">登 录</el-button>
        </el-form-item>

        <div v-if="loginForm.role === 1" class="switch-link">
          <el-button type="text" @click="toggleRegister">点击注册</el-button>
        </div>
      </el-form>

      <!-- 注册表单 -->
      <el-form v-else :model="registerForm" ref="registerFormRef" :rules="rules">
        <el-form-item label="学号" prop="studentid">
          <el-input prefix-icon="el-icon-user" v-model="registerForm.studentid" placeholder="请输入学号" />
        </el-form-item>

        <el-form-item label="姓名" prop="name">
          <el-input prefix-icon="el-icon-user" v-model="registerForm.name" placeholder="请输入姓名" />
        </el-form-item>

        <el-form-item label="密码" prop="password">
          <el-input show-password prefix-icon="el-icon-lock" v-model="registerForm.password" placeholder="请输入密码" />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" style="width: 100%" @click="register">注 册</el-button>
        </el-form-item>

        <div class="switch-link">
          <el-button type="text" @click="toggleRegister">返回登录</el-button>
        </div>
      </el-form>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from "vue";
import request from "../utils/request";
import { ElMessage } from "element-plus";
import router from "../router";

const isRegister = ref(false); // 当前是否是注册状态

// 登录表单
const loginForm = reactive({
  role: 1, // 默认角色为学生
  id: "",
  password: "",
});

// 注册表单
const registerForm = reactive({
  studentid: "",
  name: "",
  password: "",
});

// 验证规则
const rules = reactive({
  id: [{ required: true, message: "请输入账号", trigger: "blur" }],
  password: [{ required: true, message: "请输入密码", trigger: "blur" }],
  studentid: [{ required: true, message: "请输入学号", trigger: "blur" }],
  name: [{ required: true, message: "请输入姓名", trigger: "blur" }],
});

const loginFormRef = ref(); // 登录表单的引用
const registerFormRef = ref(); // 注册表单的引用

// 登录方法
const login = () => {
  loginFormRef.value.validate((valid) => {
    if (valid) {
      request.post("http://localhost:8090/login/login", loginForm).then((res) => {
        if (res.code === 200) {
          ElMessage.success("登录成功");
          router.push("/home"); // 跳转到主页
          localStorage.setItem("user", JSON.stringify(res.data));
        } else {
          ElMessage.error(res.message);
        }
      });
    }
  });
};

// 注册方法
const register = () => {
  registerFormRef.value.validate((valid) => {
    if (valid) {
      request.post("http://localhost:8090/login/register", registerForm).then((res) => {
        if (res.code === 200) {
          ElMessage.success("注册成功，请登录");
          toggleRegister();
        } else {
          ElMessage.error(res.message);
        }
      });
    }
  });
};

// 切换登录/注册状态
const toggleRegister = () => {
  isRegister.value = !isRegister.value;
};
</script>

<style scoped>
.login-container {
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #f0f2f5;
}

.login-box {
  background-color: #fff;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
  padding: 40px;
  border-radius: 8px;
  width: 400px;
  box-sizing: border-box;
}

.login-header {
  font-size: 24px;
  font-weight: bold;
  text-align: center;
  margin-bottom: 30px;
  color: #409eff;
}

.switch-link {
  display: flex;
  justify-content: center; /* Center button horizontally */
  align-items: center; /* Center button vertically */
  margin-top: 10px;
  width: 100%;
}

.switch-link el-button {
  width: auto; /* Allow the button to auto-size based on content */
}

.el-button {
  width: 100%;
  height: 40px;
  font-size: 16px;
}

.el-form-item {
  margin-bottom: 20px;
}

.el-input, .el-select {
  border-radius: 4px;
}

.el-form-item label {
  font-size: 14px;
  font-weight: 600;
}

.el-input__inner {
  border-radius: 4px;
}

.el-form-item .el-select .el-input__inner {
  border-radius: 4px;
}
</style>
