import { createApp } from 'vue'; // 使用命名导入
import App from './App.vue';       // 导入根组件
import router from './router';     // 导入路由
import ElementPlus from 'element-plus';
import 'element-plus/dist/index.css';

const app = createApp(App);       // 创建 Vue 应用实例
app.use(ElementPlus);
app.use(router);                  // 注册路由
app.mount('#app');                // 挂载到 #app 元素
