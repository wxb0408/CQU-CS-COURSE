<template>
  <div id="app">
    <router-view></router-view> <!-- 显示当前匹配的组件 -->
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
/* 这里可以添加全局样式 */
</style>
