import controller.*;
import service.Impl.viewServiceImpl;
import pojo.DataGenerate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static pojo.DataGenerate.*;
//入口类
public class Main {
    public static void main(String[] args) throws IOException {
        //获取各个类的唯一实例
        viewServiceImpl view = viewServiceImpl.getInstance();
        classController classes = classController.getInstance();
        courseController course = courseController.getInstance();
        scoreController score = scoreController.getInstance();
        studentController student = studentController.getInstance();
        teacherController teacher = teacherController.getInstance();
        //使用DataGenerate中的方法统一生成一系列的基本数据
        DataGenerate dg = new DataGenerate();
        ArrayList<pojo.Teacher> teachers = dg.generateTeachers();
        ArrayList<pojo.Class> clses = DataGenerate.generateClasses(teachers);
        ArrayList<pojo.Student> stu = dg.generateStudents(clses);
        ArrayList<pojo.Score> scores = dg.generateScores(stu,clses);
        ArrayList<pojo.Course> courses = generateCourses();
        //欢迎界面
        view.welcome();
        //是否结束标志位
        boolean flag = true;
        while(true) {
            //主菜单的显示
            view.MainMune();
            int num;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("请选择您要操作的项目1~6:");
            num = br.read();
            switch (num) {
                case 49:
                    //进入班级的菜单栏
                    classes.classfunction(stu,clses, scores);
                    break;
                case 50:
                    //进入课程的菜单栏
                    course.coursefunction(scores,clses,courses);
                    break;
                case 51:
                    //进入分数的菜单栏
                    score.scorefunction(stu,scores);
                    break;
                case 52:
                    //进入学生的菜单栏
                    student.studentfunction(stu,scores,clses);
                    break;
                case 53:
                    //进入教室的菜单栏
                    teacher.teacherfunction(scores,clses,teachers);
                    break;
                case 54:
                    //退出界面的显示
                    view.exit();
                    flag = false;
                    break;
                default:
                    System.out.println("请选择合适的数字！！！");
            }
        }
    }
}
