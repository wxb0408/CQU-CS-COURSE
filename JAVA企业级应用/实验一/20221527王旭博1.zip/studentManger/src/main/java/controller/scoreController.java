package controller;

import pojo.Score;
import pojo.Student;
import service.Impl.scoreServiceImpl;
import service.Impl.viewServiceImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class scoreController {
    //创建单例
    private static scoreController Instance;
    private scoreController(){}

    public static scoreController getInstance(){
        if (Instance == null){
            synchronized (scoreController.class){
                if(Instance==null){
                    Instance=new scoreController();
                }
            }
        }
        return Instance;
    }
    //使用单例
    private viewServiceImpl view = viewServiceImpl.getInstance();
    private scoreServiceImpl sc = scoreServiceImpl.getInstance();

    public void scorefunction(ArrayList<Student> stus, ArrayList<Score> scores) throws IOException {
        boolean flag = true;
        while(flag){
            view.scoreInformation();
            System.out.println("请选择您要操作的项目1~3：");
            int num;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            try {
                num = Integer.parseInt(input); // 将输入的字符串转为整数
            } catch (NumberFormatException e) {
                System.out.println("请输入有效的数字！");
                continue; // 继续循环要求用户重新输入
            }
            switch (num){
                case 1:
                    //展示所有学生的所有信息
                    sc.showAllStudent(scores);
                    break;
                case 2:
                    //修改/添加成绩
                    System.out.println("请输入学生id号：");
                    String studentid = br.readLine();
                    System.out.println("请输入课程编号：");
                    String courseid = br.readLine();
                    System.out.println("请输入平时成绩：");
                    String usualscore = br.readLine();
                    System.out.println("请输入实验成绩：");
                    String experimentscore = br.readLine();
                    System.out.println("请输入期中成绩：");
                    String midtermscore = br.readLine();
                    System.out.println("请输入期末成绩：");
                    String finaltermscore = br.readLine();
                    sc.updateStudentScore(stus,studentid,courseid,scores,usualscore,experimentscore,midtermscore,finaltermscore);
                    break;
                case 3:
                    flag = false;
                    break;
            }
        }
    }
}
