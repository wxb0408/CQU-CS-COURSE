package controller;

import pojo.Course;
import pojo.Score;
import service.Impl.classServiceImpl;
import service.Impl.courseServiceImpl;
import service.Impl.viewServiceImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class courseController {
    //单例模式
    private static courseController Instance;
    private courseController(){}

    public static courseController getInstance(){
        if (Instance == null){
            synchronized (courseController.class){
                if(Instance==null){
                    Instance=new courseController();
                }
            }
        }
        return Instance;
    }
    //使用各个类的单例
    private viewServiceImpl view = viewServiceImpl.getInstance();
    private courseServiceImpl course = courseServiceImpl.getInstance();
    private classServiceImpl cls =classServiceImpl.getInstance();
    public void coursefunction(ArrayList<Score> scores, ArrayList<pojo.Class> classes, ArrayList<Course> courses) throws IOException {
        boolean flag = true;
        while(flag) {
            //展示课程功能列表
            view.courseInformation();
            System.out.println("请选择您要操作的项目1~5：");
            int num;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            try {
                num = Integer.parseInt(input); // 将输入的字符串转为整数
            } catch (NumberFormatException e) {
                System.out.println("请输入有效的数字！");
                continue; // 继续循环要求用户重新输入
            }
            switch (num){
                case 1:
                    //查询课程信息
                    course.queryCourse(courses);
                    break;
                case 2:
                    //查询课程的班级
                    System.out.println("请输入需要查询的课程ID号：");
                    String courseid = br.readLine();
                    course.queryClassByCourse(classes,courseid);
                    break;
                case 3:
                    //查询课程学生成绩
                    System.out.println("请输入需要查询的课程ID号：");
                    String courseid1 = br.readLine();
                    ArrayList<Score> cous = course.queryCourseScoreAllStudents(scores,courseid1);
                    //调用子菜单栏
                    coursefunctiontwo(cous);
                    break;
                case 4:
                    System.out.println("请输入需要查询的课程ID号：");
                    String courseid2 = br.readLine();
                    //成绩分段查询
                    course.queryCourseScoreSegment(scores,courseid2);
                    break;
                case 5:
                    flag = false;
                    break;
                default:
                    System.out.println("请选择合适的数字！！！");
            }
        }
    }

    public void coursefunctiontwo(ArrayList<Score> scores) throws IOException{
        boolean flag = true;
        while(flag) {
            view.courseScore();
            System.out.println("请选择您要操作的项目：");
            int num1;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            try {
                num1 = Integer.parseInt(input); // 将输入的字符串转为整数
            } catch (NumberFormatException e) {
                System.out.println("请输入有效的数字！");
                continue; // 继续循环要求用户重新输入
            }
            switch (num1) {
                case 1:
                    //学号排名
                    cls.queryClassScoreByStudentId(scores);
                    break;
                case 2:
                    //分数排名
                    cls.queryClassScoreByFinalScore(scores);
                    break;
                case 3:
                    //成绩分段
                    cls.countClassScoreBySegment(scores);
                    break;
                case 4:
                    flag = false;
                    break;
                default:
                    System.out.println("请选择合适的数字！！！");
                    break;
            }
        }
    }
}
