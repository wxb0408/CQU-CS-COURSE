package controller;

import pojo.Score;
import pojo.Student;
import service.Impl.classServiceImpl;
import service.Impl.studentServiceImpl;
import service.Impl.viewServiceImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class studentController {

    //创建单例
    private static studentController Instance;
    private studentController(){}

    public static studentController getInstance(){
        if (Instance == null){
            synchronized (studentController.class){
                if(Instance==null){
                    Instance=new studentController();
                }
            }
        }
        return Instance;
    }
    //使用单例
    private viewServiceImpl view = viewServiceImpl.getInstance();
    private studentServiceImpl stus = studentServiceImpl.getInstance();
    private classServiceImpl cls = classServiceImpl.getInstance();

    public void studentfunction(ArrayList<Student> stu,ArrayList<Score> scores,ArrayList<pojo.Class> clsses) throws IOException {
        boolean flag = true;
        while(flag){
            //菜单栏展示
            view.studentInformation();
            System.out.println("请选择您要操作的项目1~7：");
            int num;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            try {
                num = Integer.parseInt(input); // 将输入的字符串转为整数
            } catch (NumberFormatException e) {
                System.out.println("请输入有效的数字！");
                continue; // 继续循环要求用户重新输入
            }
            switch (num){
                case 1:
                    //两种方式展示学生信息
                    System.out.println("请选择：1.按学号排名输出/2.按综合绩点排名输出");
                    String s = br.readLine();
                    int d = Integer.parseInt(s);
                    if(d == 1)
                        stus.showStudent(stu);
                    else
                        stus.queryClassScoreBygpa(stu);
                    break;
                case 2:

                    //模糊查询学生
                    System.out.println("请输入名字的部分信息：");
                    String o = br.readLine();
                    stus.fuzzyShowStudent(stu,o);
                    break;
                case 3:

                    //统计学生成绩
                    System.out.print("请输入学生 ID：");
                    String studentid = br.readLine();
                    stus.studentScores(stu,studentid,scores);
                    break;
                case 4:
                    //添加学生
                    stus.addStudent(stu);
                    break;
                case 5:
                    //更新学生信息
                    Student stu1 = new Student();
                    System.out.println("请输入待修改信息学生学号：");
                    String studentid1 = br.readLine();
                    stu1.setStudentId(studentid1);
                    System.out.println("请输入学生姓名：");
                    String studentname = br.readLine();
                    stu1.setStudentName(studentname);
                    System.out.println("请输入性别（男/女）：");
                    String sex = br.readLine();
                    stu1.setSex(sex);
                    stus.updateStudent(stu,stu1);
                    break;
                case 6:
                    //删除学生
                    System.out.println("请输入待删除学生学号：");
                    String studentid2 = br.readLine();
                    stus.deleteStudent(scores,clsses,stu,studentid2);
                    break;
                case 7:
                    //学生选课
                    cls.queryClassInformation(clsses);
                    System.out.println("请输入学生id：");
                    String studentid4 = br.readLine();
                    System.out.println("请根据上述教学班信息对每门课程选择一个班级：");
                    String selectedClassesInput = br.readLine();
                    String[] classArray = selectedClassesInput.split(","); // 按照逗号分隔
                    ArrayList<String> selectedClass = new ArrayList<>();
                    for (String classId : classArray) {
                        selectedClass.add(classId.trim()); // 去除前后空格并添加到列表中
                    }
                    stus.selectCourse(scores,clsses,stu,studentid4,selectedClass);
                    break;
                case 8:
                    flag = false;
                    break;
                default:
                    System.out.println("请选择合适的数字！！！");
            }
        }
    }
}
