package controller;

import pojo.Score;
import service.Impl.classServiceImpl;
import service.Impl.scoreServiceImpl;
import service.Impl.viewServiceImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class classController {
    //单例模式
    private static classController Instance;
    private classController(){}

    public static classController getInstance(){
        if (Instance == null){
            synchronized (classController.class){
                if(Instance==null){
                    Instance=new classController();
                }
            }
        }
        return Instance;
    }
    //使用所需累的单例
    private viewServiceImpl view = viewServiceImpl.getInstance();
    private classServiceImpl cls = classServiceImpl.getInstance();

    public void classfunction(ArrayList<pojo.Student> stus,ArrayList<pojo.Class> classes,ArrayList<pojo.Score> scores) throws IOException {
        boolean flag = true;
        while(flag) {
            //展示教学班信息界面
            view.classInformation();
            int num;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("请选择您要操作的项目：");
            String input = br.readLine();
            try {
                num = Integer.parseInt(input); // 将输入的字符串转为整数
            } catch (NumberFormatException e) {
                System.out.println("请输入有效的数字！");
                continue; // 继续循环要求用户重新输入
            }
            switch (num) {
                case 1:
                    //查询班级信息
                    cls.queryClassInformation(classes);
                    break;
                case 2:
                    System.out.println("请输入班级编号：");
                    String classid5 = br.readLine();
                    //查询班级学生信息
                    cls.queryClassStudentInformation(stus,classid5);
                    break;
                case 3:
                    String classid;
                    System.out.println("请输入您需要查询的班级号：");
                    classid = br.readLine();
                    //查询班级分数
                    ArrayList<Score> scoress = cls.queryClassScore(classid, scores);
                    //调用子菜单栏
                    classfunctiontwo(scoress);
                    break;
                case 4:
                    flag = false;
                    break;
                default:
                    System.out.println("请选择合适的数字！！！");

            }
        }
    }

    public void classfunctiontwo(ArrayList<Score> scoress) throws IOException {
        boolean flag = true;
        while(flag) {
            view.classScore();
            System.out.println("请选择您要操作的项目：");
            int num1;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            try {
                num1 = Integer.parseInt(input); // 将输入的字符串转为整数
            } catch (NumberFormatException e) {
                System.out.println("请输入有效的数字！");
                continue; // 继续循环要求用户重新输入
            }
            switch (num1) {
                case 1:
                    //按照学号排序
                    cls.queryClassScoreByStudentId(scoress);
                    break;
                case 2:
                    //按照综合成绩排序
                    cls.queryClassScoreByFinalScore(scoress);
                    break;
                case 3:
                    //统计分数段的比例
                    cls.countClassScoreBySegment(scoress);
                    break;
                case 4:
                    flag = false;
                    break;
                default:
                    System.out.println("请选择合适的数字！！！");
            }
        }
    }
}
