package controller;

import pojo.Score;
import pojo.Teacher;
import service.Impl.teacherServiceImpl;
import service.Impl.viewServiceImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class teacherController {

    private static teacherController Instance;
    private teacherController(){}

    public static teacherController getInstance(){
        if (Instance == null){
            synchronized (teacherController.class){
                if(Instance==null){
                    Instance=new teacherController();
                }
            }
        }
        return Instance;
    }

    private viewServiceImpl view = viewServiceImpl.getInstance();
    private teacherServiceImpl tea = teacherServiceImpl.getInstance();

    public void teacherfunction(ArrayList<Score> scores, ArrayList<pojo.Class> classes, ArrayList<Teacher> teacher) throws IOException {
        boolean flag = true;
        tea.firstExecute(classes,teacher);
        while(flag){
            view.teacherInformation();
            System.out.println("请选择您要操作的项目1~3：");
            int num;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            try {
                num = Integer.parseInt(input); // 将输入的字符串转为整数
            } catch (NumberFormatException e) {
                System.out.println("请输入有效的数字！");
                continue; // 继续循环要求用户重新输入
            }
            switch (num){
                case 1:
                    tea.showClassTeacher(classes,teacher);
                    break;
                case 2:
                    System.out.println("请输入待查看教师id:");
                    String teacherid = br.readLine();
                    tea.showScoreSegment(teacher,scores,teacherid);
                    break;
                case 3:
                    flag = false;
                    break;
                default:
                    System.out.println("请选择合适的数字！！！");

            }
        }
    }
}
