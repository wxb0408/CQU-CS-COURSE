package pojo;

import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Data
public class Score {
    private String studentId;//学生学号
    private String classId;//教学班号
    private String courseId;
    private String usualScore;//平时成绩
    private String experimentScore;//实验成绩
    private String midtermScore;//期中成绩
    private String finaltermScore;//期末成绩
    private String finalScore;//综合成绩
    private String gpa;
    private String creationTime; // 记录对象创建时间
    private String updateTime; // 记录对象最后更新时间

    public Score() {
        this.creationTime = getCurrentTime(); // 在构造时自动生成当前时间
        this.updateTime = this.creationTime; // 初始化更新时间
        this.usualScore = "0";
        this.experimentScore = "0";
        this.midtermScore = "0";
        this.finaltermScore = "0";
        this.finalScore = "0";
        this.gpa = "0";
    }

    // 获取当前时间的方法
    private String getCurrentTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return LocalDateTime.now().format(formatter); // 返回格式化后的当前时间
    }

    // 设置平时成绩并更新修改时间
    public void setUsualScore(String usualScore) {
        this.usualScore = usualScore;
        this.updateTime = getCurrentTime(); // 更新修改时间
    }

    // 设置实验成绩并更新修改时间
    public void setExperimentScore(String experimentScore) {
        this.experimentScore = experimentScore;
        this.updateTime = getCurrentTime(); // 更新修改时间
    }

    // 设置期中成绩并更新修改时间
    public void setMidtermScore(String midtermScore) {
        this.midtermScore = midtermScore;
        this.updateTime = getCurrentTime(); // 更新修改时间
    }

    // 设置期末成绩并更新修改时间
    public void setFinaltermScore(String finaltermScore) {
        this.finaltermScore = finaltermScore;
        this.updateTime = getCurrentTime(); // 更新修改时间
    }

    // 设置综合成绩并更新修改时间
    public void setFinalScore(String finalScore) {
        this.finalScore = finalScore;
        this.updateTime = getCurrentTime(); // 更新修改时间
    }

}
