package pojo;

import lombok.Data;

@Data
public class Class {
    private String teacherId;//教师
    private String courseId;//课程
    private Integer count;//总人数
    private String classId;//教学班号
}
