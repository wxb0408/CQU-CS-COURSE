package pojo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DataGenerate {
    // 六个老师的姓名
    private static final String[] TEACHER_NAMES = {
            "张老师", "李老师", "王老师", "赵老师", "刘老师", "陈老师"
    };
    // 六门课程名称
    private static final String[] COURSE_NAMES = {
            "软件工程", "计算机网络", "操作系统", "JAVA企业级应用", "移动应用软件开发", "大数据架构与技术"
    };
    // 课程对应的学分
    private static final String[] GRADE = {
            "3", "4.5", "4.5", "3", "3", "3"
    };
    // 六个课程编号
    private static final String[] COURSE_IDS = {
            "20240001", "20240010", "20240011", "20240100", "20240101", "20240110"
    };

    private static final String[] MAJOR_LIST = {
            "物联网工程", "计算机科学与技术", "信息安全", "光电科学与技术", "软件工程", "电气工程及其自动化"
    };

    private static final Random RANDOM = new Random(); // 随机数生成器
    private static final int STUDENT_COUNT = 225; // 学生总人数
    private static final int MIN_CLASS_SIZE = 20; // 一个班级的最少学生数目
    private static final int CLASS_PER_COURSE = 4; // 每门课程生成的班级数
    private static final int MIN_COURSES_PER_STUDENT = 3; // 每个学生最少选择的科目数量

    private static int teacherCounter = 1; // 教师编号从001开始
    private static int studentNumberCounter = 20220001; // 学号从20220001开始

    // 一个课程对应有四个班级
    public static ArrayList<pojo.Class> generateClasses(ArrayList<Teacher> teacherList) {
        ArrayList<pojo.Class> classList = new ArrayList<>(); // 创建班级的列表
        for (int i = 0; i < COURSE_NAMES.length; i++) {
            String courseName = COURSE_NAMES[i];
            String courseId = COURSE_IDS[i]; // 获取课程编号
            for (int j = 0; j < CLASS_PER_COURSE; j++) { // 每门课程生成多个班
                String classId = courseId + "_Class_" + j; // 班级ID
                pojo.Class newClass = new pojo.Class();
                // 随机选择一位教师
                Teacher randomTeacher = teacherList.get(RANDOM.nextInt(teacherList.size()));
                newClass.setTeacherId(randomTeacher.getTeacherId()); // 设置教师ID
                newClass.setCourseId(courseId); // 设置课程ID
                newClass.setCount(0); // 初始化班级人数为0
                newClass.setClassId(classId); // 设置班级ID
                classList.add(newClass); // 添加班级到班级列表中
            }
        }
        return classList; // 返回班级列表
    }

    // 对每一个课程及课程编号创建一个对象
    public static ArrayList<Course> generateCourses() {
        ArrayList<Course> courseList = new ArrayList<>();
        for (int i = 0; i < COURSE_NAMES.length; i++) {
            Course course = new Course();
            course.setCourseId(COURSE_IDS[i]); // 设置课程编号
            course.setCourseName(COURSE_NAMES[i]); // 设置课程名称
            course.setSemester(1); // 假设所有课程在同一学期开课
            course.setGrade(GRADE[i]); // 设置课程学分
            courseList.add(course); // 添加课程到列表
        }
        return courseList; // 返回课程列表
    }

    // 生成学生信息
    public static ArrayList<Student> generateStudents(ArrayList<Class> classList) {
        ArrayList<Student> studentList = new ArrayList<>();

        // 课程可选的班级映射
        List<List<String>> availableClassesByCourse = new ArrayList<>();
        for (String courseId : COURSE_IDS) {
            List<String> availableClassIds = new ArrayList<>();
            // 遍历班级列表，查找对应课程的班级
            for (Class aClass : classList) {
                if (aClass.getCourseId().equals(courseId)) {
                    availableClassIds.add(aClass.getClassId()); // 添加可选班级ID
                }
            }
            // 将找到的班级ID保存到可用班级列表中
            availableClassesByCourse.add(availableClassIds);
        }

        // 生成指定数量的学生
        for (int i = 0; i < STUDENT_COUNT; i++) {
            Student student = new Student();
            student.setStudentId(String.valueOf(studentNumberCounter++)); // 设置学生ID
            student.setMajor(MAJOR_LIST[i % 6]); // 随机选择专业
            student.setStudentName(generateStudentName()); // 生成学生姓名
            student.setSex(RANDOM.nextBoolean() ? "男" : "女"); // 随机设置性别

            // 随机选择至少三个不同的课程，选择班级
            ArrayList<String> classIds = new ArrayList<>();
            List<Integer> selectedCourseIndices = new ArrayList<>();

            // 确保选择的课程数量符合要求
            while (selectedCourseIndices.size() < MIN_COURSES_PER_STUDENT) {
                int courseIndex = RANDOM.nextInt(COURSE_IDS.length); // 随机选择课程索引
                if (!selectedCourseIndices.contains(courseIndex)) { // 确保不重复选择课程
                    selectedCourseIndices.add(courseIndex);
                    List<String> selectedClasses = availableClassesByCourse.get(courseIndex); // 获取可选的班级ID
                    if (!selectedClasses.isEmpty()) { // 如果有可选班级
                        String selectedClassId = selectedClasses.get(RANDOM.nextInt(selectedClasses.size())); // 随机选择班级ID
                        classIds.add(selectedClassId); // 添加班级ID

                        // 更新班级中已选学生人数
                        for (Class aClass : classList) {
                            if (aClass.getClassId().equals(selectedClassId)) {
                                aClass.setCount(aClass.getCount() + 1); // 班级人数加1
                                break; // 找到班级后退出循环
                            }
                        }
                    }
                }
            }
            student.setClassIds(classIds); // 设置学生选的班级ID
            studentList.add(student); // 将学生添加到学生列表中
        }
        return studentList; // 返回生成的学生列表
    }

    // 生成随机姓名
    public static String generateStudentName() {
        String[] firstNames = {"张", "李", "王", "赵", "刘", "陈", "杨", "黄", "吴", "周", "钱", "孙", "包", "郑", "徐"};
        String[] lastNames = {"伟", "芳", "娜", "敏", "静", "磊", "强", "辉", "明", "飞", "礼", "途", "波", "宇", "炜"};
        String firstName = firstNames[RANDOM.nextInt(firstNames.length)]; // 随机选择姓
        String lastName = lastNames[RANDOM.nextInt(lastNames.length)]; // 随机选择名
        return firstName + lastName; // 返回完整姓名
    }

    // 生成教师列表
    public static ArrayList<Teacher> generateTeachers() {
        ArrayList<Teacher> teacherList = new ArrayList<>();
        for (String teacherName : TEACHER_NAMES) {
            Teacher teacher = new Teacher();
            teacher.setTeacherId(String.format("%03d", teacherCounter++)); // 教师编号格式化为三位数
            teacher.setTeacherName(teacherName);
            teacher.setClasses(new ArrayList<>()); // 初始化授课班级列表
            teacherList.add(teacher); // 添加教师到列表
        }
        return teacherList; // 返回教师列表
    }

    // 生成成绩列表
    public static ArrayList<Score> generateScores(ArrayList<Student> studentList, ArrayList<Class> classList) {
        ArrayList<Score> scoreList = new ArrayList<>();
        for (Student student : studentList) {
            double totalgrade = 0.0; // 总学分
            double totalscore = 0.0; // 总分数
            for (String classId : student.getClassIds()) {
                Score score = new Score();
                score.setStudentId(student.getStudentId());
                score.setClassId(classId);
                // 根据班级获取课程ID
                String courseId = "";
                for (Class aClass : classList) {
                    if (aClass.getClassId().equals(classId)) {
                        courseId = aClass.getCourseId(); // 获取课程ID
                        break;
                    }
                }
                score.setCourseId(courseId);
                Integer index = 0; // 课程的索引
                for (int i = 0; i < COURSE_IDS.length; i++) {
                    if (COURSE_IDS[i].equals(courseId)) {
                        index = i; // 找到对应课程的索引
                    }
                }
                totalgrade = totalgrade + Float.parseFloat(GRADE[index]); // 累加学分
                // 随机生成各项成绩
                int usualScore = RANDOM.nextInt(51) + 50; // 生成50-100之间的分数
                int experimentScore = RANDOM.nextInt(51) + 50;
                int midtermScore = RANDOM.nextInt(51) + 50;
                int finaltermScore = RANDOM.nextInt(51) + 50;

                // 计算综合成绩
                int finalScore = (int) ((usualScore * 0.1)
                        + (experimentScore * 0.2)
                        + (midtermScore * 0.2)
                        + (finaltermScore * 0.5)); // 加权计算总分
                double gpa = calculateGPA(finalScore); // 计算GPA
                totalscore = totalscore + Float.parseFloat(GRADE[index]) * gpa; // 累加总分数
                score.setUsualScore(String.valueOf(usualScore));
                score.setExperimentScore(String.valueOf(experimentScore));
                score.setMidtermScore(String.valueOf(midtermScore));
                score.setFinaltermScore(String.valueOf(finaltermScore));
                score.setFinalScore(String.valueOf(finalScore));
                score.setGpa(String.valueOf(gpa));
                scoreList.add(score); // 将成绩记录添加到成绩列表
            }
            String finalgpa = String.valueOf(totalscore / totalgrade); // 计算最终GPA
            student.setGpa(finalgpa); // 设置学生的综合绩点
        }
        return scoreList; // 返回生成的成绩列表
    }

    // 根据最终成绩计算GPA
    private static double calculateGPA(int finalScore) {
        if (finalScore >= 90 && finalScore <= 100) {
            return 4.0; // GPA为4.0
        } else if (finalScore < 60) {
            return 0.0; // GPA为0.0
        } else {
            return 4.0 - (90 - finalScore) * 0.1; // 每减一分GPA减0.1
        }
    }
}

