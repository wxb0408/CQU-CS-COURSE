package pojo;

import lombok.Data;

import java.util.ArrayList;

@Data
public class Teacher {
    private String teacherId;//教师编号
    private String teacherName;//教师姓名
    private ArrayList<String> classes;
}
