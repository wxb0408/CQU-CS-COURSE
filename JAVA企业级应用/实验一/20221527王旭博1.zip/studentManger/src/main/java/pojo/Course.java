package pojo;

import lombok.Data;

@Data
public class Course {
    private String courseId;//课程编号
    private String courseName;//课程名字
    private String grade;//学分
    private Integer semester;//开课学期
}
