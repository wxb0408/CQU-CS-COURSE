package pojo;

import lombok.Data;

import java.util.ArrayList;

@Data
public class Student {
    private String studentId;//学号
    private String studentName;//学生姓名
    private String major;//专业
    private String sex;//性别
    private String gpa;//绩点
    private ArrayList<String> classIds;//教学班号组

    public Student() {
        this.gpa = "0"; // 默认绩点为0
        this.classIds = new ArrayList<>(); // 初始化教学班号组
    }
}
