package service;

import pojo.Score;
import pojo.Student;

import java.util.ArrayList;

public interface scoreService {
    //查看所有学生的成绩
    void showAllStudent(ArrayList<Score> scores);
    //修改学生成绩
    void updateStudentScore(ArrayList<Student> stus, String studentid, String courseid, ArrayList<Score> scores, String usualsc, String experimentsc, String midtermsc, String finaltermsc);
}
