package service;

import pojo.Score;
import pojo.Teacher;

import java.util.ArrayList;

public interface teacherService {
    //补全教师班级信息
    void firstExecute(ArrayList<pojo.Class> cls, ArrayList<Teacher> tea);
    //查询教师教学班信息
    void showClassTeacher(ArrayList<pojo.Class> cls, ArrayList<Teacher> tea);
    //查询教师教学班课程成绩分布情况
    void showScoreSegment(ArrayList<Teacher> teachers,ArrayList<Score> scores, String teacherid);
    //
}
