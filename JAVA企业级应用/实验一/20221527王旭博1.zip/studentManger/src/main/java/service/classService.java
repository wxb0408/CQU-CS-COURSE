package service;

import pojo.Class;
import pojo.Score;
import pojo.Student;

import java.util.ArrayList;

public interface classService {
    //查询班级基本信息
    void queryClassInformation(ArrayList<Class> classes);
    //查看班级所有学生的基本信息
    void queryClassStudentInformation(ArrayList<Student> stus,String classId);
    //查询班级所有学生的成绩
    ArrayList<Score> queryClassScore(String classId,ArrayList<Score> scores);
    //班级成绩按照学号排序
    void queryClassScoreByStudentId(ArrayList<Score> scores);
    //班级成绩按照综合成绩排名
    void queryClassScoreByFinalScore(ArrayList<Score> scores);
    //统计教学班分数段的分布
    void countClassScoreBySegment(ArrayList<Score> scores);
}
