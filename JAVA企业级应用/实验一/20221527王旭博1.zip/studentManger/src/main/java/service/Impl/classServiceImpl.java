package service.Impl;

import pojo.Score;
import pojo.Student;
import service.classService;
import pojo.Class;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

public class classServiceImpl implements classService {
    //单例模式的使用
    private static classServiceImpl Instance;
    private classServiceImpl(){}

    public static classServiceImpl getInstance(){
        if (Instance == null){
            synchronized (classServiceImpl.class){
                if(Instance==null){
                    Instance=new classServiceImpl();
                }
            }
        }
        return Instance;
    }

    @Override
    public void queryClassInformation(ArrayList<Class> classes) {//流查询班级的信息
        classes.stream().forEach(cls->System.out.println("教师："+cls.getTeacherId()+" 课程："+cls.getCourseId()+
                " 教学班："+cls.getClassId()+" 总人数："+cls.getCount()));
    }

    @Override
    public void queryClassStudentInformation(ArrayList<Student> stus, String classId) {//流查询某个班级的学生信息
        stus.stream().filter(student->student.getClassIds().contains(classId))
                .forEach(student->System.out.println("学号："+student.getStudentId()+" 姓名："+student.getStudentName()+
                        " 性别："+student.getSex()+" 专业："+student.getMajor()));
    }

    @Override
    public ArrayList<Score> queryClassScore(String classId,ArrayList<Score> scores) {//流查询班级学生分数，并传回查询结果
        ArrayList<Score> classScore = new ArrayList<>();
        System.out.printf("%-15s %-15s %-10s %-10s %-10s %-10s %-10s\n", "学生ID", "教学班号","平时成绩", "实验成绩","期中成绩","期末成绩","综合成绩");
        System.out.println("-------------------------------------------------------------------------------------------------------------");
        for(Score sc:scores){
            if(sc.getClassId().equals(classId)){
                classScore.add(sc);
                System.out.printf("%-15s %-20s %-13s %-13s %-13s %-13s %-13s\n", sc.getStudentId(), sc.getClassId(), sc.getUsualScore(),
                        sc.getExperimentScore(),sc.getMidtermScore(),sc.getFinaltermScore(),sc.getFinalScore());
            }
        }
        return classScore;
    }

    @Override
    public void queryClassScoreByStudentId(ArrayList<Score> classScore) {
        //使用内部类重新第一自定义类型的排序函数
        Collections.sort(classScore, new Comparator<Score>() {
            @Override
            public int compare(Score o1, Score o2) {
                return o1.getStudentId().compareTo(o2.getStudentId());
            }
        });
        System.out.printf("%-15s %-15s %-15s %-10s %-10s %-10s %-10s %-10s\n", "学生ID", "教学班号","课程编号","平时成绩", "实验成绩","期中成绩","期末成绩","综合成绩");
        System.out.println("-------------------------------------------------------------------------------------------------------------");
        for(Score sc:classScore){
            System.out.printf("%-15s %-15s %-20s %-13s %-13s %-13s %-13s %-13s\n", sc.getStudentId(), sc.getClassId(),sc.getCourseId(), sc.getUsualScore(),
                    sc.getExperimentScore(),sc.getMidtermScore(),sc.getFinaltermScore(),sc.getFinalScore());
        }
    }

    @Override
    public void queryClassScoreByFinalScore(ArrayList<Score> classScore) {
        //使用内部类重新第一自定义类型的排序函数
        Collections.sort(classScore, new Comparator<Score>() {
            @Override
            public int compare
                    (Score o1, Score o2) {
                return o1.getFinalScore().compareTo(o2.getFinalScore());
            }
        });

        System.out.printf("%-15s %-15s %-15s %-10s %-10s %-10s %-10s %-10s\n", "学生ID", "教学班号","课程编号","平时成绩", "实验成绩","期中成绩","期末成绩","综合成绩");
        System.out.println("-------------------------------------------------------------------------------------------------------------");
        for(Score sc:classScore){
            System.out.printf("%-15s %-15s %-20s %-13s %-13s %-13s %-13s %-13s\n", sc.getStudentId(), sc.getClassId(),sc.getCourseId(), sc.getUsualScore(),
                    sc.getExperimentScore(),sc.getMidtermScore(),sc.getFinaltermScore(),sc.getFinalScore());
        }
    }

    @Override
    public void countClassScoreBySegment(ArrayList<Score> classScore) {
        Integer studentCount = classScore.size(); // 获取学生总数

        // 统计各个分数段的计数数组
        int[] usualCounts = new int[4];
        int[] experimentCounts = new int[4];
        int[] midtermCounts = new int[4];
        int[] finaltermCounts = new int[4];
        int[] finalCounts = new int[4];

        // 遍历每个学生的成绩，统计各个分数段的数量
        for (Score score : classScore) {
            addToCounts(usualCounts, parseScore(score.getUsualScore()));
            addToCounts(experimentCounts, parseScore(score.getExperimentScore()));
            addToCounts(midtermCounts, parseScore(score.getMidtermScore()));
            addToCounts(finaltermCounts, parseScore(score.getFinaltermScore()));
            addToCounts(finalCounts, parseScore(score.getFinalScore()));
        }

        // 打印每种成绩类型的统计结果
        printResults("平时成绩", usualCounts, studentCount);
        printResults("实验成绩", experimentCounts, studentCount);
        printResults("期中成绩", midtermCounts, studentCount);
        printResults("期末成绩", finaltermCounts, studentCount);
        printResults("综合成绩", finalCounts, studentCount);
    }

    private void addToCounts(int[] counts, int score) {
        // 根据分数范围更新计数数组
        if (score < 60) {
            counts[0]++;
        } else if (score >= 60 && score < 80) {
            counts[1]++;
        } else if (score >= 80 && score <= 100) {
            counts[2]++;
        }
    }

    private void printResults(String scoreType, int[] counts, int totalStudents) {
        System.out.println(scoreType + "统计："); // 打印当前成绩类型的统计标题

        // 计算并打印每个阶段的占比和对应的彩色横条
        for (int i = 0; i < counts.length; i++) {
            double percentage = counts[i] * 100.0 / totalStudents; // 计算各分数段占比
            String bar = createColoredBar(percentage, i); // 创建对应的彩色横条

            switch (i) {
                case 0:
                    System.out.println("60以下人数占比： " + String.format("%.2f", percentage) + "%" + " " + bar);
                    break;
                case 1:
                    System.out.println("60-80人数占比： " + String.format("%.2f", percentage) + "%" + " " + bar);
                    break;
                case 2:
                    System.out.println("80-100人数占比：" + String.format("%.2f", percentage) + "%" + " " + bar);
                    break;
                default:
                    break;
            }
        }
    }

    private String createColoredBar(double percentage, int index) {
        int length = (int) (percentage / 2); // 假设每2%对应一个字符的长度
        StringBuilder bar = new StringBuilder();

        // 根据索引定义颜色代码
        String color;
        switch (index) {
            case 0: color = "\u001B[31m"; // 红色
                break;
            case 1: color = "\u001B[33m"; // 黄色
                break;
            case 2: color = "\u001B[32m"; // 绿色
                break;
            default: color = "\u001B[0m"; // 默认颜色
                break;
        }
        // 创建彩色横条
        for (int j = 0; j < length; j++) {
            bar.append(color + "█");  // 用█字符表示横条
        }
        bar.append("\u001B[0m"); // 重置颜色
        return bar.toString();
    }

    private int parseScore(String scoreStr) {
        // 尝试将字符串转换为整数，若失败则返回0
        try {
            return Integer.parseInt(scoreStr);
        } catch (NumberFormatException e) {
            return 0; // 若无法转换则设置为0分
        }
    }



}
