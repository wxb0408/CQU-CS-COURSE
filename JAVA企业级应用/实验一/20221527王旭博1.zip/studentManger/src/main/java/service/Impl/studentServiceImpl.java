package service.Impl;

import pojo.Class;
import pojo.Score;
import pojo.Student;
import service.studentService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.regex.Pattern;

public class studentServiceImpl implements studentService {
    // 单例模式的使用
    private static studentServiceImpl Instance; // 静态实例
    private studentServiceImpl(){} // 私有构造函数，防止外部实例化

    public static studentServiceImpl getInstance() {
        if (Instance == null) {
            synchronized (studentServiceImpl.class) { // 线程安全的单例实现
                if (Instance == null) {
                    Instance = new studentServiceImpl(); // 实例化对象
                }
            }
        }
        return Instance; // 返回单例对象
    }

    @Override
    public void showStudent(ArrayList<Student> stus) {
        // 遍历学生列表并打印学生信息
        stus.stream().forEach(student -> {
            System.out.println("学号: " + student.getStudentId() +
                    ", 姓名: " + student.getStudentName() +
                    ", 性别: " + student.getSex() +
                    ", 专业: " + String.format("%-15s", student.getMajor()) +
                    ", 综合绩点: " + String.format("%.2f", Double.parseDouble(student.getGpa())) +
                    ", 教学班号: " + String.join(", ", student.getClassIds()));
        });
    }

    @Override
    public void fuzzyShowStudent(ArrayList<Student> stus, String s) {
        // 将用户输入的字符串转换为正则表达式，并将其转义
        String regex = ".*" + Pattern.quote(s) + ".*";
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE); // 忽略大小写
        boolean found = false; // 记录是否找到匹配的学生

        // 遍历学生列表，检查姓名是否匹配
        for (Student student : stus) {
            if (pattern.matcher(student.getStudentName()).find()) {
                found = true; // 找到匹配学生
                int spaceAfterMajor = 15; // 控制专业字段的格式
                System.out.println("学号: " + student.getStudentId() +
                        ", 姓名: " + student.getStudentName() +
                        ", 性别: " + student.getSex() +
                        ", 专业: " + student.getMajor() +
                        String.format("%" + (spaceAfterMajor - student.getMajor().length()) + "s", "") +
                        ", 综合绩点: " + String.format("%.2f", Double.parseDouble(student.getGpa())) +
                        ", 教学班号: " + String.join(", ", student.getClassIds()));
            }
        }
        // 如果没有找到匹配的学生，输出提示信息
        if (!found) {
            System.out.println("未找到匹配的学生信息。");
        }
    }

    @Override
    public void queryClassScoreBygpa(ArrayList<Student> stus) {
        // 按综合绩点排序学生列表
        Collections.sort(stus, new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                return o1.getGpa().compareTo(o2.getGpa());
            }
        });
        // 打印排序后的学生信息
        stus.stream().forEach(student -> {
            System.out.println("学号: " + student.getStudentId() +
                    ", 姓名: " + student.getStudentName() +
                    ", 性别: " + student.getSex() +
                    ", 专业: " + String.format("%-15s", student.getMajor()) +
                    ", 综合绩点: " + String.format("%.2f", Double.parseDouble(student.getGpa())) +
                    ", 教学班号: " + String.join(", ", student.getClassIds()));
        });
    }

    @Override
    public void studentScores(ArrayList<Student> stus, String studentId, ArrayList<Score> scores) {
        // 查找学生并打印信息
        boolean studentFound = stus.stream()
                .filter(stu -> stu.getStudentId().equals(studentId))
                .findFirst()
                .map(stu -> {
                    System.out.println("学生ID: " + stu.getStudentId() +
                            ", 综合绩点: " + String.format("%.2f", Double.parseDouble(stu.getGpa())));
                    return true; // 学生找到，返回 true
                }).orElse(false); // 如果没有找到学生，返回 false

        // 如果没有找到学生，打印提示信息
        if (!studentFound) {
            System.out.println("未找到学生 ID 为 " + studentId + " 的学生。");
        } else {
            // 查找学生成绩并打印
            boolean scoresFound = scores.stream()
                    .filter(score -> score.getStudentId().equals(studentId))
                    .peek(score -> {
                        // 打印每个成绩信息
                        System.out.println("学生ID: " + score.getStudentId() +
                                ", 科目: " + score.getCourseId() +
                                ", 平时成绩: " + score.getUsualScore() +
                                ", 实验成绩: " + score.getExperimentScore() +
                                ", 期中成绩: " + score.getMidtermScore() +
                                ", 期末成绩: " + score.getFinaltermScore() +
                                ", 综合成绩: " + score.getFinalScore() +
                                ", 单科绩点: " + String.format("%.2f", Double.parseDouble(score.getGpa())));
                    }).count() > 0; // 通过计数来判断是否找到了成绩记录

            // 如果没有找到成绩记录，打印提示信息
            if (!scoresFound) {
                System.out.println("未找到学生 ID 为 " + studentId + " 的成绩记录。");
            }
        }
    }

    @Override
    public void addStudent(ArrayList<Student> stus) {
        Student stu = new Student(); // 新建学生对象
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            ArrayList<String> clssId = new ArrayList<>(); // 用于存储课程 ID
            System.out.println("请输入学生id号：");
            String studentid = br.readLine(); // 输入学号
            stu.setStudentId(studentid);
            System.out.println("请输入学生姓名：");
            String studentname = br.readLine(); // 输入姓名
            stu.setStudentName(studentname);
            System.out.println("请输入性别（男/女）：");
            String sex = br.readLine(); // 输入性别
            stu.setSex(sex);
            System.out.println("请输入专业：");
            String major = br.readLine(); // 输入专业
            stu.setMajor(major);
            stu.setClassIds(clssId); // 设置课程 ID
            stus.add(stu); // 添加学生到列表
            System.out.println("学生添加成功！");
        } catch (IOException e) {
            System.out.println("添加失败，请重试！");
        }
    }

    @Override
    public boolean updateStudent(ArrayList<Student> stus, Student stu) {
        // 查找并更新学生信息
        return stus.stream().filter(stu1 -> stu1.getStudentId().equals(stu.getStudentId())).findFirst()
                .map(existingStudent -> {
                    existingStudent.setStudentName(stu.getStudentName());
                    existingStudent.setSex(stu.getSex());
                    System.out.println("修改成功。");
                    return true; // 更新成功，返回 true
                })
                .orElseGet(() -> {
                    System.out.println("未找到学生，无法更新信息。"); // 提示用户未找到
                    return false; // 更新失败，返回 false
                });
    }

    @Override
    public void deleteStudent(ArrayList<Score> scores, ArrayList<Class> classes, ArrayList<Student> stus, String studentId) {
        ArrayList<String> classids = new ArrayList<>();
        // 找到学生并获取其班级 ID
        stus.stream().filter(stu -> stu.getStudentId().equals(studentId)).findFirst()
                .ifPresent(stu -> stu.getClassIds().stream().forEach(s -> classids.add(s)));
        boolean removed = stus.removeIf(stu -> stu.getStudentId().equals(studentId)); // 删除学生
        if (removed) {
            // 更新班级人数
            for (String classId : classids) {
                classes.stream()
                        .filter(cls -> cls.getClassId().equals(classId)) // 根据班级 ID 查找
                        .findFirst()
                        .ifPresent(cls -> {
                            cls.setCount(cls.getCount() - 1); // 减1操作
                        });
            }
            // 删除学生的成绩记录
            scores.removeIf(score -> score.getStudentId().equals(studentId));
            System.out.println("学生 ID 为 " + studentId + " 的学生已被删除。");
        } else {
            System.out.println("未找到学生 ID 为 " + studentId + " 的学生，删除失败。");
        }
    }

    @Override
    public void selectCourse(ArrayList<Score> scores, ArrayList<Class> classes, ArrayList<Student> stus, String studentId, ArrayList<String> selectedClass) {
        Set<String> classPrefixes = new HashSet<>(); // 用于记录课程的前缀
        boolean hasDuplicate = false; // 标记是否有重复的课程

        // 检查选择的课程中是否存在重复的课程
        for (String classId : selectedClass) {
            String prefix = classId.length() >= 8 ? classId.substring(0, 8) : classId; // 提取班级编号的前8位

            // 判断当前前缀是否已经存在
            if (classPrefixes.contains(prefix)) {
                hasDuplicate = true; // 找到重复的课程
                break;
            } else {
                classPrefixes.add(prefix); // 记录当前前缀
            }
        }

        if (hasDuplicate) {
            System.out.println("选择的课程班级中存在重复的课程,请重新选课！");
            return; // 退出方法，不进行选课
        }

        stus.stream()
                .filter(stu -> stu.getStudentId().equals(studentId)) // 筛选出 ID 符合的学生
                .findFirst() // 找到第一个匹配的学生
                .ifPresentOrElse(existingStudent -> {
                    existingStudent.setClassIds(selectedClass); // 更新学生的课程列表
                    // 为每个选择的课程创建新的成绩记录
                    for (Integer i = 0; i < selectedClass.size(); i++) {
                        Score sc = new Score();
                        sc.setStudentId(studentId);
                        Integer subi = i;
                        sc.setClassId(selectedClass.get(subi));
                        // 更新班级人数
                        classes.stream().filter(cls -> cls.getClassId().equals(selectedClass.get(subi))).findFirst()
                                .ifPresent(cls -> {
                                    cls.setCount(cls.getCount() + 1);
                                    sc.setCourseId(cls.getCourseId()); // 设置课程 ID
                                });
                        scores.add(sc); // 将成绩记录添加到成绩列表
                    }
                    System.out.println("已为学生 ID " + studentId + " 选择课程： " + selectedClass); // 提示选课成功的信息
                }, () -> {
                    System.out.println("未找到学生 ID 为 " + studentId + " 的学生，无法选择课程。"); // 提示未找到学生的信息
                });
    }
}

