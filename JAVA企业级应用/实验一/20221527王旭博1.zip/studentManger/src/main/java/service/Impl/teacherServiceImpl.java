package service.Impl;

import pojo.Score;
import pojo.Teacher;
import service.teacherService;

import java.util.ArrayList;

public class teacherServiceImpl implements teacherService {
    // 单例模式的使用
    private static teacherServiceImpl Instance; // 静态实例
    private teacherServiceImpl(){} // 私有构造函数，防止外部实例化

    public static teacherServiceImpl getInstance(){
        if (Instance == null){
            synchronized (teacherServiceImpl.class){ // 线程安全的单例实现
                if(Instance==null){
                    Instance=new teacherServiceImpl(); // 实例化对象
                }
            }
        }
        return Instance; // 返回单例对象
    }

    @Override
    public void firstExecute(ArrayList<pojo.Class> cls, ArrayList<Teacher> tea) {
        // 为每位教师设置指导的班级
        tea.forEach(teacher -> {
            String teacherId = teacher.getTeacherId(); // 获取教师编号
            ArrayList<String> classIds = new ArrayList<>(); // 创建一个班级ID列表
            for (pojo.Class aClass : cls) {
                if (aClass.getTeacherId().equals(teacherId)) {
                    classIds.add(aClass.getClassId()); // 添加班级编号到列表中
                }
            }
            teacher.setClasses(classIds); // 更新教师的班级列表
        });
    }

    @Override
    public void showClassTeacher(ArrayList<pojo.Class> cls, ArrayList<Teacher> tea) {
        // 显示每位教师及其所教的班级
        tea.stream().forEach(student -> {
            System.out.println("教师编号: " + student.getTeacherId() +
                    ", 姓名: " + student.getTeacherName() +
                    ", 教学班号: " + String.join(", ", student.getClasses()));
        });
    }

    @Override
    public void showScoreSegment(ArrayList<Teacher> teachers, ArrayList<Score> scores, String teacherid) {
        // 获取教师指导的班级并统计成绩
        ArrayList<String> classes = new ArrayList<>();
        teachers.stream().filter(tea -> tea.getTeacherId().equals(teacherid)).findFirst()
                .ifPresent(tea -> classes.addAll(tea.getClasses())); // 获取教师对应的班级列表

        for (Integer i = 0; i < classes.size(); i++) {
            ArrayList<Score> classScore = new ArrayList<>();
            Integer finalI = i; // 为 lambda 表达式捕获的变量
            scores.stream().filter(score -> score.getClassId().equals(classes.get(finalI)))
                    .forEach(score -> classScore.add(score)); // 添加对应班级的成绩到班级成绩列表

            Integer studentCount = classScore.size(); // 当前班级的学生数
            System.out.println("--------------------------------------------");
            System.out.println("教学班" + classes.get(finalI) + "的成绩组成为：");
            int[] usualCounts = new int[4];
            int[] experimentCounts = new int[4];
            int[] midtermCounts = new int[4];
            int[] finaltermCounts = new int[4];
            int[] finalCounts = new int[4];

            // 统计所有成绩
            for (Score score : classScore) {
                addToCounts(usualCounts, parseScore(score.getUsualScore()));
                addToCounts(experimentCounts, parseScore(score.getExperimentScore()));
                addToCounts(midtermCounts, parseScore(score.getMidtermScore()));
                addToCounts(finaltermCounts, parseScore(score.getFinaltermScore()));
                addToCounts(finalCounts, parseScore(score.getFinalScore()));
            }

            // 打印结果
            printResults("平时成绩", usualCounts, studentCount);
            printResults("实验成绩", experimentCounts, studentCount);
            printResults("期中成绩", midtermCounts, studentCount);
            printResults("期末成绩", finaltermCounts, studentCount);
            printResults("综合成绩", finalCounts, studentCount);
        }
    }

    private void addToCounts(int[] counts, int score) {
        // 根据分数范围更新计数数组
        if (score < 60) {
            counts[0]++;
        } else if (score >= 60 && score < 80) {
            counts[1]++;
        } else if (score >= 80 && score <= 100) {
            counts[2]++;
        }
    }

    private void printResults(String scoreType, int[] counts, int totalStudents) {
        // 打印成绩统计信息
        System.out.println(scoreType + "统计：");

        for (int i = 0; i < counts.length; i++) {
            double percentage = counts[i] * 100.0 / totalStudents; // 计算百分比
            String bar = createColoredBar(percentage, i); // 创建彩色横条

            // 打印各成绩段占比及对应的横条
            switch (i) {
                case 0:
                    System.out.println("60以下人数占比： " + String.format("%.2f", percentage) + "%" + " " + bar);
                    break;
                case 1:
                    System.out.println("60-80人数占比： " + String.format("%.2f", percentage) + "%" + " " + bar);
                    break;
                case 2:
                    System.out.println("80-100人数占比：" + String.format("%.2f", percentage) + "%" + " " + bar);
                    break;
                default:
                    break;
            }
        }
    }

    private String createColoredBar(double percentage, int index) {
        int length = (int) (percentage / 2); // 假设每2%对应一个字符的长度
        StringBuilder bar = new StringBuilder();

        // 根据索引定义颜色代码
        String color;
        switch (index) {
            case 0: color = "\u001B[31m"; // 红色
                break;
            case 1: color = "\u001B[33m"; // 黄色
                break;
            case 2: color = "\u001B[32m"; // 绿色
                break;
            default: color = "\u001B[0m"; // 默认颜色
                break;
        }

        // 创建彩色横条
        for (int j = 0; j < length; j++) {
            bar.append(color + "█");  // 用█字符表示横条
        }

        bar.append("\u001B[0m"); // 重置颜色
        return bar.toString(); // 返回彩色横条
    }

    private int parseScore(String scoreStr) {
        // 尝试将字符串转换为整数，若失败则返回0
        try {
            return Integer.parseInt(scoreStr);
        } catch (NumberFormatException e) {
            return 0; // 若无法转换则设置为0分
        }
    }
}

