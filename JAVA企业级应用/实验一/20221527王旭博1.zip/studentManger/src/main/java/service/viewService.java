package service;

public interface viewService {
    void welcome();
    void MainMune();
    void exit();
    void classInformation();
    void classScore();
    void courseInformation();
    void studentInformation();
    void teacherInformation();
    void courseScore();
    void scoreInformation();
}
