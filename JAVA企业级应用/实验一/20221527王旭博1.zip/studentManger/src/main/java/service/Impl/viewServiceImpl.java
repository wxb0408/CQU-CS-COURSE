package service.Impl;

import service.viewService;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class viewServiceImpl implements viewService {
    //单例模式的使用
    private static viewServiceImpl Instance;
    private viewServiceImpl(){}

    public static viewServiceImpl getInstance(){
        if (Instance == null){
            synchronized (viewServiceImpl.class){
                if(Instance==null){
                    Instance=new viewServiceImpl();
                }
            }
        }
        return Instance;
    }


    @Override
    public void welcome(){
        System.out.println("--------------------------------------------");
        System.out.println("欢迎来到学生成绩管理系统!");
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedTime = currentTime.format(formatter);
        System.out.println("当前时间: " + formattedTime);
        System.out.print("当前学生数量: " + 225);
        System.out.println("\t\t\t当前课程数量: " + 6);
        System.out.print("当前教师数量: " + 6);
        System.out.println("\t\t\t当前班级数量: " + 24);
    }
    @Override
    public void MainMune() {
        System.out.println("--------------------------------------------");
        System.out.print("1.班级相关信息操作");
        System.out.println("\t\t\t2.课程相关信息操作");
        System.out.print("3.成绩相关信息操作");
        System.out.println("\t\t\t4.学生相关信息操作");
        System.out.print("5.教师相关信息操作");
        System.out.println("\t\t\t6.退出");
    }

    @Override
    public void exit() {
        System.out.println("--------------------------------------------");
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedTime = currentTime.format(formatter);
        System.out.println("当前时间: " + formattedTime);
        System.out.println("感谢您使用本系统,再见!");
        System.out.println("--------------------------------------------");
        System.exit(1);
    }
    @Override
    public void classInformation(){
        System.out.println("--------------------------------------------");
        System.out.print("1.查看所有班级基本信息");
        System.out.println("\t\t2.查看某班级学生");
        System.out.print("3.查看班级成绩");
        System.out.println("\t\t\t4.返回上一级");
    }
    @Override
    public void classScore(){
        System.out.println("--------------------------------------------");
        System.out.print("1.按学号排序查询");
        System.out.println("\t\t\t2.按综合成绩排名");
        System.out.print("3.统计教学班分数段分布");
        System.out.println("\t\t4.返回上一级");
    }

    @Override
    public void courseScore(){
        System.out.println("--------------------------------------------");
        System.out.print("1.按学号排序查询");
        System.out.println("\t\t\t2.按综合成绩排名");
        System.out.print("3.统计课程分数段分布");
        System.out.println("\t\t4.返回上一级");
    }

    @Override
    public void scoreInformation() {
        System.out.println("--------------------------------------------");
        System.out.print("1.查看所有学生各科目的成绩");
        System.out.println("\t\t\t2.修改/添加学生成绩");
        System.out.println("3.返回上一级");
    }

    @Override
    public void courseInformation(){
        System.out.println("--------------------------------------------");
        System.out.print("1.查询所有课程信息");
        System.out.println("\t\t\t2.查询课程对应班级信息");
        System.out.print("3.查询课程学生成绩");
        System.out.println("\t\t\t4.查询课程学生成绩分布");
        System.out.println("5.返回上一级");
    }
    @Override
    public void studentInformation(){
        System.out.println("--------------------------------------------");
        System.out.print("1.展示所有学生信息");
        System.out.println("\t\t2.模糊查询部分学生信息");
        System.out.print("3.统计学生个人成绩单");
        System.out.println("\t4.添加学生信息");
        System.out.print("5.修改学生基本信息");
        System.out.println("\t\t6.删除学生");
        System.out.print("7.学生选课");
        System.out.println("\t\t\t8.返回上一级");

    }
    @Override
    public void teacherInformation(){
        System.out.println("--------------------------------------------");
        System.out.print("1.查询教师教学班信息");
        System.out.println("\t\t\t2.查询教师成绩分布图");
        System.out.println("3.返回上一级");
    }





}
