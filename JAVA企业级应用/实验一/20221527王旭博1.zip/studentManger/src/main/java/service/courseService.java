package service;

import pojo.Course;
import pojo.Class;
import pojo.Score;

import java.util.ArrayList;

public interface courseService {
    //查询所有课程信息
    void queryCourse(ArrayList<Course> courses);
    //查询课程对应班级信息
    void queryClassByCourse(ArrayList<Class> classes,String courseId);
    //查询课程总体学生成绩分布
    void queryCourseScoreSegment(ArrayList<Score> scores,String courseId);
    //查询课程学生成绩
    ArrayList<Score> queryCourseScoreAllStudents(ArrayList<Score> scores,String courseId);
}
