package service.Impl;

import pojo.Class;
import pojo.Course;
import pojo.Score;
import service.courseService;

import java.util.ArrayList;
import java.util.function.Predicate;

public class courseServiceImpl implements courseService {
    // 单例模式的使用
    private static courseServiceImpl Instance; // 静态实例
    private courseServiceImpl(){} // 私有构造函数，防止外部实例化

    public static courseServiceImpl getInstance(){
        if (Instance == null){
            synchronized (courseServiceImpl.class){ // 线程安全的单例实现
                if(Instance==null){
                    Instance=new courseServiceImpl(); // 实例化对象
                }
            }
        }
        return Instance; // 返回单例对象
    }

    @Override
    public void queryCourse(ArrayList<Course> courses) {
        // 遍历课程列表并打印课程信息
        for(Course co:courses){
            System.out.println("课程编号："+co.getCourseId()+" 课程名字："+co.getCourseName()+" 开课学期："+co.getSemester());
        }
    }

    @Override
    public void queryClassByCourse(ArrayList<Class> classes, String courseId) {
        // 遍历班级列表，打印指定课程的信息
        for(Class cls:classes){
            if(cls.getCourseId().equals(courseId)){
                System.out.println("教师："+cls.getTeacherId()+" 课程："+cls.getCourseId()+" 总人数："+
                        cls.getCount()+" 教学班号："+cls.getClassId());
            }
        }
    }

    @Override
    public void queryCourseScoreSegment(ArrayList<Score> scores, String courseId) {
        ArrayList<Score> classScore = new ArrayList<>();
        // 过滤出指定课程的成绩
        scores.stream().filter(score->score.getCourseId().equals(courseId))
                .forEach(score->classScore.add(score));
        Integer studentCount = classScore.size(); // 学生数量

        // 统计各个分数段
        int[] usualCounts = new int[4];
        int[] experimentCounts = new int[4];
        int[] midtermCounts = new int[4];
        int[] finaltermCounts = new int[4];
        int[] finalCounts = new int[4];

        // 统计各类成绩分数段
        for (Score score : classScore) {
            addToCounts(usualCounts, parseScore(score.getUsualScore()));
            addToCounts(experimentCounts, parseScore(score.getExperimentScore()));
            addToCounts(midtermCounts, parseScore(score.getMidtermScore()));
            addToCounts(finaltermCounts, parseScore(score.getFinaltermScore()));
            addToCounts(finalCounts, parseScore(score.getFinalScore()));
        }

        // 打印各类成绩统计结果
        printResults("平时成绩", usualCounts, studentCount);
        printResults("实验成绩", experimentCounts, studentCount);
        printResults("期中成绩", midtermCounts, studentCount);
        printResults("期末成绩", finaltermCounts, studentCount);
        printResults("综合成绩", finalCounts, studentCount);
    }

    @Override
    public ArrayList<Score> queryCourseScoreAllStudents(ArrayList<Score> scores, String courseId) {
        // 创建一个新的 ArrayList 来存储匹配的 Score 对象
        ArrayList<Score> filteredScores = new ArrayList<>();

        // 过滤出指定课程的所有成绩
        scores.stream()
                .filter(score -> score.getCourseId().equals(courseId)) // 过滤出匹配的课程成绩
                .forEach(score -> {
                    // 打印成绩信息
                    System.out.println("学号：" + score.getStudentId() +
                            " 课程号：" + score.getCourseId() +
                            " 平时成绩：" + score.getUsualScore() +
                            " 实验成绩：" + score.getExperimentScore() +
                            " 期中成绩：" + score.getMidtermScore() +
                            " 期末成绩：" + score.getFinaltermScore() +
                            " 综合成绩：" + score.getFinalScore());

                    // 将匹配的成绩添加到新的列表中
                    filteredScores.add(score);
                });

        // 返回存储的成绩列表
        return filteredScores;
    }

    private void addToCounts(int[] counts, int score) {
        // 根据分数范围更新计数数组
        if (score < 60) {
            counts[0]++;
        } else if (score >= 60 && score < 80) {
            counts[1]++;
        } else if (score >= 80 && score <= 100) {
            counts[2]++;
        }
    }

    private void printResults(String scoreType, int[] counts, int totalStudents) {
        System.out.println(scoreType + "统计："); // 打印当前成绩类型的统计标题

        // 计算并打印每个阶段的占比和对应的彩色横条
        for (int i = 0; i < counts.length; i++) {
            double percentage = counts[i] * 100.0 / totalStudents; // 计算各分数段占比
            String bar = createColoredBar(percentage, i); // 创建对应的彩色横条

            switch (i) {
                case 0:
                    System.out.println("60以下人数占比： " + String.format("%.2f", percentage) + "%" + " " + bar);
                    break;
                case 1:
                    System.out.println("60-80人数占比： " + String.format("%.2f", percentage) + "%" + " " + bar);
                    break;
                case 2:
                    System.out.println("80-100人数占比：" + String.format("%.2f", percentage) + "%" + " " + bar);
                    break;
                default:
                    break;
            }
        }
    }

    private String createColoredBar(double percentage, int index) {
        int length = (int) (percentage / 2); // 假设每2%对应一个字符的长度
        StringBuilder bar = new StringBuilder();

        // 根据索引定义颜色代码
        String color;
        switch (index) {
            case 0: color = "\u001B[31m"; // 红色
                break;
            case 1: color = "\u001B[33m"; // 黄色
                break;
            case 2: color = "\u001B[32m"; // 绿色
                break;
            default: color = "\u001B[0m"; // 默认颜色
                break;
        }

        // 创建彩色横条
        for (int j = 0; j < length; j++) {
            bar.append(color + "█");  // 用█字符表示横条
        }

        bar.append("\u001B[0m"); // 重置颜色
        return bar.toString();
    }

    private int parseScore(String scoreStr) {
        // 尝试将字符串转换为整数，若失败则返回0
        try {
            return Integer.parseInt(scoreStr);
        } catch (NumberFormatException e) {
            return 0; // 若无法转换则设置为0分
        }
    }
}

