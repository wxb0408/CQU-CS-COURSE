package service.Impl;

import pojo.Score;
import pojo.Student;
import service.scoreService;

import java.util.ArrayList;

public class scoreServiceImpl implements scoreService {
    //单例模式的使用
    private static scoreServiceImpl Instance;
    private scoreServiceImpl(){}

    public static scoreServiceImpl getInstance(){
        if (Instance == null){
            synchronized (scoreServiceImpl.class){
                if(Instance==null){
                    Instance=new scoreServiceImpl();
                }
            }
        }
        return Instance;
    }
    @Override
    public void showAllStudent(ArrayList<Score> scores) {
        scores.stream().forEach(score -> {
                    System.out.println("学生ID: " + score.getStudentId() +
                            ", 课程编号: " + score.getCourseId() +
                            ", 教学班号: " + score.getClassId() +
                            ", 平时成绩: " + score.getUsualScore()+
                            ", 实验成绩: " + score.getExperimentScore()+
                            ", 期中成绩: " + score.getUsualScore()+
                            ", 期末成绩: " + score.getFinaltermScore()+
                            ", 综合成绩: " + score.getFinalScore()+
                            ", 单科绩点: " + String.format("%.2f", Double.parseDouble(score.getGpa()))+
                            ", 创建时间: " + score.getCreationTime()+
                            ", 修改时间: " + score.getUpdateTime());
                });
    }

    @Override
    public void updateStudentScore(ArrayList<Student> stus, String studentid, String courseid, ArrayList<Score> scores, String usualsc, String experimentsc, String midtermsc, String finaltermsc) {
        scores.stream().filter(score->score.getStudentId().equals(studentid)&&score.getCourseId().equals(courseid)).findFirst()
                .ifPresentOrElse(score->{
                    score.setUsualScore(usualsc);
                    score.setExperimentScore(experimentsc);
                    score.setMidtermScore(midtermsc);
                    score.setFinaltermScore(finaltermsc);
                    double usualScoreValue = Double.parseDouble(usualsc);
                    double experimentScoreValue = Double.parseDouble(experimentsc);
                    double midtermScoreValue = Double.parseDouble(midtermsc);
                    double finaltermScoreValue = Double.parseDouble(finaltermsc);
                    double totalScore = (usualScoreValue * 0.1 +
                            experimentScoreValue * 0.2 +
                            midtermScoreValue * 0.2 +
                            finaltermScoreValue * 0.5);
                    double gpa =calculateGPA(totalScore);
                    score.setFinalScore(String.valueOf(totalScore));
                    score.setGpa(String.valueOf(gpa));
                    double totalGpa = scores.stream()
                            .filter(s -> s.getStudentId().equals(studentid) && !s.getGpa().isEmpty()) // 过滤出该学生所有记录且绩点不为空
                            .mapToDouble(s -> Double.parseDouble(s.getGpa())) // 提取绩点
                            .sum(); // 累加绩点
                    long count = scores.stream()
                            .filter(s -> s.getStudentId().equals(studentid) && !s.getGpa().isEmpty()) // 统计有效的绩点记录数
                            .count(); // 有效记录数
                        double averageGpa = totalGpa / count; // 计算平均 GPA
                    stus.stream().filter(s -> s.getStudentId().equals(studentid)).findFirst()
                                    .ifPresent(s->s.setGpa(String.valueOf(averageGpa)));
                    System.out.println("成绩更新成功: 学生ID = " + studentid + ", 课程ID = " + courseid + ", 综合成绩 = " + totalScore + ", gpa = " + gpa);
                },()->{
                    System.out.println("未找到相应的成绩记录: 学生ID = " + studentid + ", 课程ID = " + courseid);
                });
    }

    private static double calculateGPA(double finalScore) {
        if (finalScore >= 90 && finalScore <= 100) {
            return 4.0;
        } else if (finalScore < 60) {
            return 0.0;
        } else {
            return 4.0 - (90 - finalScore) * 0.1; // 每减一分GPA减0.1
        }
    }
}
