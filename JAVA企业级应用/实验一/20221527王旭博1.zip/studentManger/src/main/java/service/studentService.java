package service;

import pojo.Class;
import pojo.Score;
import pojo.Student;

import java.util.ArrayList;

public interface studentService {

    //展示所有学生信息
    void showStudent(ArrayList<Student> stus);
    //模糊查询学生信息
    void fuzzyShowStudent(ArrayList<Student> stus, String s);
    //按照绩点排名的学生信息
    void queryClassScoreBygpa(ArrayList<Student> stus);
    //统计某个学生个人成绩单
    void studentScores(ArrayList<Student> stus,String studentId,ArrayList<Score> scores);
    //添加学生
    void addStudent(ArrayList<Student> stus);
    //修改学生信息
    boolean updateStudent(ArrayList<Student> stus,Student stu);
    //删除学生
    void deleteStudent(ArrayList<Score> scores,ArrayList<Class> classes,ArrayList<Student> stus,String studentId);
    //学生选课
    void selectCourse(ArrayList<Score> scores,ArrayList<Class> classes, ArrayList<Student> stus, String studentId, ArrayList<String> selectedClass);
}
